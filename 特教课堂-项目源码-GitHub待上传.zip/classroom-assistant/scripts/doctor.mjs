import { available, python } from "./process.mjs";
console.log(`Node.js ${process.versions.node}`);
if (Number(process.versions.node.split(".")[0]) !== 24) {
  console.error("请使用Node.js 24 LTS");
  process.exitCode = 1;
} else if (!available("uv", ["--version"])) {
  console.error("缺少uv，请安装后运行pnpm bootstrap");
  process.exitCode = 1;
} else {
  try {
    await python(["python", "scripts/doctor.py"]);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
