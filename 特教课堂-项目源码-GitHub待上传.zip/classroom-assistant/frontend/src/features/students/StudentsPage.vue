<script setup lang="ts">
import { onMounted, reactive, ref } from "vue";
import Button from "../../components/Button.vue";
import { ElMessage } from "element-plus";
import {
  studentsApi,
  type Student,
  type StudentInput,
} from "../../api/services/students";
const students = ref<Student[]>([]);
const selected = ref<Student | null>(null);
const busy = ref(false);
const form = reactive<StudentInput>({
  name: "",
  communication_modes: ["action"],
  goals: [],
  observed_abilities: [],
  usual_supports: [],
  interests: [],
  notes: "",
});
const abilities = ref("");
const supports = ref("");
const interests = ref("");
const modes = [
  { value: "speech", label: "语言" },
  { value: "gesture", label: "手势" },
  { value: "aac", label: "辅助沟通" },
  { value: "action", label: "动作" },
  { value: "other", label: "其他" },
];
const lines = (value: string) =>
  value
    .split("\n")
    .map((v) => v.trim())
    .filter(Boolean);
async function load() {
  try {
    students.value = (await studentsApi.list()).items;
  } catch (e) {
    ElMessage.error((e as Error).message);
  }
}
function edit(student: Student | null) {
  selected.value = student;
  Object.assign(
    form,
    student
      ? {
          name: student.name,
          communication_modes: [...student.communication_modes],
          goals: student.goals.map((g) => ({ ...g })),
          observed_abilities: [...student.observed_abilities],
          usual_supports: [...student.usual_supports],
          interests: [...student.interests],
          notes: student.notes,
        }
      : {
          name: "",
          communication_modes: ["action"],
          goals: [{ description: "", criterion: null }],
          observed_abilities: [],
          usual_supports: [],
          interests: [],
          notes: "",
        },
  );
  abilities.value = form.observed_abilities.join("\n");
  supports.value = form.usual_supports.join("\n");
  interests.value = form.interests.join("\n");
}
async function save() {
  if (!form.name.trim() || form.goals.some((g) => !g.description.trim())) {
    ElMessage.warning("请填写姓名和已添加目标的描述");
    return;
  }
  busy.value = true;
  try {
    const body = {
      ...form,
      observed_abilities: lines(abilities.value),
      usual_supports: lines(supports.value),
      interests: lines(interests.value),
    };
    const student = selected.value
      ? await studentsApi.update(selected.value.id, {
          ...body,
          expected_revision: selected.value.revision,
        })
      : await studentsApi.create(body);
    await load();
    edit(student);
    ElMessage.success("档案已保存");
  } catch (e) {
    ElMessage.error((e as Error).message);
  } finally {
    busy.value = false;
  }
}
onMounted(async () => {
  await load();
  if (students.value.length) edit(students.value[0]);
});
edit(null);
</script>
<template>
  <div class="page-title">
    <div>
      <router-link to="/" class="back-link">← 返回工作台</router-link>
      <span class="stage-tag stage-blue">学生 · 档案</span>
      <h1>学生档案</h1>
      <p class="subtle">目标由教师维护，生成方案引用已有目标。</p>
    </div>
    <Button variant="secondary" @click="edit(null)">新建学生</Button>
  </div>
  <p class="preview-notice">
    预置学生均为虚构教学案例。目标描述和达成标准用于规划，课堂是否完成应依据实际观察记录。
  </p>
  <div class="two-column">
    <section>
      <h2>学生列表</h2>
      <el-empty v-if="!students.length" description="暂无档案" />
      <button
        v-for="student in students"
        :key="student.id"
        class="list-row"
        :class="{ 'student-selected': selected?.id === student.id }"
        @click="edit(student)"
      >
        <strong>{{ student.name }}</strong>
        <span>
          {{ student.goals.length }} 个目标 · 版本 {{ student.revision }}
        </span>
        <span>{{ student.interests.join(" · ") || "尚未填写兴趣材料" }}</span>
      </button>
    </section>
    <section>
      <h2>{{ selected ? "编辑档案" : "新建档案" }}</h2>
      <el-form label-position="top">
        <el-form-item label="姓名">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="沟通方式">
          <el-checkbox-group v-model="form.communication_modes">
            <el-checkbox
              v-for="mode in modes"
              :key="mode.value"
              :value="mode.value"
            >
              {{ mode.label }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <h3>教学目标</h3>
        <div
          v-for="(goal, index) in form.goals"
          :key="goal.id || index"
          class="student-goal-card"
        >
          <div class="student-goal-heading">
            <strong>目标 {{ String(index + 1).padStart(2, "0") }}</strong
            ><Button size="sm" variant="quiet" @click="form.goals.splice(index, 1)">移除</Button>
          </div>
          <el-form-item :label="`目标${index + 1}描述`"
            ><el-input
              v-model="goal.description"
              type="textarea"
              :rows="2"
              placeholder="可观察的目标描述"
          /></el-form-item>
          <el-form-item :label="`目标${index + 1}观察或达成标准`"
            ><el-input
              :model-value="goal.criterion ?? ''"
              @update:model-value="goal.criterion = $event || null"
              type="textarea"
              :rows="2"
              placeholder="观察或达成标准（未知可留空）"
          /></el-form-item>
        </div>
        <Button size="sm" variant="ghost" @click="form.goals.push({ description: '', criterion: null })">添加目标</Button>
        <el-form-item label="已观察能力（每行一项）">
          <el-input v-model="abilities" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="常用支持（每行一项）">
          <el-input v-model="supports" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="兴趣材料（每行一项）">
          <el-input v-model="interests" type="textarea" />
        </el-form-item>
        <el-form-item label="教师备注">
          <el-input v-model="form.notes" type="textarea" :rows="4" />
        </el-form-item>
        <Button variant="primary" :loading="busy" @click="save">保存档案</Button>
      </el-form>
    </section>
  </div>
</template>
<style scoped>
.student-goal-card {
  padding: 18px;
  margin-bottom: 16px;
  border: 1px solid var(--line);
  border-radius: 12px;
  background: #fafbf7;
}
.student-goal-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  color: var(--green);
  font-size: 12px;
}
.student-goal-card .el-form-item:last-child {
  margin-bottom: 0;
}
</style>
