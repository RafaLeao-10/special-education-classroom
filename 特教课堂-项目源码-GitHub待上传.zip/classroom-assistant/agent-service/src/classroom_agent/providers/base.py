from typing import Protocol

from classroom_contracts.agent import AgentRequest, AgentResponse


class Provider(Protocol):
    async def generate(self, request: AgentRequest) -> AgentResponse: ...
