<script setup lang="ts">
import { ref, onMounted, computed } from "vue";
import { assetsApi, type Asset } from "../../api/services/assets";
import Button from "../../components/Button.vue";

const value = defineModel<string | null>({ required: true });
const assets = ref<Asset[]>([]);
const alt = ref("");
const error = ref("");
const busy = ref(false);
const selected = computed(() => assets.value.find((a) => a.id === value.value));
async function load() {
  try {
    assets.value = (await assetsApi.list()).filter(a => a.kind === "image");
    error.value = "";
  } catch (e) {
    error.value = (e as Error).message;
  }
}
async function upload(event: Event) {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  busy.value = true;
  try {
    const asset = await assetsApi.upload(file, alt.value);
    assets.value.push(asset);
    value.value = asset.id;
    error.value = "";
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    busy.value = false;
    input.value = "";
  }
}
onMounted(load);
</script>
<template>
  <div class="asset-picker">
    <el-select
      :model-value="value || ''"
      clearable
      placeholder="选择教学图片（可选）"
      aria-label="教学图片"
      @update:model-value="value = $event || null"
      ><el-option
        v-for="a in assets"
        :key="a.id"
        :value="a.id"
        :label="a.name" /></el-select
    ><img
      v-if="selected"
      :src="selected.url"
      :alt="selected.alt"
      class="asset-thumbnail"
    />
    <details>
      <summary>上传新图片</summary>
      <el-input
        v-model="alt"
        placeholder="图片内容描述"
        aria-label="图片内容描述"
      /><input
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif"
        :disabled="busy"
        aria-label="上传教学图片"
        @change="upload"
      />
      <p v-if="busy" class="subtle">正在保存图片…</p>
    </details>
    <p v-if="error" class="inline-error">
      {{ error }}<Button size="sm" variant="ghost" @click="load">重试</Button>
    </p>
  </div>
</template>
