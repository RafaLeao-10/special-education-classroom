<script setup lang="ts">
import AppIcon from "../../components/AppIcon.vue";

defineProps<{ stars: number; goal: number; celebrating: boolean }>();
</script>

<template>
<div class="token-board" :class="{ 'token-celebrate': celebrating }">
    <span
    v-for="i in goal"
    :key="i"
    class="token-star"
    :class="{ 'is-filled': i <= stars }"
    >
    <AppIcon name="star" :size="34" />
    </span>
    <span class="token-goal">{{ stars }} / {{ goal }}</span>
    <template v-if="celebrating">
    <i
        v-for="i in 10"
        :key="'b' + i"
        class="burst"
        :style="{ '--angle': `${i * 36}deg` }"
        aria-hidden="true"
    />
    </template>
</div>
</template>