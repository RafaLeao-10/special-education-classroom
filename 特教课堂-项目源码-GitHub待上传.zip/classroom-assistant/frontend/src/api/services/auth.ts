import { client, unwrap } from "../client";

export const auth = {
  login: async (username: string, password: string) =>
    unwrap(
      await client.POST("/api/v1/auth/login", { body: { username, password } }),
    ),
  me: async () => unwrap(await client.GET("/api/v1/auth/me")),
  logout: async () =>
    unwrap(await client.POST("/api/v1/auth/logout", { body: {} })),
};
