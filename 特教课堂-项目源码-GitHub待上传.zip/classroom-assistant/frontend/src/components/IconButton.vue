<script setup lang="ts">
import AppIcon from "./AppIcon.vue";

withDefaults(
defineProps<{
    /** AppIcon 图标名 */
    name: string;
    /** 无障碍名称。纯图标按钮必须传，读屏软件靠它念出按钮是什么 */
    label: string;
    /** md = 40×40，lg = 48×48（平板端，提示词 §3）*/
    size?: "md" | "lg";
    loading?: boolean;
    disabled?: boolean;
}>(),
{ size: "md" }
);

const emit = defineEmits<{ click: [ev: MouseEvent] }>();
</script>

<template>
<button
    class="icon-btn"
    :class="{ 'icon-btn-lg': size === 'lg', 'is-loading': loading }"
    type="button"
    :disabled="disabled"
    :aria-label="label"
    :aria-busy="loading || undefined"
    @click="emit('click', $event)"
>
    <span v-if="loading" class="btn-spinner" aria-hidden="true"></span>
    <AppIcon v-else :name="name" :size="size === 'lg' ? 22 : 20" />
</button>
</template>