"""Pure teaching calculations; no model, database or provider dependency."""
