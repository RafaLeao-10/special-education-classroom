from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import LessonRow


def used_goal_ids(db: Session, student_id: str) -> set[str]:
    """Read current plan references; no student mutation or transaction ownership here."""
    ids = set()
    rows = db.scalars(
        select(LessonRow).where(
            LessonRow.student_ids.contains([student_id]), LessonRow.status.in_(["draft", "ready"])
        )
    )
    for row in rows:
        for activity in (row.plan or {}).get("activities", []):
            for task in activity["tasks"]:
                for target in task["student_targets"]:
                    if target["student_id"] == student_id:
                        ids.update(target["goal_ids"])
    return ids
