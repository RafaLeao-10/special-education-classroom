// 图谱节点 → 备课"教学方式"的映射：让老师从图谱直接带着方法去备课。
// 方法 id 与 ../preparation/trainingMethods 的 id 一致。
import sample from "./graph.sample.json";
import type { KnowledgeGraph } from "./graph.types";

const graph = sample as KnowledgeGraph;

type NodeMapping = { methods: string[]; note: string };

// 有直接对应教学方式的节点
export const nodeMethodMap: Record<string, NodeMapping> = {
"task-analysis": { methods: ["task_analysis"], note: "" },
dtt: { methods: ["discrete_trial"], note: "" },
prt: { methods: ["naturalistic", "play"], note: "" },
ndbi: { methods: ["naturalistic", "play"], note: "" },
esdm: { methods: ["naturalistic", "play"], note: "" },
jasper: { methods: ["naturalistic", "play"], note: "" },
teacch: { methods: ["task_analysis"], note: "" },
sst: { methods: ["discussion"], note: "" },
aba: { methods: ["discrete_trial", "naturalistic"], note: "" },
};

// 按节点 id 取"带进备课页的信息"；未映射的节点（pecs/aac/fct/emt/scerts/
// pbii/pii/asi、社交故事、DIR/Floortime 等）没有直接对应方式，
// 返回一段说明文字，由老师自行选择或补充。
export function nodePrepareInfo(nodeId: string): NodeMapping {
const node = graph.nodes.find((n) => n.id === nodeId);
if (!node) return { methods: [], note: "" };
const mapped = nodeMethodMap[nodeId];
if (mapped && mapped.methods.length) return mapped;
return {
    methods: [],
    note: `${node.label}暂无直接对应的教学方式，可参考其要点自行选择或补充。`,
};
}