import type { Lesson, LessonPlan } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
export type Activity = LessonPlan["activities"][number];
export type Task = Activity["tasks"][number];
export type Step = Task["steps"][number];
export function newStep(order = 1): Step {
  return {
    id: crypto.randomUUID(),
    order,
    instruction: "",
    expected_response: "",
    completion_criterion: "",
    observation_focus: "",
    demonstration: "",
    display_blocks: [{ type: "text", text: "" }],
  };
}
export function syncTargets(task: Task, students: Student[]) {
  task.student_targets = task.participant_ids.map(
    (id) =>
      task.student_targets.find((t) => t.student_id === id) || {
        student_id: id,
        goal_ids: [],
        completion_criterion: "",
        accepted_response_modes: [
          ...(students.find((s) => s.id === id)?.communication_modes || []),
        ],
        routine_support_ids: [],
        adaptation_note: "",
      },
  );
}
export function newTask(participants: string[], students: Student[]): Task {
  const task: Task = {
    id: crypto.randomUUID(),
    title: "新任务",
    participant_ids: [...participants],
    objective: "",
    student_targets: [],
    practice_format: "naturalistic",
    material_ids: [],
    teacher_preparation: "",
    feedback_guidance: "",
    recording_unit: "task",
    planned_opportunities: null,
    steps: [newStep()],
    knowledge_refs: [],
  };
  syncTargets(task, students);
  return task;
}
export function newActivity(lesson: Lesson, students: Student[]): Activity {
  return {
    id: crypto.randomUUID(),
    title: "新活动",
    order: 1,
    activity_type: "individual",
    duration_min: 1,
    participant_ids: [...lesson.student_ids],
    group_id: null,
    tasks: [newTask(lesson.student_ids, students)],
  };
}
export function newPlan(lesson: Lesson, students: Student[]): LessonPlan {
  return {
    title: lesson.title,
    groups: [],
    supports: [],
    activities: [newActivity(lesson, students)],
    resources: [],
    references: [],
  };
}
export function reorder<T>(items: T[], index: number, delta: number) {
  const next = index + delta;
  if (next < 0 || next >= items.length) return;
  const [item] = items.splice(index, 1);
  items.splice(next, 0, item);
}
export function normalizeOrder(items: { order: number }[]) {
  items.forEach((item, i) => (item.order = i + 1));
}
export function pruneTaskReferences(plan: LessonPlan) {
  const ids = new Set(plan.activities.flatMap((a) => a.tasks.map((t) => t.id)));
  for (const resource of plan.resources)
    resource.task_ids = resource.task_ids.filter((id) => ids.has(id));
}
export function removeSupport(plan: LessonPlan, id: string) {
  plan.supports = plan.supports.filter((s) => s.id !== id);
  for (const a of plan.activities)
    for (const t of a.tasks)
      for (const target of t.student_targets)
        target.routine_support_ids = target.routine_support_ids.filter(
          (s) => s !== id,
        );
}
export const communicationModes = [
  ["speech", "语言"],
  ["gesture", "手势"],
  ["aac", "辅助沟通"],
  ["action", "动作"],
  ["other", "其他"],
] as const;
export const practiceFormats = [
  ["discrete_trial", "离散回合"],
  ["task_analysis", "任务分析"],
  ["naturalistic", "自然情境"],
] as const;
