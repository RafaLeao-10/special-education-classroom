"""Apply proposals only after teacher adoption; keep past records tied to their plan version."""

from datetime import UTC, datetime
from uuid import uuid4

from classroom_api.errors import BusinessError
from classroom_contracts.agent import AdjustmentProposal, AdjustParams
from classroom_contracts.models import AdjustmentLog, LessonPlan, Student
from sqlalchemy import select

from . import service
from .history import save_snapshot
from .models import AdjustmentRow
from .validation import check_plan


def validate_steps(original, update, params):
    """A split substitutes selected steps in place; old facts stay in their plan snapshot."""
    replacement = update.replacement
    if not update.step_splits:
        if [s.id for s in original.steps] != [s.id for s in replacement.steps]:
            raise BusinessError(422, "INVALID_ARGUMENT", "步骤结构变化需要说明原步骤与新步骤的对应关系")
        if params.step_ids and any(
            old.model_dump(exclude={"order"}) != new.model_dump(exclude={"order"})
            and old.id not in params.step_ids
            for old, new in zip(original.steps, replacement.steps, strict=True)
        ):
            raise BusinessError(422, "INVALID_ARGUMENT", "调整改变了教师未选定的步骤")
        return {}
    if params.action != "simplify_instruction":
        raise BusinessError(422, "INVALID_ARGUMENT", "实时拆步请使用指令调整")
    splits = {s.source_step_id: s.replacement_step_ids for s in update.step_splits}
    old_ids = {s.id for s in original.steps}
    new_ids = [id for ids in splits.values() for id in ids]
    selected = set(params.step_ids) or old_ids
    if (
        len(splits) != len(update.step_splits)
        or not splits.keys() <= old_ids & selected
        or len(new_ids) != len(set(new_ids))
        or old_ids & set(new_ids)
    ):
        raise BusinessError(422, "INVALID_ARGUMENT", "拆步须对应选定的原步骤，并为新步骤使用独立标识")
    expected = [id for step in original.steps for id in splits.get(step.id, [step.id])]
    if [s.id for s in replacement.steps] != expected:
        raise BusinessError(422, "INVALID_ARGUMENT", "新步骤须原位替换被拆步骤，保留其他步骤的顺序")
    current = {s.id: s for s in replacement.steps}
    if any(
        step.model_dump(exclude={"order"}) != current[step.id].model_dump(exclude={"order"})
        for step in original.steps
        if step.id not in splits
    ):
        raise BusinessError(422, "INVALID_ARGUMENT", "拆步不能修改未选择的步骤")
    return splits


def listing(db, lesson_id):
    rows = db.scalars(
        select(AdjustmentRow).where(AdjustmentRow.lesson_id == lesson_id).order_by(AdjustmentRow.applied_at)
    )
    return [AdjustmentLog.model_validate(row.details) for row in rows]


def apply(db, lesson, job_id: str, params: AdjustParams, proposal: AdjustmentProposal):
    if lesson.status != "in_progress" or lesson.plan is None:
        raise BusinessError(409, "INVALID_STATE", "仅课堂进行中可以采用调整")
    if proposal.action != params.action:
        raise BusinessError(422, "INVALID_ARGUMENT", "调整结果与教师选择的动作不一致")
    plan = LessonPlan.model_validate(lesson.plan)
    tasks = {t.id: t for a in plan.activities for t in a.tasks}
    states = {s["task_id"]: s["status"] for s in lesson.execution["task_states"]}
    targets = set(params.target_task_ids)
    if not targets or not targets <= tasks.keys():
        raise BusinessError(422, "INVALID_ARGUMENT", "请选择本课的调整任务")
    if len({u.task_id for u in proposal.task_updates}) != len(proposal.task_updates):
        raise BusinessError(422, "INVALID_ARGUMENT", "同一任务不能重复调整")
    split_enabled = set(lesson.execution.get("split_task_ids", []))
    if params.instruction_mode == "split" and not targets <= split_enabled:
        raise BusinessError(409, "INVALID_STATE", "请先打开目标任务的拆分指令开关")
    split_map = {}
    for update in proposal.task_updates:
        if update.task_id not in targets or states.get(update.task_id) in ("done", "skipped"):
            raise BusinessError(409, "INVALID_STATE", "不能调整范围外或已经结束的任务")
        original, replacement = tasks[update.task_id], update.replacement
        fixed = (
            "id",
            "participant_ids",
            "student_targets",
            "practice_format",
            "recording_unit",
            "planned_opportunities",
        )
        if any(getattr(original, key) != getattr(replacement, key) for key in fixed):
            raise BusinessError(422, "INVALID_ARGUMENT", "调整须保留任务标识、学生目标和观察口径")
        split_map.update(validate_steps(original, update, params))
        if (
            params.action == "replace_material"
            and params.replacement_material_id not in replacement.material_ids
        ):
            raise BusinessError(422, "INVALID_ARGUMENT", "未采用教师选定的替换材料")
        for activity in plan.activities:
            activity.tasks = [replacement if t.id == update.task_id else t for t in activity.tasks]
    if params.action == "simplify_instruction" and params.instruction_mode == "split" and not split_map:
        raise BusinessError(422, "INVALID_ARGUMENT", "本次要求实时拆步，但候选结果没有生成独立的新步骤")
    future = proposal.future_activity_replacement
    if future:
        ids = set(future.replace_activity_ids)
        selected = [a for a in plan.activities if a.id in ids]
        if (
            params.action != "adjust_next_activity"
            or len(selected) != len(ids)
            or not selected
            or not future.activities
        ):
            raise BusinessError(422, "INVALID_ARGUMENT", "后续活动替换范围无效")
        if any(states.get(t.id) != "pending" for a in selected for t in a.tasks):
            raise BusinessError(409, "INVALID_STATE", "只能替换尚未开始的完整活动")
        if not targets <= {t.id for a in selected for t in a.tasks}:
            raise BusinessError(422, "INVALID_ARGUMENT", "替换范围未包含教师选择的后续任务")
        replacement_tasks = {t.id for a in future.activities for t in a.tasks}
        if replacement_tasks & tasks.keys():
            raise BusinessError(422, "INVALID_ARGUMENT", "新活动的任务需使用新标识，以保留历史记录")
        first = next(i for i, a in enumerate(plan.activities) if a.id in ids)
        retained = [a for a in plan.activities if a.id not in ids]
        retained[first:first] = future.activities
        plan.activities = retained
        removed = {t.id for a in selected for t in a.tasks}
        plan.resources = [r for r in plan.resources if not set(r.task_ids) & removed]
    if not proposal.task_updates and not future:
        raise BusinessError(422, "INVALID_ARGUMENT", "本次结果没有可采用的调整")
    for index, activity in enumerate(plan.activities, 1):
        activity.order = index
    resources = {r.id: r for r in plan.resources}
    resources.update({r.id: r for r in proposal.resource_updates})
    plan.resources = list(resources.values())
    references = {r.knowledge_id: r for r in plan.references}
    references.update({r.knowledge_id: r for r in proposal.references})
    plan.references = list(references.values())
    people = [Student.model_validate(s) for s in lesson.student_snapshots]
    check_plan(plan, service.to_dto(lesson), people)
    service.validate_assets(db, plan, service.to_dto(lesson))
    previous_version = lesson.plan_version
    lesson.plan = plan.model_dump(mode="json")
    lesson.plan_version += 1
    lesson.record_version += 1
    execution = {**lesson.execution}
    execution["task_states"] = [
        {"task_id": t.id, "status": states.get(t.id, "pending")} for a in plan.activities for t in a.tasks
    ]
    execution["split_task_ids"] = [
        id for id in execution.get("split_task_ids", [])
        if id in {t.id for a in plan.activities for t in a.tasks}
    ]
    execution["display_revision"] += 1
    if execution["display_step_id"] in split_map:
        execution["display_step_id"] = split_map[execution["display_step_id"]][0]
    if execution["display_task_id"] not in {s["task_id"] for s in execution["task_states"]}:
        execution["display_task_id"] = execution["display_step_id"] = None
    lesson.execution = execution
    now = datetime.now(UTC)
    lesson.updated_at = now
    entry = AdjustmentLog(
        id=str(uuid4()),
        job_id=job_id,
        action=params.action,
        from_plan_version=previous_version,
        to_plan_version=lesson.plan_version,
        target_task_ids=params.target_task_ids,
        summary=proposal.summary,
        applied_at=now,
    )
    db.add(
        AdjustmentRow(
            id=entry.id,
            lesson_id=lesson.id,
            job_id=job_id,
            details=entry.model_dump(mode="json"),
            applied_at=now,
        )
    )
    save_snapshot(db, lesson)
    db.flush()
    return entry
