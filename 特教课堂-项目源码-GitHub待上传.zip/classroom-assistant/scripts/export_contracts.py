"""Generate from imports only: no lifespan, database connection or external call."""

import argparse
import json
from pathlib import Path

from classroom_api.main import create_app
from classroom_contracts.agent import AgentRequest, AgentResponse
from classroom_contracts.models import DTO, StatisticsRow
from classroom_contracts.teaching import StatisticsInput
from planned_contracts import planned_openapi

ROOT = Path(__file__).resolve().parents[1]


class AgentProtocol(DTO):
    request: AgentRequest
    response: AgentResponse


class TeachingProtocol(DTO):
    request: StatisticsInput
    response: list[StatisticsRow]


def export(target: Path):
    target.mkdir(parents=True, exist_ok=True)
    for name, data in (
        ("openapi.json", create_app().openapi()),
        ("agent.schema.json", AgentProtocol.model_json_schema()),
        ("teaching.schema.json", TeachingProtocol.model_json_schema()),
        ("planned.openapi.json", planned_openapi()),
    ):
        (target / name).write_text(
            json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
            newline="\n",
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "contracts/generated")
    export(parser.parse_args().output)
