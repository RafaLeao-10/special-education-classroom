import { ref } from "vue";
import { emptyCounts, type Counts } from "./counts";

// 模块级单例：课堂快捷键与观察表单共享同一份待保存计数
export const pendingCounts = ref<Counts>(emptyCounts());