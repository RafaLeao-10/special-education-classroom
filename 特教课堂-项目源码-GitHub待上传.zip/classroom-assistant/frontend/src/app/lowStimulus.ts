// 低刺激模式：只负责把 html 的 data 属性设上/摘下，
// 视觉灰化由 styles/low-stimulus.css 的 html[data-low-stimulus] 规则完成。
export function applyLowStimulus(on: boolean) {
    const el = document.documentElement;
    if (on) {
      el.dataset.lowStimulus = "1";
    } else {
      // dataset 赋 undefined/null 会变成字符串，属性选择器照样匹配——必须真删属性
      el.removeAttribute("data-low-stimulus");
    }
  }