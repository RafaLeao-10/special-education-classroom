<script setup lang="ts">
import { ref, watch, onUnmounted } from "vue";
import Button from "../../components/Button.vue";
import ObservedAtField from "./ObservedAtField.vue";
import { localTimeInput, isoFromLocal } from "./recordTime";
import CountsFields from "./CountsFields.vue";
import { emptyCounts, describeCounts, promptOptions } from "./counts";
import {
  classroomApi,
  type ClassroomRecord,
  type RecordCorrection,
} from "../../api/services/classroom";
const props = defineProps<{
  record: ClassroomRecord;
  label: string;
  taskLabel: string;
}>();
const emit = defineEmits<{
  saved: [version: number];
  dirty: [value: boolean];
}>();
const editing = ref(false);
const observedAt = ref("");
let originalTime = "";
watch(editing, (value) => emit("dirty", value));
onUnmounted(() => emit("dirty", false));
const draft = ref("");
const counts = ref(emptyCounts());
const prompts = ref<ClassroomRecord["prompt_types"]>([]);
function edit() {
  draft.value = props.record.note;
  observedAt.value = localTimeInput(props.record.observed_at);
  originalTime = observedAt.value;
  counts.value = { ...(props.record.counts || emptyCounts()) };
  prompts.value = [...props.record.prompt_types];
  editing.value = true;
}
const busy = ref(false);
const error = ref("");
const history = ref<RecordCorrection[]>([]);
const showHistory = ref(false);
async function change(values: {
  note?: string;
  is_void?: boolean;
  observed_at?: string;
  counts?: ClassroomRecord["counts"];
  prompt_types?: ClassroomRecord["prompt_types"];
}) {
  busy.value = true;
  error.value = "";
  try {
    const result = await classroomApi.updateRecord(
      props.record.lesson_id,
      props.record.id,
      {
        expected_revision: props.record.revision,
        ...values,
      },
    );
    editing.value = false;
    showHistory.value = false;
    emit("saved", result.record_version);
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    busy.value = false;
  }
}
async function toggleHistory() {
  error.value = "";
  try {
    if (!showHistory.value)
      history.value = await classroomApi.history(
        props.record.lesson_id,
        props.record.id,
      );
    showHistory.value = !showHistory.value;
  } catch (e) {
    error.value = (e as Error).message;
  }
}
</script>
<template>
  <article
    :id="`record-${record.id}`"
    class="note-item"
    :class="{ 'void-record': record.is_void }"
  >
    <div class="record-meta">
      <time>{{
        new Date(record.observed_at).toLocaleString("zh-CN", { hour12: false })
      }}</time>
      <span>{{ label }} · {{ taskLabel }}</span
      ><span
        >修订 {{ record.revision
        }}<template v-if="record.is_void"> · 已作废</template></span
      >
    </div>
    <template v-if="editing">
      <el-input
        v-model="draft"
        type="textarea"
        :rows="3"
        aria-label="更正速记内容"
      />
      <template v-if="record.kind === 'observation'"
        ><CountsFields v-model="counts" /><el-select
          v-model="prompts"
          multiple
          aria-label="更正追加提示"
          ><el-option
            v-for="[value, label] in promptOptions"
            :key="value"
            :value="value"
            :label="label" /></el-select
      ></template>
      <ObservedAtField v-model="observedAt" label="更正发生时间" />
      <div class="report-actions">
        <Button
          variant="primary"
          :loading="busy"
          :disabled="
            record.kind === 'note'
              ? !draft.trim()
              : Object.values(counts).reduce((a, b) => a + b, 0) < 1
          "
          @click="
            change({
              note: draft.trim(),
              ...(observedAt !== originalTime
                ? {
                    observed_at: observedAt
                      ? isoFromLocal(observedAt)
                      : new Date().toISOString(),
                  }
                : {}),
              ...(record.kind === 'observation'
                ? { counts, prompt_types: prompts }
                : {}),
            })
          "
          >保存更正</Button
        >
        <Button variant="secondary" :disabled="busy" @click="editing = false">取消</Button>
      </div>
    </template>
    <template v-else
      ><p>{{ record.note || "观察计数记录" }}</p>
      <p v-if="record.counts" class="subtle">
        {{ describeCounts(record.counts) }}
      </p>
      <div class="record-actions">
        <Button
          v-if="!record.is_void"
          size="sm"
          variant="ghost"
          :disabled="busy"
          @click="edit"
          >{{ record.kind === "note" ? "更正文字" : "更正观察" }}</Button
        >
        <Button
          size="sm"
          variant="quiet"
          :loading="busy"
          @click="change({ is_void: !record.is_void })"
          >{{ record.is_void ? "恢复记录" : "作废" }}</Button
        >
        <Button
          v-if="record.revision > 1"
          size="sm"
          variant="ghost"
          @click="toggleHistory"
          >{{ showHistory ? "收起历史" : "更正历史" }}</Button
        >
      </div>
    </template>
    <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
    <div v-if="showHistory" class="record-history">
      <div v-for="item in history" :key="item.revision">
        <strong
          >修订 {{ item.revision }} ·
          {{ new Date(item.changed_at).toLocaleString("zh-CN") }}</strong
        >
        <p>
          修改前：{{
            new Date(item.before.observed_at).toLocaleString("zh-CN")
          }}
          · {{ describeCounts(item.before.counts) }} · {{ item.before.note
          }}{{ item.before.is_void ? "（作废）" : "" }}
        </p>
        <p>
          修改后：{{
            new Date(item.after.observed_at).toLocaleString("zh-CN")
          }}
          · {{ describeCounts(item.after.counts) }} · {{ item.after.note
          }}{{ item.after.is_void ? "（作废）" : "" }}
        </p>
      </div>
    </div>
  </article>
</template>
