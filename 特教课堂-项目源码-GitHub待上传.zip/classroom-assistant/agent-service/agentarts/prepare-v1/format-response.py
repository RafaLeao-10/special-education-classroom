def main(args: dict) -> dict:
    import json

    response = json.loads(args["raw_output"])
    result = response.get("result")
    if response.get("status") == "succeeded" and result and result.get("kind") == "plan":
        for activity in result["data"]["activities"]:
            for task in activity["tasks"]:
                # An omitted list means no declared citation, never an inferred source.
                task.setdefault("knowledge_refs", [])
    return {"result": json.dumps(response, ensure_ascii=False)}
