# 生成 PWA 图标：绿底 #466454 + 白色叶子（沿用 AppIcon 的 leaf 路径）
import os
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(__file__), "..", "frontend", "public", "icons")
os.makedirs(ROOT, exist_ok=True)

BG = (70, 100, 84)   # #466454
FG = (255, 255, 255) # 白

# AppIcon leaf 路径（24 坐标系）两段三次贝塞尔曲线围成叶形：
# M20 4C10 2 3 7 5 15c8 3 14-2 15-11Z
OUTLINE = [
    ((20, 4), (10, 2), (3, 7), (5, 15)),
    ((5, 15), (13, 18), (19, 13), (20, 4)),
]
VEINS = [((4, 21), (15, 10)), ((9, 15), (8, 10)), ((10, 15), (15, 16))]

def bezier(p0, p1, p2, p3, steps=80):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        u = 1 - t
        x = u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0]
        y = u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1]
        pts.append((x, y))
    return pts

def make(size, path):
    # maskable 安全区：图案只占中间 80%，四周留 10% 边距
    scale = size / 24 * 0.8
    off = size * 0.1
    img = Image.new("RGB", (size, size), BG)
    d = ImageDraw.Draw(img)
    outline = []
    for seg in OUTLINE:
        outline += bezier(*seg)
    outline = [(x * scale + off, y * scale + off) for x, y in outline]
    d.polygon(outline, fill=FG)
    stroke = max(2, round(size / 160))
    for (a, b) in VEINS:
        d.line(
            [(a[0] * scale + off, a[1] * scale + off),
            (b[0] * scale + off, b[1] * scale + off)],
            fill=BG, width=stroke,
        )
    img.save(path)
    print("saved", path)

make(192, os.path.join(ROOT, "icon-192.png"))
make(512, os.path.join(ROOT, "icon-512.png"))
make(180, os.path.join(ROOT, "apple-touch-icon.png"))