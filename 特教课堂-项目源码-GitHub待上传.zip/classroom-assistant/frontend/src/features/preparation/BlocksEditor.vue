<script setup lang="ts">
import type { components } from "../../api/generated/schema";
import AssetPicker from "../assets/AssetPicker.vue";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

type Blocks = components["schemas"]["Step"]["display_blocks"];
const props = withDefaults(
  defineProps<{ modelValue: Blocks; label?: string }>(),
  { label: "编辑教学资料（文字、图片、表格）" },
);
const emit = defineEmits<{ "update:modelValue": [value: Blocks] }>();
function change(work: (blocks: Blocks) => void) {
  const blocks: Blocks = JSON.parse(JSON.stringify(props.modelValue));
  work(blocks);
  emit("update:modelValue", blocks);
}
function add(type: "text" | "image" | "table") {
  if (type === "text") change((b) => b.push({ type, text: "" }));
  else if (type === "table")
    change((b) =>
      b.push({ type, headers: ["项目", "内容"], rows: [["", ""]] }),
    );
  else change((b) => b.push({ type, asset_id: "", alt: "" }));
}
</script>
<template>
  <details class="blocks-editor">
    <summary>{{ props.label }}</summary>
    <div v-for="(block, i) in modelValue" :key="i" class="block-editor">
      <el-input
        v-if="block.type === 'text'"
        :model-value="block.text"
        type="textarea"
        aria-label="教学资料文字"
        @update:model-value="
          change((b) => {
            if (b[i].type === 'text') b[i].text = $event;
          })
        "
      /><template v-else-if="block.type === 'image'"
        ><AssetPicker
          :model-value="block.asset_id || null"
          @update:model-value="
            change((b) => {
              if (b[i].type === 'image') b[i].asset_id = $event || '';
            })
          " /><el-input
          :model-value="block.alt"
          placeholder="图片说明"
          @update:model-value="
            change((b) => {
              if (b[i].type === 'image') b[i].alt = $event;
            })
          " /></template
      ><template v-else
        ><div class="material-row">
          <el-input
            v-for="(h, j) in block.headers"
            :key="j"
            :model-value="h"
            placeholder="表头"
            @update:model-value="
              change((b) => {
                if (b[i].type === 'table') b[i].headers[j] = $event;
              })
            "
          />
        </div>
        <div v-for="(row, j) in block.rows" :key="j" class="material-row">
          <el-input
            v-for="(cell, k) in row"
            :key="k"
            :model-value="cell"
            placeholder="单元格"
            @update:model-value="
              change((b) => {
                if (b[i].type === 'table') b[i].rows[j][k] = $event;
              })
            "
          /><Button
            size="sm"
            variant="quiet"
            @click="
              change((b) => {
                if (b[i].type === 'table') b[i].rows.splice(j, 1);
              })
            "
            >移除行</Button
          >
        </div>
        <ButtonGroup>
          <Button
            size="sm"
            variant="ghost"
            @click="
              change((b) => {
                if (b[i].type === 'table')
                  b[i].rows.push(b[i].headers.map(() => ''));
              })
            "
            >添加行</Button
          ><Button
            size="sm"
            variant="ghost"
            @click="
              change((b) => {
                const table = b[i];
                if (table.type === 'table') {
                  table.headers.push('新列');
                  table.rows.forEach((row) => row.push(''));
                }
              })
            "
            >添加列</Button
          ><Button
            size="sm"
            variant="quiet"
            :disabled="block.headers.length <= 1"
            @click="
              change((b) => {
                const table = b[i];
                if (table.type === 'table') {
                  table.headers.pop();
                  table.rows.forEach((row) => row.pop());
                }
              })
            "
            >移除末列</Button
          >
        </ButtonGroup>
          </template
      ><Button
        size="sm"
        variant="quiet"
        @click="change((b) => b.splice(i, 1))"
        >移除此内容块</Button
      >
    </div>
    <div class="report-actions">
      <Button size="sm" variant="ghost" @click="add('text')">添加文字</Button
      ><Button size="sm" variant="ghost" @click="add('image')">添加图片</Button
      ><Button size="sm" variant="ghost" @click="add('table')">添加表格</Button>
    </div>
  </details>
</template>
