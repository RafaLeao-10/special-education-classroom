import { client, unwrap } from "../client";
import type { components } from "../generated/schema";

export type AiJob = components["schemas"]["AiJob"];
type Schema = components["schemas"];
export type JobOperation = AiJob["operation"];
export type JobParams =
  | Schema["PrepareParams"]
  | Schema["AdjustParams"]
  | Schema["ReportParams"]
  | Schema["ReviseParams"];
export type Answer = Schema["Answer"];
export const jobsApi = {
  status: async () => unwrap(await client.GET("/api/v1/agent-status")),
  create: async (id: string, teacher_request: string) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/ai-jobs", {
        params: { path: { id } },
        body: {
          client_request_id: crypto.randomUUID(),
          operation: "prepare",
          params: { teacher_request },
        },
      }),
    ),
  submit: async (
    id: string,
    operation: JobOperation,
    params: JobParams,
    client_request_id: string = crypto.randomUUID(),
  ) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/ai-jobs", {
        params: { path: { id } },
        body: { client_request_id, operation, params } as
          | Schema["JobCreate"]
          | Schema["AdjustJobCreate"]
          | Schema["ReportJobCreate"]
          | Schema["ReviseJobCreate"],
      }),
    ),
  resume: async (job_id: string, body: Schema["JobResume"]) =>
    unwrap(
      await client.POST("/api/v1/ai-jobs/{job_id}/resume", {
        params: { path: { job_id } },
        body,
      }),
    ),
  retry: async (job_id: string, expected_revision: number) =>
    unwrap(
      await client.POST("/api/v1/ai-jobs/{job_id}/retry", {
        params: { path: { job_id } },
        body: { expected_revision },
      }),
    ),
  adjustments: async (id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/adjustments", {
        params: { path: { id } },
      }),
    ).items,
  list: async (id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/ai-jobs", {
        params: { path: { id } },
      }),
    ),
  get: async (job_id: string) =>
    unwrap(
      await client.GET("/api/v1/ai-jobs/{job_id}", {
        params: { path: { job_id } },
      }),
    ),
  apply: async (job_id: string) =>
    unwrap(
      await client.POST("/api/v1/ai-jobs/{job_id}/apply", {
        params: { path: { job_id } },
        body: {},
      }),
    ),
};
