<script setup lang="ts">
import { ref, watch } from "vue";
import { reportsApi } from "../../api/services/reports";
import AssetPicker from "../assets/AssetPicker.vue";
import Button from "../../components/Button.vue";
import type { LessonInput } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
const form = defineModel<LessonInput>({ required: true });
defineProps<{ students: Student[] }>();
const choices = ref<Awaited<ReturnType<typeof reportsApi.choices>>>([]);
const reportError = ref("");
watch(
  () => [...form.value.student_ids],
  async (ids) => {
    const key = ids.join();
    try {
      const items = ids.length ? await reportsApi.choices(ids) : [];
      if (form.value.student_ids.join() === key) {
        choices.value = items;
        reportError.value = "";
      }
    } catch (e) {
      reportError.value = (e as Error).message;
    }
  },
  { immediate: true },
);
function addMaterial() {
  form.value.available_materials.push({
    id: crypto.randomUUID(),
    name: "",
    quantity: null,
    asset_id: null,
  });
}
</script>
<template>
  <el-form label-position="top">
    <el-form-item label="课程标题">
      <el-input v-model="form.title" />
    </el-form-item>
    <el-form-item label="参加学生">
      <el-select
        v-model="form.student_ids"
        multiple
        placeholder="选择本课学生"
        style="width: 100%"
      >
        <el-option
          v-for="student in students"
          :key="student.id"
          :label="student.name"
          :value="student.id"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="参考前次报告（可选）"
      ><el-select
        v-model="form.previous_report_ids"
        multiple
        placeholder="先选择学生，再选择已确认报告"
        style="width: 100%"
        ><el-option
          v-for="report in choices"
          :key="report.id"
          :value="report.id"
          :label="`${report.lesson_title} · ${new Date(report.generated_at).toLocaleDateString('zh-CN')}`" /></el-select
    ></el-form-item>
    <p v-if="reportError" class="inline-error">{{ reportError }}</p>
    <p class="subtle">报告须已确认、未过期；本课需包含来源报告的参与学生。</p>
    <el-form-item label="课时（分钟）">
      <el-input-number
        v-model="form.planned_duration_min"
        :min="1"
        :precision="0"
      />
    </el-form-item>
    <h3>本次可用材料（可选）</h3>
    <div
      v-for="(material, index) in form.available_materials"
      :key="material.id || index"
      class="material-editor"
    >
      <div class="material-row">
        <el-input v-model="material.name" placeholder="材料名称" />
        <el-input
          :model-value="
            material.quantity == null ? '' : String(material.quantity)
          "
          @update:model-value="
            material.quantity = $event === '' ? null : Number($event)
          "
          type="number"
          min="0"
          step="1"
          placeholder="数量未知可留空"
        />
        <Button
          size="sm"
          variant="quiet"
          @click="form.available_materials.splice(index, 1)"
          >移除</Button
        >
      </div>
      <AssetPicker
        :model-value="material.asset_id ?? null"
        @update:model-value="material.asset_id = $event"
      />
    </div>
    <Button size="sm" variant="ghost" @click="addMaterial">添加材料</Button>
    <p class="subtle">
      没有指定材料也可以生成教案；需要时再添加。数量未知可留空，也可附上教学图片。
    </p>
  </el-form>
</template>
