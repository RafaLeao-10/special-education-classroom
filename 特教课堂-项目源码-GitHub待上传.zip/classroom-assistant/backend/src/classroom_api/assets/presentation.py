"""Convert classroom slides to a static PDF with the installed office application."""

import os
import shutil
import subprocess
from pathlib import Path

from classroom_api.errors import BusinessError


def convert(source: Path) -> Path:
    target = source.with_suffix(".pdf")
    office = shutil.which("soffice")
    if office:
        command = [office, "--headless", "--convert-to", "pdf", "--outdir", str(source.parent), str(source)]
    elif os.name == "nt":
        command = [
            "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-File", str(Path(__file__).with_name("export_presentation.ps1")),
            "-Source", str(source.resolve()), "-Target", str(target.resolve()),
        ]
    else:
        raise BusinessError(422, "PREVIEW_UNAVAILABLE", "当前环境没有课件转换组件，请先将课件导出为PDF上传")
    try:
        subprocess.run(
            command, check=True, timeout=120, capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        target.unlink(missing_ok=True)
        raise BusinessError(
            422, "PREVIEW_FAILED", "课件转换失败，请确认文件可以正常打开，或导出为PDF后上传"
        ) from exc
    if not target.is_file():
        raise BusinessError(422, "PREVIEW_FAILED", "未生成课件预览，请将课件导出为PDF后上传")
    return target
