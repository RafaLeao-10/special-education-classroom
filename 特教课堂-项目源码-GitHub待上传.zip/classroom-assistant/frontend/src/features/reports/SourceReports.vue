<script setup lang="ts">
import { ref, watch } from "vue";
import { reportsApi, type ClassroomReport } from "../../api/services/reports";
import Button from "../../components/Button.vue";
import AppIcon from "../../components/AppIcon.vue";

const props = defineProps<{ ids: string[] }>();
const reports = ref<ClassroomReport[]>([]);
const error = ref("");
watch(
  () => props.ids,
  async (ids) => {
    try {
      reports.value = await Promise.all(ids.map((id) => reportsApi.get(id)));
      error.value = "";
    } catch (e) {
      error.value = (e as Error).message;
    }
  },
  { immediate: true },
);
</script>
<template>
  <section v-if="ids.length">
    <h2>前次课堂的依据</h2>
    <p class="subtle">保留前次报告来源，供教师规划时参考。</p>
    <p v-if="error" class="inline-error">{{ error }}</p>
    <article v-for="report in reports" :key="report.id" class="source-report">
      <span class="status-pill"
        >{{ report.status === "confirmed" ? "已确认" : "草稿"
        }}{{ report.is_stale ? " · 记录已变化" : "" }}</span
      >
      <p>{{ report.content.overview }}</p>
      <ul>
        <li v-for="(item, i) in report.content.recommendations" :key="i">
          {{ item.action }}<small v-if="item.basis"> · {{ item.basis }}</small>
        </li>
      </ul>
      <Button :to="`/lessons/${report.lesson_id}/report`" variant="ghost" size="sm"
        >查看来源报告 <AppIcon name="arrow" :size="16" /></Button
      >
    </article>
  </section>
</template>
