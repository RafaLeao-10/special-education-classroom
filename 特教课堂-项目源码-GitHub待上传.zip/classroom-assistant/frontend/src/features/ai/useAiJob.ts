import { computed, onMounted, onScopeDispose, ref } from "vue";
import {
  jobsApi,
  type AiJob,
  type Answer,
  type JobOperation,
  type JobParams,
} from "../../api/services/jobs";
import { ApiError } from "../../api/client";
import { clearDraft, readDraft, writeDraft } from "../../app/drafts";

type Pending =
  | { kind: "create"; client_request_id: string; params: JobParams }
  | {
      kind: "resume";
      job_id: string;
      client_request_id: string;
      expected_revision: number;
      answers: Answer[];
    }
  | { kind: "retry"; job_id: string; expected_revision: number };

export function useAiJob(
  lessonId: string,
  operation: JobOperation = "prepare",
) {
  const scope = `ai-submit:${lessonId}:${operation}`;
  const pending = ref<Pending | null>(readDraft<Pending>(scope));
  const job = ref<AiJob | null>(null);
  const error = ref("");
  const submitting = ref(false);
  const applying = ref(false);
  const status = ref<Awaited<ReturnType<typeof jobsApi.status>>>();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let disposed = false;
  let polling = false;
  let failures = 0;
  const isActive = () =>
    ["queued", "running"].includes(job.value?.status || "");
  const running = computed(
    () => submitting.value || applying.value || isActive(),
  );
  const hasPending = computed(() => !!pending.value);
  const available = computed(
    () =>
      !!status.value?.configured &&
      (status.value.provider === "agentarts" || operation === "prepare"),
  );
  const serviceMessage = computed(() => {
    if (!status.value || status.value.provider === "unavailable")
      return "智能服务暂不可用，已保存任务仍可恢复查询。";
    if (status.value.provider === "mock")
      return operation === "prepare"
        ? "当前为演示备课；真实 Agent 待配置。"
        : "本功能需要真实 Agent，请完成实例部署与调用配置。";
    return status.value.configured
      ? "已连接智能服务。"
      : "真实 Agent 尚未配置调用地址与凭证。";
  });
  function storePending(value: Pending | null) {
    pending.value = value;
    if (value) writeDraft(scope, value);
    else clearDraft(scope);
  }
  function schedule(delay = 2000) {
    clearTimeout(timer);
    if (!disposed && isActive()) timer = setTimeout(pollJob, delay);
  }
  async function pollJob() {
    if (!job.value || disposed || polling) return;
    clearTimeout(timer);
    polling = true;
    try {
      const id = job.value.id;
      const current = await jobsApi.get(id);
      if (disposed || job.value?.id !== id) return;
      job.value = current;
      error.value = "";
      failures = 0;
      schedule();
    } catch (e) {
      if (disposed) return;
      error.value = (e as Error).message;
      if (!(e instanceof ApiError && [401, 404].includes(e.status)))
        schedule(Math.min(15000, 2000 * ++failures));
    } finally {
      polling = false;
    }
  }
  async function restore() {
    clearTimeout(timer);
    const results = await Promise.allSettled([
      jobsApi.status(),
      jobsApi.list(lessonId),
    ]);
    if (disposed) return;
    status.value =
      results[0].status === "fulfilled"
        ? results[0].value
        : { provider: "unavailable", configured: false };
    if (results[1].status === "rejected") {
      error.value = (results[1].reason as Error).message;
      schedule();
      return;
    }
    const candidates = results[1].value.items.filter(
      (item) => item.operation === operation,
    );
    const creating = pending.value?.kind === "create" ? pending.value : null;
    const submitted = creating
      ? candidates.find(
          (item) => item.client_request_id === creating.client_request_id,
        )
      : undefined;
    const found = submitted || candidates[0];
    if (submitted) storePending(null);
    try {
      job.value = found ? await jobsApi.get(found.id) : null;
      error.value = "";
      schedule();
    } catch (e) {
      error.value = (e as Error).message;
    }
  }
  async function execute(request: Pending) {
    if (submitting.value || applying.value || isActive()) return;
    submitting.value = true;
    error.value = "";
    storePending(request);
    try {
      if (request.kind === "create")
        job.value = await jobsApi.submit(
          lessonId,
          operation,
          request.params,
          request.client_request_id,
        );
      else if (request.kind === "resume")
        job.value = await jobsApi.resume(request.job_id, {
          client_request_id: request.client_request_id,
          expected_revision: request.expected_revision,
          answers: request.answers,
        });
      else
        job.value = await jobsApi.retry(
          request.job_id,
          request.expected_revision,
        );
      storePending(null);
      if (request.kind === "resume") clearDraft(`ai-answers:${request.job_id}`);
      await pollJob();
    } catch (e) {
      error.value = (e as Error).message;
      if (
        e instanceof ApiError &&
        e.status >= 400 &&
        e.status < 500 &&
        ![408, 429].includes(e.status)
      )
        storePending(null);
    } finally {
      submitting.value = false;
    }
  }
  async function start(params: JobParams) {
    if (pending.value) {
      error.value = "上次提交结果尚未确认，请先重新查询或重试上次提交。";
      return;
    }
    return execute({
      kind: "create",
      client_request_id: crypto.randomUUID(),
      params: JSON.parse(JSON.stringify(params)),
    });
  }
  const generate = (teacher_request: string) => start({ teacher_request });
  async function resume(answers: Answer[]) {
    if (!job.value || pending.value) {
      error.value = "请先确认上次提交结果，再提交补问回答。";
      return;
    }
    return execute({
      kind: "resume",
      job_id: job.value.id,
      expected_revision: job.value.revision,
      client_request_id: crypto.randomUUID(),
      answers: JSON.parse(JSON.stringify(answers)),
    });
  }
  async function retry() {
    if (pending.value) return execute(pending.value);
    if (job.value?.status === "failed")
      return execute({
        kind: "retry",
        job_id: job.value.id,
        expected_revision: job.value.revision,
      });
  }
  async function apply() {
    if (!job.value || running.value) return;
    applying.value = true;
    try {
      const result = await jobsApi.apply(job.value.id);
      job.value = { ...job.value, applied_resource: result.applied_resource };
      // A successful adoption remains successful even if the subsequent read is interrupted.
      try {
        job.value = await jobsApi.get(job.value.id);
      } catch {
        error.value = "结果已保存，重新查询可刷新当前状态。";
      }
      return result.applied_resource;
    } finally {
      applying.value = false;
    }
  }
  const online = () => {
    if (isActive()) void pollJob();
    else void restore();
  };
  onMounted(() => window.addEventListener("online", online));
  onScopeDispose(() => {
    disposed = true;
    clearTimeout(timer);
    window.removeEventListener("online", online);
  });
  return {
    job,
    error,
    running,
    available,
    serviceMessage,
    hasPending,
    generate,
    start,
    resume,
    retry,
    restore,
    apply,
    poll: restore,
  };
}
