@echo off
setlocal
cd /d "%~dp0"
where pnpm >nul 2>&1
if errorlevel 1 (
  echo pnpm not found. Install Node.js 24 and pnpm 10.28.2, then reopen this window.
  echo See README.md for setup instructions.
  pause
  exit /b 1
)
echo Keep this window open while using the platform. Press Ctrl+C to stop.
call pnpm setup:local
if errorlevel 1 (
  echo Startup failed. Check the messages above and README.md.
  pause
  exit /b 1
)
echo Platform stopped.
pause
