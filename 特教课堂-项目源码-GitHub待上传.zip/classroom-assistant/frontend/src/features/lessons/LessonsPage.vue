<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ElMessage } from "element-plus";
import { lessonsApi, type LessonInput } from "../../api/services/lessons";
import { studentsApi, type Student } from "../../api/services/students";
import LessonConditions from "./LessonConditions.vue";
import { reportsApi } from "../../api/services/reports";
import SourceReports from "../reports/SourceReports.vue";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
import catalog from "../../../../contracts/examples/catalog.json";
const router = useRouter();
const route = useRoute();
const list = ref<Awaited<ReturnType<typeof lessonsApi.list>>["items"]>([]);
const students = ref<Student[]>([]);
const busy = ref(false);
const entry = ref<"choose" | "existing" | "create">(typeof route.query.from_report === "string" ? "create" : "choose");
const examples = computed(() =>
  catalog.lessons.filter((example) =>
    list.value.some((lesson) => lesson.id === example.id),
  ),
);
const hasShowcase = computed(() =>
  list.value.some((lesson) => lesson.id === catalog.showcase.lesson_id),
);
const form = ref<LessonInput>({
  title: "",
  student_ids: [],
  planned_duration_min: 20,
  available_materials: [],
  previous_report_ids: [],
});
async function load() {
  try {
    [list.value, students.value] = await Promise.all([
      lessonsApi.list().then((r) => r.items),
      studentsApi.list().then((r) => r.items),
    ]);
  } catch (e) {
    ElMessage.error((e as Error).message);
  }
}
async function create() {
  if (
    !form.value.title.trim() ||
    !form.value.student_ids.length ||
    form.value.available_materials.some((m) => !m.name.trim())
  ) {
    ElMessage.warning("请填写标题、选择学生；已添加的材料需填写名称");
    return;
  }
  busy.value = true;
  try {
    const lesson = await lessonsApi.create(form.value);
    await router.push(`/lessons/${lesson.id}/prepare?mode=choose`);
  } catch (e) {
    ElMessage.error((e as Error).message);
  } finally {
    busy.value = false;
  }
}
onMounted(async () => {
  await load();
  const reportId = route.query.from_report;
  if (typeof reportId === "string") {
    try {
      const report = await reportsApi.get(reportId);
      if (report.status !== "confirmed" || report.is_stale)
        throw new Error("请先确认最新报告后再开始下一课");
      const previous = await lessonsApi.get(report.lesson_id);
      form.value = {
        title: `${previous.title} · 下一课`,
        student_ids: [...previous.student_ids],
        planned_duration_min: previous.planned_duration_min,
        available_materials: previous.available_materials.map((m) => ({
          ...m,
          id: crypto.randomUUID(),
        })),
        previous_report_ids: [report.id],
      };
    } catch (e) {
      ElMessage.error((e as Error).message);
    }
  }
});
</script>
<template>
  <div class="page-title">
    <div>
      <router-link to="/" class="back-link">← 返回工作台</router-link>
      <span class="stage-tag stage-sage">课前 · 备课</span>
      <h1>为下一堂课，做好准备</h1>
      <p class="page-description">
        选定学生，再选择知识板块和教学方式，让教案贴近孩子当下的需要。
      </p>
    </div>
    <span class="feature-emblem sage"><AppIcon name="book" :size="30" /></span>
  </div>
  <div class="workflow-strip">
    <span class="current">01 设置课堂条件</span><i /><span>02 选择知识板块与教学方式</span
    ><i /><span>03 生成与编辑教案</span>
  </div>
  <section v-if="entry === 'existing' && examples.length" class="curated-examples">
    <div class="section-heading compact">
      <div>
        <p class="eyebrow">完整教案示例</p>
        <h2>从一份完整教案开始</h2>
      </div>
      <Button v-if="hasShowcase" to="/showcase" variant="ghost" size="sm"
        >查看展示版 <AppIcon name="arrow" :size="16" /></Button
      >
    </div>
    <div class="curated-example-grid">
      <router-link
        v-for="example in examples"
        :key="example.id"
        :to="`/lessons/${example.id}/prepare?mode=existing`"
        class="curated-example-card"
      >
        <span class="subtle">{{ example.duration_min }} 分钟 · 三人小组</span>
        <h3>{{ example.title }}</h3>
        <p>{{ example.summary }}</p>
        <span class="curated-methods">{{ example.methods.join(" · ") }}</span
        ><span class="card-link-hint">查看完整教案 →</span>
      </router-link>
    </div>
  </section>
  <section v-if="entry === 'choose'" class="preparation-choices">
    <h2>选择备课方式</h2>
    <p class="subtle">选择一份已有教案，或新建课程并编写教案。</p>
    <div class="preparation-choice-grid">
      <button class="preparation-choice" type="button" @click="entry = 'existing'"><strong>使用已有教案</strong><span>查看已有教案，编辑后进入课堂</span><b>选择教案 →</b></button>
      <button class="preparation-choice" type="button" @click="entry = 'create'"><strong>生成教案</strong><span>创建课程，选择 Agent 生成或手动编写</span><b>新建课程 →</b></button>
    </div>
  </section>
  <div v-else class="preparation-single">
    <Button variant="ghost" size="sm" @click="entry = 'choose'">← 返回备课方式</Button>
    <section v-if="entry === 'existing'">
      <p class="eyebrow">已有备课</p>
      <h2>继续一份已有备课</h2>
      <el-empty v-if="!list.length" description="暂无课程" />
      <router-link
        v-for="lesson in list"
        :key="lesson.id"
        :to="`/lessons/${lesson.id}/${lesson.status === 'completed' ? 'report' : lesson.status === 'in_progress' ? 'classroom' : 'prepare?mode=existing'}`"
        class="list-row"
      >
        <strong>{{ lesson.title }}</strong>
        <span>
          {{
            {
              draft: "备课中",
              ready: "待上课",
              in_progress: "课堂中",
              completed: "已结束",
            }[lesson.status]
          }}
          ·
          {{ new Date(lesson.updated_at).toLocaleString() }}
        </span>
      </router-link>
    </section>
    <section v-if="entry === 'create'">
      <p class="eyebrow">新建课程</p>
      <h2>创建一堂新课</h2>
      <SourceReports :ids="form.previous_report_ids" /><LessonConditions
        v-model="form"
        :students="students"
      />
      <Button variant="primary" :loading="busy" @click="create">
        下一步，编写或生成教案
      </Button>
    </section>
  </div>
</template>
<style scoped>
.preparation-single { max-width: 1000px; margin: 0 auto; }
.preparation-choices { margin-top: 30px; }
.preparation-choice-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
.preparation-choice { display:flex; flex-direction:column; align-items:flex-start; gap:12px; padding:28px; text-align:left; border:1px solid var(--line); border-radius:14px; background:#f9fbf7; color:var(--ink); }
.preparation-choice strong { font-size:19px; } .preparation-choice span { color:var(--muted); } .preparation-choice b { color:var(--green); }
@media (max-width: 760px) { .preparation-choice-grid { grid-template-columns:1fr; } }
.curated-examples {
  margin: 30px 0 40px;
}
.curated-example-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 18px;
}
.curated-example-card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 26px;
  border: 1px solid var(--line);
  border-radius: 18px;
  background: linear-gradient(135deg, #fffefa, #eef2e7);
  text-decoration: none;
  color: inherit;
  transition:
    transform 0.2s,
    box-shadow 0.2s;
}
.curated-example-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 26px #52663e0c;
}
.curated-example-card h3 {
  margin: 0;
  font-size: 18px;
  font-weight: 500;
}
.curated-example-card p {
  margin: 0;
  color: var(--muted);
  font-size: 13px;
  line-height: 1.9;
}
.curated-methods {
  color: #829171;
  font-size: 11px;
}
.curated-example-card .card-link-hint {
  margin-top: auto;
  padding-top: 6px;
  font-size: 12px; /* 原 .text-link 的字号，类名换了要平移过来 */
}
@media (max-width: 760px) {
  .curated-example-grid {
    grid-template-columns: 1fr;
  }
}
</style>
