import secrets

from classroom_contracts.http import Empty, Envelope
from classroom_contracts.models import DisplayState
from classroom_contracts.teaching import DisplayLink
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from classroom_api.assets import service as assets
from classroom_api.auth.access import require_lesson
from classroom_api.db import get_db
from classroom_api.lessons import service as lessons

from .state import by_token, current, image_ids

router = APIRouter(tags=["display"])


@router.post(
    "/lessons/{id}/display-link", response_model=Envelope[DisplayLink], dependencies=[Depends(require_lesson)]
)
def link(id: str, body: Empty, db: Session = Depends(get_db)):
    lesson = lessons.get(db, id, lock=True)
    if not lesson.display_token:
        lesson.display_token = secrets.token_urlsafe(24)
        db.flush()
    return Envelope(data=DisplayLink(url=f"/display/{lesson.display_token}"))


@router.get("/display/{token}", response_model=Envelope[DisplayState])
def read(token: str, db: Session = Depends(get_db)):
    lesson = by_token(db, token)
    item = current(lesson)
    return Envelope(
        data=DisplayState(
            lesson_id=lesson.id,
            status=lesson.status,
            display_revision=lesson.execution["display_revision"],
            activity_title=item[0]["title"] if item else "",
            task_title=item[1]["title"] if item else "",
            step_order=item[2]["order"] if item and item[2] else 0,
            total_steps=len(item[1]["steps"]) if item and item[2] else 0,
            blocks=(
                item[2]["display_blocks"] if item[2] else [
                    b for step in item[1]["steps"] for b in step["display_blocks"]
                ]
            ) if item else [],
            assets=[assets.to_dto(assets.get(db, id), token) for id in sorted(image_ids(lesson))],
        )
    )
