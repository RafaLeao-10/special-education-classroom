import logging

from classroom_contracts.agent import AgentRequest, AgentResponse, PrepareRequest
from classroom_contracts.models import Error

from .providers.agentarts import AgentArtsProvider
from .providers.base import Provider
from .providers.mock import MockProvider
from .settings import Settings
from .tools.questions import validate_questions
from .tools.statistics import summarize

log = logging.getLogger(__name__)


class AgentService:
    def __init__(self, settings: Settings):
        self.provider: Provider = (
            MockProvider(settings) if settings.agent_provider == "mock" else AgentArtsProvider(settings)
        )
        self.is_mock = settings.agent_provider == "mock"

    async def prepare(self, request: PrepareRequest) -> AgentResponse:
        return await self.run(request)

    async def run(self, request: AgentRequest) -> AgentResponse:
        log.info("agent operation=%s request_id=%s", request.operation, request.request_id)
        if self.is_mock and request.operation != "prepare":
            return AgentResponse(
                contract_version="1.0",
                request_id=request.request_id,
                status="failed",
                questions=[],
                result=None,
                error=Error(
                    code="REAL_AGENT_REQUIRED",
                    message="教学内容同步、课堂调整与智能报告需要配置真实Agent服务",
                    fields=[],
                ),
            )
        response = await self.provider.generate(request)
        if response.status == "needs_input":
            try:
                validate_questions(request, response)
            except ValueError:
                return AgentResponse(
                    contract_version="1.0",
                    request_id=request.request_id,
                    status="failed",
                    questions=[],
                    result=None,
                    error=Error(
                        code="AGENT_QUESTION_INVALID",
                        message="补问与当前课堂资料不匹配，请重新生成",
                        fields=[],
                    ),
                )
        if response.status == "succeeded" and response.result.kind == "report":
            response.result.data.statistics = summarize(request.records)
        return response
