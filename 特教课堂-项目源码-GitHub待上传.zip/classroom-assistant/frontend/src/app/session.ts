import { ref } from "vue";
import { auth } from "../api/services/auth";
import type { components } from "../api/generated/schema";

export const currentUser = ref<components["schemas"]["User"] | null>(null);
export async function loadUser() {
  try {
    currentUser.value = (await auth.me()).user;
  } catch {
    currentUser.value = null;
  }
  return currentUser.value;
}
