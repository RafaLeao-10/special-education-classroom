"""Report archive queries, independent from report writing and lesson mutations."""

from classroom_contracts.http import LessonSummary
from classroom_contracts.planned import ReportArchive, ReportArchiveItem, ReportSummary
from sqlalchemy import func, or_, select

from classroom_api.errors import BusinessError
from classroom_api.lessons.models import LessonRow
from classroom_api.students.models import StudentRow

from .models import ReportRow


def search(
    db, query, student_id, status, is_stale, generated_from, generated_before, page, page_size, owner_id
):
    if generated_from and generated_before and generated_from >= generated_before:
        raise BusinessError(422, "INVALID_ARGUMENT", "结束日期应不早于开始日期")
    stale = or_(
        ReportRow.source_plan_version != LessonRow.plan_version,
        ReportRow.source_record_version != LessonRow.record_version,
    )
    filters = [LessonRow.owner_id == owner_id]
    if query.strip():
        filters.append(
            or_(
                LessonRow.title.icontains(query.strip(), autoescape=True),
                ReportRow.content["overview"].astext.icontains(query.strip(), autoescape=True),
            )
        )
    if student_id:
        filters.append(LessonRow.student_ids.contains([student_id]))
    if status:
        filters.append(ReportRow.status == status)
    if is_stale is not None:
        filters.append(stale if is_stale else ~stale)
    if generated_from:
        filters.append(ReportRow.generated_at >= generated_from)
    if generated_before:
        filters.append(ReportRow.generated_at < generated_before)
    joined = select(ReportRow, LessonRow).join(LessonRow, ReportRow.lesson_id == LessonRow.id).where(*filters)
    total = db.scalar(select(func.count()).select_from(joined.subquery()))
    rows = db.execute(
        joined.order_by(ReportRow.generated_at.desc(), ReportRow.id)
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()
    student_ids = {id for _, lesson in rows for id in lesson.student_ids}
    names = dict(
        db.execute(select(StudentRow.id, StudentRow.name).where(StudentRow.id.in_(student_ids))).all()
    )
    items = []
    for report, lesson in rows:
        values = {name: getattr(report, name) for name in ReportSummary.model_fields if name != "is_stale"}
        historical = {s["id"]: s["name"] for s in lesson.student_snapshots}
        items.append(
            ReportArchiveItem(
                **values,
                is_stale=(report.source_plan_version, report.source_record_version)
                != (lesson.plan_version, lesson.record_version),
                lesson_title=lesson.title,
                student_ids=lesson.student_ids,
                student_names=[historical.get(id, names.get(id, "学生")) for id in lesson.student_ids],
                overview=report.content["overview"],
            )
        )
    # Keep the existing entry for completed courses that have no report yet.
    pending = (
        select(LessonRow)
        .where(
            LessonRow.status == "completed",
            LessonRow.owner_id == owner_id,
            ~select(ReportRow.id).where(ReportRow.lesson_id == LessonRow.id).exists(),
        )
        .order_by(LessonRow.updated_at.desc())
    )
    unreported = [
        LessonSummary.model_validate({name: getattr(row, name) for name in LessonSummary.model_fields})
        for row in db.scalars(pending)
    ]
    return ReportArchive(
        items=items, total=total, page=page, page_size=page_size, unreported_lessons=unreported
    )
