from collections.abc import Generator

from fastapi import Request
from sqlalchemy.orm import DeclarativeBase, Session


class Base(DeclarativeBase):
    pass


def get_db(request: Request) -> Generator[Session, None, None]:
    """One transaction per request; domain functions flush, never commit."""
    with request.app.state.sessions.begin() as session:
        yield session
