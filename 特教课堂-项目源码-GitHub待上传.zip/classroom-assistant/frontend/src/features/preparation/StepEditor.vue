<script setup lang="ts">
import type { Step } from "./planDraft";
const step = defineModel<Step>({ required: true });
function instruction(text: string) {
  const blocks = step.value.display_blocks;
  const linked =
    blocks.length === 1 &&
    blocks[0].type === "text" &&
    blocks[0].text === step.value.instruction;
  step.value.instruction = text;
  if (linked) step.value.display_blocks = [{ type: "text", text }];
}
</script>
<template>
  <div class="step-editor">
    <label>教师指令</label
    ><el-input
      :model-value="step.instruction"
      @update:model-value="instruction"
      type="textarea"
      :rows="2"
      aria-label="教师指令"
      placeholder="这一步要对孩子说什么？"
    />
    <div class="editor-fields">
      <label
        >预期反应<el-input
          v-model="step.expected_response"
          aria-label="预期反应" /></label
      ><label
        >完成标准<el-input
          v-model="step.completion_criterion"
          aria-label="完成标准" /></label
      ><label
        >观察重点<el-input
          v-model="step.observation_focus"
          aria-label="观察重点" /></label
      ><label
        >示范说明<el-input v-model="step.demonstration" aria-label="示范说明"
      /></label>
    </div>
  </div>
</template>
