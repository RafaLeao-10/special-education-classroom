"""V1 shared vocabulary. Owners: A (business), B (teaching meaning)."""

from typing import Literal

CommunicationMode = Literal["speech", "gesture", "aac", "action", "other"]
LessonStatus = Literal["draft", "ready", "in_progress", "completed"]
Operation = Literal["prepare", "adjust", "report", "revise"]
JobStatus = Literal["queued", "running", "needs_input", "succeeded", "failed"]
TaskStatus = Literal["pending", "active", "done", "skipped"]
ActivityType = Literal["individual", "group", "routine"]
PracticeFormat = Literal["discrete_trial", "task_analysis", "naturalistic"]
RecordingUnit = Literal["task", "step"]
RecordKind = Literal["observation", "note"]
SupportType = Literal["visual_steps", "visual_schedule", "position_marker", "communication_board", "other"]
PromptType = Literal["verbal", "gestural", "model", "physical", "other"]
ResourceType = Literal["execution_sheet", "worksheet", "activity_steps", "record_sheet"]
AdjustmentAction = Literal[
    "simplify_instruction", "replace_material", "add_demonstration", "adjust_next_activity"
]
ReviewStatus = Literal["draft", "reviewed"]
SourceKind = Literal["research", "guide", "teacher_experience", "project_example"]
KnowledgeCategory = Literal[
    "method", "task_design", "instruction_support", "adjustment", "continuity", "report_spec"
]
ReportStatus = Literal["draft", "confirmed"]
