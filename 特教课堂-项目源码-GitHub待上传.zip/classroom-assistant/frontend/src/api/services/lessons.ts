import { client, unwrap } from "../client";
import type { components } from "../generated/schema";

export type Lesson = components["schemas"]["Lesson"];
export type LessonPlan = components["schemas"]["LessonPlan"];
export type LessonInput = components["schemas"]["LessonCreate"];
export const lessonsApi = {
  copy: async (id: string, body: components["schemas"]["LessonCopy"]) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/copies", {
        params: { path: { id } },
        body,
      }),
    ),
  list: async () => unwrap(await client.GET("/api/v1/lessons")),
  create: async (body: LessonInput) =>
    unwrap(await client.POST("/api/v1/lessons", { body })),
  get: async (id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}", { params: { path: { id } } }),
    ),
  update: async (id: string, body: components["schemas"]["LessonPatch"]) =>
    unwrap(
      await client.PATCH("/api/v1/lessons/{id}", {
        params: { path: { id } },
        body,
      }),
    ),
  savePlan: async (
    id: string,
    expected_plan_version: number,
    plan: LessonPlan,
  ) =>
    unwrap(
      await client.PUT("/api/v1/lessons/{id}/plan", {
        params: { path: { id } },
        body: { expected_plan_version, plan },
      }),
    ),
};
