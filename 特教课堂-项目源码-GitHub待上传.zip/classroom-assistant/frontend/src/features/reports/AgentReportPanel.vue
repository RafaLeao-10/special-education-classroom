<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import type { Lesson } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import type { Answer } from "../../api/services/jobs";
import { useAiJob } from "../ai/useAiJob";
import JobStatus from "../ai/JobStatus.vue";
import ReportEditor from "./ReportEditor.vue";
import StatisticsTable from "./StatisticsTable.vue";
import { readDraft, writeDraft } from "../../app/drafts";
import Button from "../../components/Button.vue";
const props = defineProps<{
  lesson: Lesson;
  students: Student[];
  disabled: boolean;
}>();
const emit = defineEmits<{ saved: [id: string]; contextChanged: [] }>();
const {
  job,
  error,
  running,
  available,
  serviceMessage,
  hasPending,
  retry,
  generate,
  resume,
  restore,
  apply,
  poll,
} = useAiJob(props.lesson.id, "report");
const scope = `report-request:${props.lesson.id}`;
const request = ref(readDraft<string>(scope) || "");
watch(request, (value) => writeDraft(scope, value));
const saving = ref(false);
const saveError = ref("");
const draft = computed(() =>
  job.value?.result?.kind === "report" ? job.value.result.data : null,
);
const stale = computed(
  () =>
    !!draft.value &&
    (job.value!.base_plan_version !== props.lesson.plan_version ||
      job.value!.base_record_version !== props.lesson.record_version),
);
async function answer(answers: Answer[]) {
  await resume(answers);
  emit("contextChanged");
}
async function save() {
  saving.value = true;
  saveError.value = "";
  try {
    const result = await apply();
    if (result?.type === "report") emit("saved", result.id);
  } catch (e) {
    saveError.value = (e as Error).message;
  } finally {
    saving.value = false;
  }
}
onMounted(async () => {
  try {
    await restore();
  } catch (e) {
    saveError.value = (e as Error).message;
  }
});
</script>
<template>
  <section class="agent-panel">
    <p class="eyebrow">智能报告</p>
    <h2>生成本课报告</h2>
    <p class="subtle">{{ serviceMessage }}</p>
    <p class="subtle">
      根据已保存的速记、观察计数与调整记录生成新报告。
    </p>
    <el-input
      v-model="request"
      type="textarea"
      :rows="2"
      placeholder="例如：重点回顾轮流参与和自主选择，并给出下一课建议。"
    />
    <Button
      variant="secondary"
      :loading="running"
      :disabled="disabled || !available || lesson.status !== 'completed'"
      @click="generate(request)"
      >根据课堂记录生成报告</Button
    >
    <JobStatus
      :job="job"
      :running="running"
      :error="error"
      :pending="hasPending"
      @retry="retry"
      @resume="answer"
      @poll="poll"
    />
    <div v-if="draft && !job?.applied_resource" class="agent-preview">
      <p v-if="stale" class="preview-notice">
        课堂记录已更新，请按最新记录重新生成，旧结果不会覆盖已保存报告。
      </p>
      <h3>候选报告 · 尚未保存</h3>
      <ReportEditor
        :model-value="draft.content"
        :lesson="lesson"
        :students="students"
        :disabled="true"
      />
      <StatisticsTable
        :rows="draft.statistics"
        :lesson="lesson"
        :students="students"
      />
      <p v-if="draft.references.length" class="subtle">
        引用：{{ draft.references.map((r) => r.source_title).join("；") }}
      </p>
      <Button
        variant="secondary"
        :loading="saving"
        :disabled="disabled || running || stale"
        @click="save"
        >采用并保存本轮报告</Button
      >
      <p class="subtle">
        保存后可继续编辑或确认归档。已确认且未过期的报告可用于下一课备课。
      </p>
    </div>
    <p v-if="saveError" class="inline-error" role="alert">{{ saveError }}</p>
  </section>
</template>
