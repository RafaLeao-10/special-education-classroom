<script setup lang="ts">
import type { Student } from "../../api/services/students";
import type { Lesson, LessonPlan } from "../../api/services/lessons";
import {
  type Task,
  newStep,
  reorder,
  normalizeOrder,
  syncTargets,
  communicationModes,
  practiceFormats,
} from "./planDraft";
import StepEditor from "./StepEditor.vue";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

const task = defineModel<Task>({ required: true });
const props = defineProps<{
  participants: string[];
  students: Student[];
  lesson: Lesson;
  plan: LessonPlan;
}>();
function move(index: number, delta: number) {
  reorder(task.value.steps, index, delta);
  normalizeOrder(task.value.steps);
}
function remove(index: number) {
  task.value.steps.splice(index, 1);
  normalizeOrder(task.value.steps);
}
</script>
<template>
  <div class="task-editor">
    <div class="editor-fields">
      <label
        >任务名称<el-input v-model="task.title" aria-label="任务名称" /></label
      ><label
        >练习形式<el-select v-model="task.practice_format" aria-label="练习形式"
          ><el-option
            v-for="[value, label] in practiceFormats"
            :key="value"
            :value="value"
            :label="label" /></el-select
      ></label>
    </div>
    <label
      >任务目标<el-input
        v-model="task.objective"
        type="textarea"
        :rows="2"
        aria-label="任务目标" /></label
    ><label
      >参与学生<el-select
        v-model="task.participant_ids"
        multiple
        aria-label="任务参与学生"
        @change="syncTargets(task, props.students)"
        ><el-option
          v-for="s in students.filter((s) => participants.includes(s.id))"
          :key="s.id"
          :value="s.id"
          :label="s.name" /></el-select
    ></label>
    <details class="editor-details">
      <summary>学生目标、回应与支持<span v-if="task.student_targets.some(t=>!t.goal_ids.length||!t.accepted_response_modes.length)"> · 有待选择项</span></summary>
      <div
        v-for="target in task.student_targets"
        :key="target.student_id"
        class="editor-target"
      >
        <h4>
          {{ students.find((s) => s.id === target.student_id)?.name || "学生" }}
        </h4>
        <label
          >本课目标<el-select
            v-model="target.goal_ids"
            multiple
            aria-label="学生教学目标"
            placeholder="选择已有目标"
            ><el-option
              v-for="g in students.find((s) => s.id === target.student_id)
                ?.goals || []"
              :key="g.id"
              :value="g.id"
              :label="g.description" /></el-select></label
        ><label
          >本次达成标准<el-input
            v-model="target.completion_criterion"
            aria-label="学生达成标准" /></label
        ><label
          >接受的回应方式<el-select
            v-model="target.accepted_response_modes"
            multiple
            aria-label="接受的回应方式"
            ><el-option
              v-for="[value, label] in communicationModes"
              :key="value"
              :value="value"
              :label="label" /></el-select></label
        ><label
          >既定常规支持<el-select
            v-model="target.routine_support_ids"
            multiple
            aria-label="常规支持"
            ><el-option
              v-for="s in plan.supports"
              :key="s.id"
              :value="s.id"
              :label="s.description || '未命名支持'" /></el-select></label
        ><label
          >个别调整说明<el-input
            v-model="target.adaptation_note"
            type="textarea"
        /></label>
      </div>
      <p class="subtle">
        可以先保存草稿，再补充学生目标和回应方式。
      </p>
    </details>
    <div class="editor-fields">
      <label
        >使用材料<el-select
          v-model="task.material_ids"
          multiple
          aria-label="任务使用材料"
          ><el-option
            v-for="m in lesson.available_materials"
            :key="m.id"
            :value="m.id"
            :label="m.name" /></el-select></label
      ><label
        >主要计数层级<el-select
          v-model="task.recording_unit"
          aria-label="主要计数层级"
          ><el-option value="step" label="按步骤" /><el-option
            value="task"
            label="按整个任务" /></el-select></label
      ><label
        >计划机会数（可空）<el-input :model-value="task.planned_opportunities==null?'':String(task.planned_opportunities)" @update:model-value="task.planned_opportunities=$event===''?null:Number($event)" type="number" min="1" step="1" placeholder="未知或未设定可留空" aria-label="计划机会数" /></label>
    </div>
    <label
      >教师准备<el-input
        v-model="task.teacher_preparation"
        type="textarea"
        :rows="2"
        aria-label="教师准备" /></label
    ><label
      >反馈方式<el-input
        v-model="task.feedback_guidance"
        type="textarea"
        :rows="2"
        aria-label="反馈方式"
    /></label>
    <div v-for="(step, i) in task.steps" :key="step.id" class="editor-step">
      <div class="editor-heading">
        <strong>步骤 {{ i + 1 }}</strong>
        <ButtonGroup>
          <Button
            size="sm"
            variant="ghost"
            :disabled="i === 0"
            @click="move(i, -1)"
            >上移步骤</Button
          ><Button
            size="sm"
            variant="ghost"
            :disabled="i === task.steps.length - 1"
            @click="move(i, 1)"
            >下移步骤</Button
          ><Button
            size="sm"
            variant="quiet"
            :disabled="task.steps.length === 1"
            @click="remove(i)"
            >移除步骤</Button
          >
        </ButtonGroup>
      </div>
      <StepEditor v-model="task.steps[i]" />
    </div>
    <Button
      size="sm"
      variant="secondary"
      @click="task.steps.push(newStep(task.steps.length + 1))"
      >添加步骤</Button
    >
    <label v-if="plan.references.length"
      >参考来源<el-select v-model="task.knowledge_refs" multiple
        ><el-option
          v-for="ref in plan.references"
          :key="ref.knowledge_id"
          :value="ref.knowledge_id"
          :label="ref.title || '未命名来源'" /></el-select
    ></label>
  </div>
</template>
