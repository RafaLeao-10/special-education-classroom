import { spawn, spawnSync } from "node:child_process";
import { createInterface } from "node:readline";
import { root } from "./process.mjs";

const definitions = [
  [
    "A",
    "uv",
    [
      "run",
      "--no-sync",
      "--package",
      "classroom-api",
      "uvicorn",
      "classroom_api.main:create_app",
      "--factory",
      "--host",
      "127.0.0.1",
      "--port",
      "8000",
    ],
  ],
  [
    "B",
    "uv",
    [
      "run",
      "--no-sync",
      "--package",
      "classroom-agent",
      "uvicorn",
      "classroom_agent.main:create_app",
      "--factory",
      "--host",
      "127.0.0.1",
      "--port",
      "8001",
    ],
  ],
  [
    "F",
    process.execPath,
    [process.env.npm_execpath, "--filter", "classroom-web", "dev"],
  ],
];
const children = [];
let stopping = false;
function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  process.exitCode = code;
  for (const child of children) {
    if (!child.pid) continue;
    if (process.platform === "win32")
      spawnSync("taskkill", ["/pid", String(child.pid), "/t", "/f"], {
        stdio: "ignore",
        windowsHide: true,
      });
    else {
      try {
        process.kill(-child.pid, "SIGTERM");
      } catch (error) {
        if (error.code !== "ESRCH") throw error;
      }
    }
  }
}
for (const [label, command, args] of definitions) {
  const child = spawn(command, args, {
    cwd: root,
    windowsHide: true,
    detached: true,
    stdio: ["ignore", "pipe", "pipe"],
  });
  children.push(child);
  for (const stream of [child.stdout, child.stderr]) {
    createInterface({ input: stream }).on("line", (line) =>
      console.log(`[${label}] ${line}`),
    );
  }
  child.on("error", (error) => {
    console.error(`[${label}] 启动失败：${error.message}`);
    stop(1);
  });
  child.on("exit", (code) => {
    if (!stopping) {
      console.error(
        `[${label}] 进程退出（${code}），停止其它模块；请检查该模块日志。`,
      );
      stop(code || 1);
    }
  });
}
process.on("SIGINT", () => stop());
process.on("SIGTERM", () => stop());
process.on("exit", () => stop(process.exitCode || 0));
