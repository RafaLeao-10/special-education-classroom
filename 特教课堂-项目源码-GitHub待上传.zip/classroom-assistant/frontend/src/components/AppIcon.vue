<script setup lang="ts">
withDefaults(defineProps<{ name: string; size?: number }>(), { size: 22 });
const paths: Record<string, string> = {
  leaf: "M20 4C10 2 3 7 5 15c8 3 14-2 15-11ZM4 21 15 10M9 15l-1-5m1 5 5 1",
  arrow: "M5 12h14m-6-6 6 6-6 6",
  book: "M12 5v15M3 4c4-1 7 0 9 2 2-2 5-3 9-2v15c-4-1-7 0-9 2-2-2-5-3-9-2Z",
  classroom: "M4 3h16v13H4ZM8 21l4-5 4 5M8 8h8m-8 4h5",
  report: "M6 3h9l4 4v14H6ZM14 3v5h5M9 12h7m-7 4h5",
  graph:
    "M12 7v4m-6 5 4-3m4 0 4 3M9 4a3 3 0 1 0 6 0 3 3 0 1 0-6 0ZM2 18a3 3 0 1 0 6 0 3 3 0 1 0-6 0Zm14 0a3 3 0 1 0 6 0 3 3 0 1 0-6 0Z",
  students:
    "M16 21v-3a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v3M5 6a4 4 0 1 0 8 0 4 4 0 1 0-8 0Zm12-3a4 4 0 0 1 0 8m2 3a4 4 0 0 1 3 4v3",
  spark:
    "m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5ZM20 2v4m-2-2h4",
  check: "m5 12 4 4L19 6",
  clock: "M12 8v5l3 2M2 12a10 10 0 1 0 20 0 10 10 0 1 0-20 0Z",
  mic: "M9 5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0ZM5 10v2a7 7 0 0 0 14 0v-2m-7 9v3m-4 0h8",
  edit: "m16 3 5 5L9 20l-6 1 1-6ZM13 6l5 5",
  plus: "M12 5v14M5 12h14",
  chevron: "m9 5 7 7-7 7",
  home: "m3 10 9-7 9 7v11h-6v-7H9v7H3Z",
  logout: "M9 4H4v16h5m5-13 5 5-5 5m-6-5h13",
  star: "m12 2.5 3 6.3 6.9.9-5 4.8 1.2 6.8-6.1-3.3-6.1 3.3 1.2-6.8-5-4.8 6.9-.9Z",
  volume:
    "M11 5 6 9H3v6h3l5 4V5ZM15.5 8.5a5 5 0 0 1 0 7m2.5-9a9 9 0 0 1 0 12",
  mute: "M11 5 6 9H3v6h3l5 4V5ZM22 9l-6 6m0-6 6 6",
  moon: "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z",
};
</script>
<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.5"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    <path :d="paths[name] || paths.book" />
  </svg>
</template>
