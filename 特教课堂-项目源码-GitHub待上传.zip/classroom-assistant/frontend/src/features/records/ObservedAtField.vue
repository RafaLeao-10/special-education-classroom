<script setup lang="ts">
import Button from "../../components/Button.vue";

const value = defineModel<string>({ required: true });
defineProps<{ label?: string }>();
</script>
<template>
  <div class="observed-at-field">
    <label
      >{{ label || "发生时间（可补录）"
      }}<input
        v-model="value"
        type="datetime-local"
        step="1"
        aria-label="记录发生时间" /></label
    ><Button v-if="value" size="sm" variant="quiet" @click="value = ''">使用保存时刻</Button>
    <p class="subtle">
      {{
        value
          ? "按填写的发生时间保存。"
          : "留空时使用本次保存时刻；补录时可选择实际发生时间。"
      }}
    </p>
  </div>
</template>
