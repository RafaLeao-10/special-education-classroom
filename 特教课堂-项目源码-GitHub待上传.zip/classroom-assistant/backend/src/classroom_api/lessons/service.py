from datetime import UTC, datetime
from uuid import uuid4

from classroom_api.assets.service import get as get_asset
from classroom_api.errors import BusinessError
from classroom_api.reports.queries import get_previous, validate_previous
from classroom_api.students.service import get_many
from classroom_contracts.http import LessonCreate, LessonPatch, PlanInput
from classroom_contracts.models import Lesson, LessonPlan
from sqlalchemy import select
from sqlalchemy.orm import Session

from .history import save_snapshot
from .models import LessonRow
from .validation import check_plan


def to_dto(row: LessonRow) -> Lesson:
    return Lesson.model_validate({name: getattr(row, name) for name in Lesson.model_fields})


def get(db: Session, id: str, *, lock: bool = False) -> LessonRow:
    query = select(LessonRow).where(LessonRow.id == id)
    row = db.scalar(query.with_for_update().execution_options(populate_existing=True) if lock else query)
    if row is None:
        raise BusinessError(404, "NOT_FOUND", "课程不存在")
    return row


def check_version(row: LessonRow, expected: int, states: tuple[str, ...] = ("draft",)):
    if row.status not in states:
        raise BusinessError(409, "INVALID_STATE", "当前课堂状态不允许修改备课内容")
    if row.plan_version != expected:
        raise BusinessError(409, "VERSION_CONFLICT", "课程已更新，请刷新后重试")


def normalize_materials(materials):
    result = [{**item.model_dump(), "id": item.id or str(uuid4())} for item in materials]
    if len({item["id"] for item in result}) != len(result):
        raise BusinessError(422, "INVALID_ARGUMENT", "材料ID不能重复", ["available_materials"])
    return result


def check_inputs(db: Session, body: LessonCreate, owner_id: str):
    from classroom_api.auth.access import require_reports, require_students

    require_students(db, body.student_ids, owner_id)
    require_reports(db, body.previous_report_ids, owner_id)
    get_many(db, body.student_ids)
    validate_previous(db, body.previous_report_ids, body.student_ids)
    for material in body.available_materials:
        if material.asset_id:
            get_asset(db, material.asset_id, owner_id=owner_id)


def create(db: Session, body: LessonCreate, owner_id: str) -> Lesson:
    check_inputs(db, body, owner_id)
    now = datetime.now(UTC)
    row = LessonRow(
        id=str(uuid4()),
        owner_id=owner_id,
        **body.model_dump(exclude={"available_materials"}),
        available_materials=normalize_materials(body.available_materials),
        student_snapshots=[],
        snapshot_origin="none",
        status="draft",
        plan=None,
        plan_version=0,
        record_version=0,
        execution={
            "task_states": [],
            "display_task_id": None,
            "display_step_id": None,
            "display_revision": 0,
        },
        created_at=now,
        updated_at=now,
    )
    db.add(row)
    db.flush()
    return to_dto(row)


def update(db: Session, id: str, body: LessonPatch) -> Lesson:
    row = get(db, id, lock=True)
    check_version(row, body.expected_plan_version, ("draft", "ready"))
    data = body.model_dump(exclude_unset=True, exclude={"expected_plan_version"})
    if "available_materials" in data:
        data["available_materials"] = normalize_materials(body.available_materials)
    candidate = Lesson.model_validate({**to_dto(row).model_dump(), **data})
    if row.status == "ready" and candidate.student_ids != row.student_ids:
        raise BusinessError(409, "INVALID_STATE", "已确认课程的参与学生固定，请新建课程")
    if id in {report.lesson_id for report in get_previous(db, candidate.previous_report_ids)}:
        raise BusinessError(422, "INVALID_ARGUMENT", "不能引用本课自己的报告")
    check_inputs(
        db,
        LessonCreate.model_validate(candidate.model_dump(include=set(LessonCreate.model_fields))),
        row.owner_id,
    )
    if candidate.plan:
        try:
            check_plan(candidate.plan, candidate, get_many(db, candidate.student_ids), allow_draft=True)
        except BusinessError as exc:
            raise BusinessError(
                409, "INVALID_STATE", "备课条件与教案不匹配，请调整学生、材料或活动后再保存", exc.fields
            ) from exc
    if "plan" in data:
        validate_assets(db, candidate.plan, candidate)
    for key, value in data.items():
        setattr(row, key, value)
    row.plan_version += 1
    row.status = "draft"
    row.updated_at = datetime.now(UTC)
    save_snapshot(db, row)
    db.flush()
    return to_dto(row)


def save_plan(
    db: Session, row: LessonRow, expected: int, plan: LessonPlan, *, allow_draft: bool = False
) -> Lesson:
    """Caller holds lesson row lock and owns commit (PUT or job apply)."""
    check_version(row, expected, ("draft", "ready"))
    check_plan(plan, to_dto(row), get_many(db, row.student_ids), allow_draft=allow_draft)
    validate_assets(db, plan, to_dto(row))
    row.plan = plan.model_dump(mode="json")
    row.plan_version += 1
    row.status = "draft"
    row.updated_at = datetime.now(UTC)
    save_snapshot(db, row)
    db.flush()
    return to_dto(row)


def validate_assets(db: Session, plan: LessonPlan, lesson: Lesson):
    blocks = [b for a in plan.activities for t in a.tasks for s in t.steps for b in s.display_blocks]
    blocks += [b for resource in plan.resources for b in resource.blocks]
    asset_ids = {b.asset_id for b in blocks if b.type == "image"}
    asset_ids.update(s.asset_id for s in plan.supports if s.asset_id)
    asset_ids.update(m.asset_id for m in lesson.available_materials if m.asset_id)
    owner_id = get(db, lesson.id).owner_id
    for asset_id in asset_ids:
        get_asset(db, asset_id, owner_id=owner_id)


def put_plan(db: Session, id: str, body: PlanInput) -> Lesson:
    return save_plan(db, get(db, id, lock=True), body.expected_plan_version, body.plan, allow_draft=True)
