// Teacher selections travel through the existing teacher_request contract.
export const knowledgeAreas = [
  { id: "academic", title: "学科知识", description: "生活语文、生活数学等学科内容。" },
  { id: "motor", title: "动作训练", description: "粗大动作、精细动作与生活操作。" },
  { id: "communication", title: "语言沟通", description: "理解、表达、对话与辅助沟通。" },
  { id: "reasoning", title: "逻辑思维", description: "分类、配对、排序与问题解决。" },
  { id: "arts", title: "艺术实践", description: "音乐、美术、律动与创作表达。" },
] as const;
export const trainingMethods = [
  { id: "inquiry", title: "观察与探究", description: "观察、比较与尝试，发现事物的联系。" },
  { id: "reading", title: "绘本与阅读", description: "通过共读、图片理解与故事交流学习。" },
  { id: "discussion", title: "情境对话与角色扮演", description: "在具体情境中表达、互动和解决问题。" },
  { id: "hands_on", title: "实物操作与实践", description: "通过操作、实验和创作理解知识。" },
  { id: "task_analysis", title: "任务分析教学", description: "围绕完整技能组织教学，按需提供拆步支持。" },
  { id: "discrete_trial", title: "短回合练习", description: "在清楚的提问与反馈中安排练习。" },
  { id: "naturalistic", title: "自然情境教学", description: "从真实场景和孩子的兴趣中创造学习机会。" },
  { id: "play", title: "游戏化教学", description: "把目标融入配对、轮流与合作游戏。" },
  { id: "routine", title: "生活情境教学", description: "围绕日常生活中的真实任务开展学习。" },
  { id: "modeling", title: "示范与模仿", description: "结合示范和尝试，按需要逐步减少提示。" },
] as const;
export function preparationRequest(
  methods: string[], supports: string[], request: string,
  areas: string[] = [], textbook = "",
) {
  return [
    areas.length ? `本课知识板块：${knowledgeAreas.filter(a => areas.includes(a.id)).map(a => a.title).join("、")}。围绕所选板块设计实质学习内容，不把所有内容改写成动作或物品归位训练。` : "",
    methods.length ? `教师选择的教学方式：${trainingMethods.filter(m => methods.includes(m.id)).map(m => m.title).join("、")}。结合学生目标落实教学方式，不只复述名称。` : "教学方式未限定，请结合所选知识板块和学生需要选择。",
    supports.length ? `教师希望使用的支持：${supports.join("、")}。` : "",
    textbook.trim() ? `教材参考：${textbook.trim()}。可结合培智系列教材的主题与学习顺序；只依据已提供或可核验的教材内容，不编造课文、页码、原文或引用。未提供正文时只作主题参考。` : "可参考培智系列教材的教学主题和生活化安排；未提供或检索到具体教材正文时，不声称已读取教材，不编造课名、页码或引用。",
    "可用材料为可选项；清单为空时优先设计无需专门器材的活动，不为材料为空发起必答补问，不把未提供的器材当成已有材料。",
    "每个任务默认提供完整的教学详细说明（组织、讲解或提问、回应、支持、反馈），不把每一个动作自动拆成指令。默认recording_unit=task；steps可用一条完整任务说明承载，拆分由教师在课堂逐任务开启后按需进行。",
    request.trim() ? `课堂具体描述：${request.trim()}` : "",
  ].filter(Boolean).join("\n");
}
