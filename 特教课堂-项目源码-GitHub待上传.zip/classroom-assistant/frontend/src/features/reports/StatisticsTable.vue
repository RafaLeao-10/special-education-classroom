<script setup lang="ts">
import { ref } from "vue";
import type { StatisticsRow } from "../../api/services/statistics";
import type { Lesson } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import { countFields } from "../records/counts";
import Button from "../../components/Button.vue";

const props = defineProps<{
  rows: StatisticsRow[];
  lesson: Lesson;
  students: Student[];
}>();
const evidence = ref<StatisticsRow>();
function subject(row: StatisticsRow) {
  return row.subject.type === "class"
    ? "整班"
    : row.subject.type === "group"
      ? props.lesson.plan?.groups.find((g) => g.id === row.subject.id)?.label ||
        "小组"
      : props.students.find((s) => s.id === row.subject.id)?.name || "学生";
}
function task(row: StatisticsRow) {
  const t = props.lesson.plan?.activities
    .flatMap((a) => a.tasks)
    .find((t) => t.id === row.task_id);
  return t?.title || "历史任务";
}
</script>
<template>
  <div class="statistics-table">
    <p class="subtle">
      仅汇总有效观察记录，按对象、任务、步骤和方案版本分别列出。小组不拆给个人；文字速记不计数。
    </p>
    <p v-if="!rows.length" class="subtle">
      尚无观察计数。
    </p>
    <div v-else class="table-scroll">
      <table>
        <thead>
          <tr>
            <th>对象与任务</th>
            <th v-for="[, label] in countFields" :key="label">{{ label }}</th>
            <th>已知结果</th>
            <th>完成次数</th>
            <th>依据</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, i) in rows" :key="i">
            <td>
              {{ subject(row) }}<br />{{ task(row)
              }}<small
                >方案 v{{ row.task_plan_version }} ·
                {{
                  row.step_id
                    ? `步骤 ${
                        lesson.plan?.activities
                          .flatMap((a) => a.tasks)
                          .flatMap((t) => t.steps)
                          .find((s) => s.id === row.step_id)?.order ||
                        "历史步骤"
                      }`
                    : "任务级"
                }}</small
              >
            </td>
            <td v-for="[key] in countFields" :key="key">
              {{ row.counts[key] }}
            </td>
            <td>{{ row.known_outcome_count }}</td>
            <td>{{ row.completed_count }}</td>
            <td>
              <Button
                variant="ghost"
                size="sm"
                @click="evidence = evidence === row ? undefined : row"
              >
                {{ row.record_ids.length }} 条记录
              </Button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="evidence" class="record-history">
      <strong>统计依据记录编号</strong>
      <p v-for="id in evidence.record_ids" :key="id">
        <a :href="`#record-${id}`">{{ id }}</a>
      </p>
    </div>
  </div>
</template>
