import type { ReportArchiveQuery } from "../../api/services/reports";
export function archiveFilters(
  query: string,
  studentId: string,
  status: string,
  from: string,
  to: string,
  page: number,
): ReportArchiveQuery {
  const filters: ReportArchiveQuery = {
    query,
    student_id: studentId || undefined,
    page,
    page_size: 12,
  };
  if (status === "stale") filters.is_stale = true;
  else if (status === "draft" || status === "confirmed")
    filters.status = status;
  if (from) filters.generated_from = new Date(`${from}T00:00:00`).toISOString();
  if (to) {
    const end = new Date(`${to}T00:00:00`);
    end.setDate(end.getDate() + 1);
    filters.generated_before = end.toISOString();
  }
  return filters;
}
