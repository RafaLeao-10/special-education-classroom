import { onUnmounted, ref } from "vue";
import { displayApi } from "../../api/services/display";

export function useDisplay(
token: string,
opts: { onRevision?: (rev: number) => void } = {},
) {
const state = ref<Awaited<ReturnType<typeof displayApi.state>>>();
const error = ref("");
let timer: ReturnType<typeof setInterval> | undefined;
let lastRevision: number | undefined;

async function poll() {
    if (document.hidden) return; // 后台标签页跳过，避免节流堆积
    try {
    const next = await displayApi.state(token);
    state.value = next;
    error.value = "";
    if (lastRevision !== undefined && next.display_revision !== lastRevision) {
        opts.onRevision?.(next.display_revision);
    }
    lastRevision = next.display_revision;
    } catch (e) {
    error.value = (e as Error).message;
    }
}

function onVisibility() {
    if (!document.hidden) poll(); // 回到前台立刻拉一次
}

poll();
timer = setInterval(poll, 2000);
document.addEventListener("visibilitychange", onVisibility);
onUnmounted(() => {
    clearInterval(timer);
    document.removeEventListener("visibilitychange", onVisibility);
});

return { state, error, poll };
}