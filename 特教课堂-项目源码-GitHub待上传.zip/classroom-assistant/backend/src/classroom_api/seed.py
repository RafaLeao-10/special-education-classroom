"""Idempotent local demo data. Never deletes or overwrites teachers' changes."""

import json

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from classroom_api.auth.models import UserRow
from classroom_api.auth.service import hash_password
from classroom_api.examples.service import create_examples
from classroom_api.settings import ROOT, Settings
from classroom_api.students.models import StudentRow

TEACHER_ID = "10000000-0000-4000-8000-000000000001"
LESSON_ID = "30000000-0000-4000-8000-000000000001"


def seed(db: Session, settings: Settings):
    teacher = db.scalar(select(UserRow).where(UserRow.username == settings.demo_username))
    if teacher is None:
        teacher = UserRow(
            id=TEACHER_ID,
            username=settings.demo_username,
            name="演示教师",
            password_hash=hash_password(settings.demo_password),
        )
        db.add(teacher)
        db.flush()
    fixtures = json.loads((ROOT / "contracts/fixtures/students.json").read_text(encoding="utf-8"))
    for student in fixtures:
        if db.get(StudentRow, student["id"]) is None:
            db.add(
                StudentRow(
                    id=student["id"],
                    owner_id=teacher.id,
                    name=student["name"],
                    revision=1,
                    details={
                        key: value for key, value in student.items() if key not in {"id", "name", "revision"}
                    },
                )
            )
    db.flush()
    create_examples(db, teacher.id)


def main():
    settings = Settings()
    engine = create_engine(settings.database_url, connect_args={"connect_timeout": 5})
    with Session(engine) as db, db.begin():
        seed(db, settings)
    engine.dispose()
    print("演示数据已就绪；重复运行不会新增相同数据。账号见根.env及README。")


if __name__ == "__main__":
    main()
