import { ref, watch, type Ref } from "vue";
import { displayGet, displaySet } from "./displayStore";

export function useTokenStars(
lessonId: Ref<string | undefined>,
goal: Ref<number>,
opts: { onCelebrate?: () => void } = {},
) {
const stars = ref(0);
const celebrating = ref(false);
let settleTimer: ReturnType<typeof setTimeout> | undefined;

function save() {
    const id = lessonId.value;
    if (id) displaySet(`stars:${id}`, stars.value);
}

function applyDelta(delta: number) {
    stars.value = Math.max(0, Math.min(goal.value, stars.value + delta));
    save();
    if (stars.value >= goal.value && goal.value > 0 && !celebrating.value) {
    celebrating.value = true;
    opts.onCelebrate?.();
    clearTimeout(settleTimer);
    settleTimer = setTimeout(() => {
        stars.value = 0;
        save();
        celebrating.value = false;
    }, 3500);
    }
}

function addByRevision(rev: number) {
    const id = lessonId.value;
    if (!id) return;
    const base = displayGet<number>(`revision:${id}`);
    if (base === null || base === undefined) {
    // 首次看到 revision：只记基准，不加星
    displaySet(`revision:${id}`, rev);
    return;
    }
    const delta = rev - base;
    if (delta > 0) applyDelta(delta);
    displaySet(`revision:${id}`, rev); // 不变或变小也更新基准
}

function manualAdd(delta: number) {
    if (celebrating.value) return;
    applyDelta(delta);
}

function reset() {
    stars.value = 0;
    save();
}

watch(lessonId, (id) => {
    stars.value = id ? (displayGet<number>(`stars:${id}`) ?? 0) : 0;
}, { immediate: true });

return { stars, celebrating, addByRevision, manualAdd, reset };
}