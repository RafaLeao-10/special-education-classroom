"""Curated lesson content and the presentation example."""
