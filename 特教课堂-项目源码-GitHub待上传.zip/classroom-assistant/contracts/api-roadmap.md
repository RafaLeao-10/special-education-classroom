# 接口与后续范围

更新日期：2026-10-28。本文描述当前源码和已知状态，不代表完成全工程验收。实际接口以 `contracts/generated/openapi.json` 和源码为准；云端部署及其验证以现有记录为准。

当前链路：F（Vue）→ A（FastAPI、PostgreSQL）→ B（Agent 服务）→ AgentArts。B 不访问业务数据库。课程规划、教学实施、记录与报告、教学统筹四个角色已配置；教师核对后再采用候选。一次虚构备课和历史教案修订有成功记录，不能推广为全链路通过。知识库已配置，检索曾出现鉴权错误，有效召回与引用尚未验证；备用生成的真实云端回退尚未验证。知识内容保留 draft，专业审核尚未完成。

当前课堂支持按任务显示详细说明，拆分指令由教师按任务选择；课件可在侧边作静态预览。儿童展示入口暂时隐藏。语音速记、新账号和服务器部署准备不计入本阶段交付。

已挂载 API 以 generated/openapi.json 为准，具体输入以 python/src/classroom_contracts 为准。LessonPatch 支持同时提交备课条件和 plan，由 A 在一个版本中校验保存。B 的操作包括 prepare、revise、adjust、report。planned 文件描述设计类型，不能仅凭名称断言已实现。
