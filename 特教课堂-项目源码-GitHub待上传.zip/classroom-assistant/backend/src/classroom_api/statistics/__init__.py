"""Read snapshots and call B deterministic tools through HTTP."""
