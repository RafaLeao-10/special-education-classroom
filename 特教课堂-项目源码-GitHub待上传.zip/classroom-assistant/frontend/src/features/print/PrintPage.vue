<script setup lang="ts">
import { ref, onMounted, computed } from "vue";
import { useRoute } from "vue-router";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import { reportsApi, type ClassroomReport } from "../../api/services/reports";
import PlanPreview from "../preparation/PlanPreview.vue";
import StatisticsTable from "../reports/StatisticsTable.vue";
import Button from "../../components/Button.vue";

const route = useRoute();
const lesson = ref<Lesson>();
const report = ref<ClassroomReport>();
const error = ref("");
const people = computed(() => lesson.value?.student_snapshots || []);
const mode = ref<"plan" | "steps">("plan");
const print = () => window.print();
onMounted(async () => {
  try {
    if (route.params.report_id) {
      report.value = await reportsApi.get(String(route.params.report_id));
      lesson.value = await lessonsApi.get(report.value.lesson_id);
    } else lesson.value = await lessonsApi.get(String(route.params.id));
  } catch (e) {
    error.value = (e as Error).message;
  }
});
function studentName(id: string) {
  return people.value.find((s) => s.id === id)?.name || id;
}
</script>
<template>
  <div class="print-toolbar">
    <router-link
      :to="
        lesson ? `/lessons/${lesson.id}/${report ? 'report' : 'prepare'}` : '/'
      "
      >← 返回</router-link
    ><template v-if="!report"
      ><Button variant="secondary" @click="mode = 'plan'">完整教案</Button
      ><Button variant="secondary" @click="mode = 'steps'">教学步骤单</Button></template
    ><Button variant="primary" @click="print">打印 / 保存 PDF</Button>
  </div>
  <p v-if="error" class="inline-error">{{ error }}</p>
  <article v-if="lesson" class="print-document">
    <p class="eyebrow">
      特教课堂辅助平台 ·
      {{ report ? "课堂报告" : mode === "steps" ? "教学步骤单" : "教师教案" }}
    </p>
    <h1>{{ lesson.title }}</h1>
    <p>
      参与学生：{{ people.map((s) => s.name).join("、") || "未保存历史姓名" }} ·
      教案 v{{ report?.source_plan_version || lesson.plan_version }}
    </p>
    <p v-if="lesson.snapshot_origin === 'migration'" class="subtle">
      档案描述为迁移时基线，此前未保存的历史描述不可还原。
    </p>
    <template v-if="report"
      ><p>
        {{ report.status === "confirmed" ? "已确认" : "草稿" }} ·
        {{ new Date(report.generated_at).toLocaleString("zh-CN") }} · 记录 v{{
          report.source_record_version
        }}
      </p>
      <p v-if="report.is_stale">
        本报告保存后课堂记录已有更正。
      </p>
      <h2>课堂概览</h2>
      <p class="preserve-lines">{{ report.content.overview }}</p>
      <template
        v-for="s in report.content.activity_summaries"
        :key="s.activity_id"
        ><h3>
          {{
            lesson.plan?.activities.find((a) => a.id === s.activity_id)
              ?.title || "活动回顾"
          }}
        </h3>
        <p>{{ s.text || "未填写" }}</p></template
      ><template
        v-for="s in report.content.student_summaries"
        :key="s.student_id"
        ><h3>{{ studentName(s.student_id) }}</h3>
        <p>{{ s.text || "未填写" }}</p></template
      ><template v-for="s in report.content.group_summaries" :key="s.group_id"
        ><h3>
          {{
            lesson.plan?.groups.find((g) => g.id === s.group_id)?.label ||
            "小组观察"
          }}
        </h3>
        <p>{{ s.text }}</p></template
      >
      <h2>观察统计</h2>
      <StatisticsTable
        :rows="report.statistics"
        :lesson="lesson"
        :students="people"
      />
      <h2>下一次教学建议</h2>
      <p v-for="(s, i) in report.content.recommendations" :key="i">
        {{ i + 1 }}. {{ s.action }}<br />依据：{{ s.basis || "未填写" }}
      </p>
      <template v-if="report.content.missing_information.length"
        ><h2>尚不确定的信息</h2>
        <p v-for="(s, i) in report.content.missing_information" :key="i">
          {{ s.description }}
        </p></template
      ></template
    ><PlanPreview
      v-else-if="mode === 'plan' && lesson.plan"
      :plan="lesson.plan"
      :students="people"
    /><template v-else-if="lesson.plan"
      ><div v-for="a in lesson.plan.activities" :key="a.id">
        <h2>{{ a.order }}. {{ a.title }}</h2>
        <div v-for="t in a.tasks" :key="t.id" class="print-task">
          <h3>{{ t.title }}</h3>
          <p>准备：{{ t.teacher_preparation }}</p>
          <ol>
            <li v-for="s in t.steps" :key="s.id">
              <strong>{{ s.instruction }}</strong>
              <p>
                观察：{{ s.observation_focus }}<br />完成标准：{{
                  s.completion_criterion
                }}
              </p>
            </li>
          </ol>
        </div>
      </div></template
    >
    <p v-else>尚未保存教案。</p>
  </article>
  <p v-else-if="!error">正在读取打印内容…</p>
</template>
