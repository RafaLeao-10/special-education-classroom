import type { Ref } from "vue";

export function useChime(enabled: Ref<boolean>) {
let ctx: AudioContext | null = null;
let unlocked = false;

function unlock() {
    // 必须在用户点击手势中调用，否则浏览器禁止出声
    if (!ctx) ctx = new AudioContext();
    void ctx.resume();
    unlocked = true;
}

function tone(freq: number, offset: number, dur: number, peak = 0.12) {
    if (!ctx) return;
    const t = ctx.currentTime + offset;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(peak, t + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gain).connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.05);
}

function play(kind: "step" | "star" | "goal" | "expire") {
    if (!enabled.value || !unlocked) return;
    if (kind === "step") tone(660, 0, 0.18);
    else if (kind === "star") {
    tone(784, 0, 0.15);
    tone(1046, 0.12, 0.2);
    } else if (kind === "goal") {
    // 集满代币：上行琶音
    tone(523, 0, 0.16);
    tone(659, 0.14, 0.16);
    tone(784, 0.28, 0.16);
    tone(1046, 0.42, 0.35);
    } else {
    // 倒计时结束：温和下行双音
    tone(392, 0, 0.22);
    tone(311, 0.18, 0.3);
    }
}

return { unlock, play };
}