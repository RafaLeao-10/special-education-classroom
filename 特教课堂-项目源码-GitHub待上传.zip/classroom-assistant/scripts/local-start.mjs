import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";
import { pnpm } from "./process.mjs";

async function ready() {
  const urls = ["http://127.0.0.1:8000/ready", "http://127.0.0.1:8001/health", "http://127.0.0.1:5173/"];
  const responses = await Promise.all(urls.map(async (url) => {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(2000) });
      return response.ok;
    } catch {
      return false;
    }
  }));
  return responses.every(Boolean);
}

async function main() {
  if (process.argv.includes("--setup")) {
    console.log("首次初始化：安装依赖并准备数据库。");
    await pnpm(["bootstrap"]);
    await pnpm(["db:up"]);
    await pnpm(["db:migrate"]);
    await pnpm(["db:seed"]);
    await pnpm(["contracts:generate"]);
  } else {
    console.log("正在启动本地数据库；首次使用请先运行 pnpm setup:local。");
    await pnpm(["db:up"]);
  }

  console.log("正在启动平台，请保持窗口打开。");
  let stopped = false;
  const running = pnpm(["dev"]).then(
    () => { stopped = true; return null; },
    (error) => { stopped = true; return error; },
  );
  const deadline = Date.now() + 120000;
  let available = false;
  while (!stopped && Date.now() < deadline) {
    if (await ready()) {
      available = true;
      break;
    }
    await delay(2000);
  }
  if (available && !stopped) {
    console.log("平台已就绪：http://127.0.0.1:5173/");
    if (process.platform === "win32") {
      const browser = spawn("cmd.exe", ["/c", "start", "", "http://127.0.0.1:5173/"], {
        detached: true, stdio: "ignore", windowsHide: true,
      });
      browser.on("error", () => console.log("请手动打开 http://127.0.0.1:5173/"));
      browser.unref();
    }
  } else if (!stopped) {
    console.log("服务仍在启动，请查看窗口日志，或稍后手动打开 http://127.0.0.1:5173/");
  }
  const error = await running;
  if (error) throw error;
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
