import { onUnmounted, ref } from "vue";

export function useCountdown(initialMin: number) {
const totalSec = ref(Math.max(1, Math.round(initialMin * 60)));
const remainingSec = ref(totalSec.value);
const expired = ref(false);
let endAt = 0;
let timer: ReturnType<typeof setInterval> | undefined;
let expiredCb: (() => void) | undefined;

function start(min: number) {
    totalSec.value = Math.max(1, Math.round(min * 60));
    endAt = Date.now() + totalSec.value * 1000;
    expired.value = false;
    tick();
}

function tick() {
    if (!endAt) return; // 还没开始计时
    const remain = Math.max(0, Math.round((endAt - Date.now()) / 1000));
    remainingSec.value = remain;
    if (remain <= 0 && !expired.value) {
    expired.value = true;
    expiredCb?.();
    }
}

function onExpired(cb: () => void) {
    expiredCb = cb;
}

timer = setInterval(tick, 250);
onUnmounted(() => clearInterval(timer));

return { totalSec, remainingSec, expired, start, onExpired };
}