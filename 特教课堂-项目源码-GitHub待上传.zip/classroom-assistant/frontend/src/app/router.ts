import { createRouter, createWebHistory } from "vue-router";
import { currentUser, loadUser } from "./session";

export const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/showcase",
      component: () => import("../features/showcase/ShowcasePage.vue"),
      meta: { standalone: true },
    },
    {
      path: "/lessons/:id/print",
      component: () => import("../features/print/PrintPage.vue"),
    },
    {
      path: "/reports/:report_id/print",
      component: () => import("../features/print/PrintPage.vue"),
    },
    { path: "/", component: () => import("../features/home/HomePage.vue") },
    {
      path: "/login",
      component: () => import("../features/auth/LoginPage.vue"),
    },
    {
      path: "/students",
      component: () => import("../features/students/StudentsPage.vue"),
    },
    {
      path: "/lessons",
      component: () => import("../features/lessons/LessonsPage.vue"),
    },
    {
      path: "/lessons/:id/prepare",
      component: () => import("../features/preparation/PreparePage.vue"),
    },
    {
      path: "/classroom",
      component: () => import("../features/classroom/ClassroomLibraryPage.vue"),
    },
    {
      path: "/reports",
      component: () => import("../features/reports/ReportsPage.vue"),
    },
    {
      path: "/lessons/:id/classroom",
      component: () => import("../features/classroom/ClassroomPage.vue"),
    },
    {
      path: "/lessons/:id/review",
      component: () => import("../features/classroom/LessonReviewPage.vue"),
    },
    {
      path: "/lessons/:id/report",
      component: () => import("../features/reports/ReportWorkspacePage.vue"),
    },
    {
      path: "/knowledge-graph",
      component: () =>
        import("../features/knowledge-graph/KnowledgeGraphPage.vue"),
      meta: { title: "教师学习图谱", owner: "F", public: true },
    },
    {
        path: "/display/:token",
        component: () => import("../features/display/DisplayPage.vue"),
        meta: { standalone: true, public: true },
    },
  ],
});
router.beforeEach(async (to) => {
  if (to.path === "/login" || to.meta.public) return;
  if (!currentUser.value && !(await loadUser())) return "/login";
});
