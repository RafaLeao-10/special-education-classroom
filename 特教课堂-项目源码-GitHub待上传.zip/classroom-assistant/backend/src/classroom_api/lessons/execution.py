"""Lesson lifecycle and teacher-controlled progress; never infer student performance."""

from datetime import UTC, datetime

from classroom_api.errors import BusinessError
from classroom_api.students.service import get_many
from classroom_contracts.models import ExecutionState, Lesson, Student
from classroom_contracts.planned import ExecutionPatch, ExecutionUpdated, LessonAction
from sqlalchemy.orm import Session

from . import service
from .history import save_snapshot
from .validation import check_plan


def act(db: Session, lesson_id: str, body: LessonAction) -> Lesson:
    row = service.get(db, lesson_id, lock=True)
    if row.plan_version != body.expected_plan_version:
        raise BusinessError(409, "VERSION_CONFLICT", "教案已更新，请重新读取后操作")
    destination = {"confirm_plan": "ready", "start": "in_progress", "complete": "completed"}[body.action]
    if row.status == destination:
        return service.to_dto(row)
    allowed = {"confirm_plan": "draft", "start": "ready", "complete": "in_progress"}
    if row.status != allowed[body.action]:
        raise BusinessError(409, "INVALID_STATE", "请按确认教案、开课、结课的顺序操作")
    if body.action == "confirm_plan":
        if row.plan is None:
            raise BusinessError(409, "INVALID_STATE", "请先保存教案")
        check_plan(
            service.to_dto(row).plan,
            service.to_dto(row),
            [Student.model_validate(s) for s in row.student_snapshots] or get_many(db, row.student_ids),
        )
        save_snapshot(db, row)
    elif body.action == "start":
        tasks = [task for activity in row.plan["activities"] for task in activity["tasks"]]
        row.execution = {
            "task_states": [
                {"task_id": task["id"], "status": "active" if i == 0 else "pending"}
                for i, task in enumerate(tasks)
            ],
            "display_task_id": tasks[0]["id"],
            "display_step_id": None,
            "split_task_ids": [],
            "display_revision": row.execution["display_revision"] + 1,
        }
        row.record_version += 1
    else:
        state = ExecutionState.model_validate(row.execution)
        for task in state.task_states:
            if task.status != "done":
                task.status = "skipped"
        state.display_task_id = state.display_step_id = None
        state.display_revision += 1
        row.execution = state.model_dump(mode="json")
        row.record_version += 1
    row.status = destination
    row.updated_at = datetime.now(UTC)
    db.flush()
    return service.to_dto(row)


def update(db: Session, lesson_id: str, body: ExecutionPatch) -> ExecutionUpdated:
    row = service.get(db, lesson_id, lock=True)
    if row.status != "in_progress":
        raise BusinessError(409, "INVALID_STATE", "仅上课期间可以修改课堂进度")
    if body.task_changes and body.expected_record_version != row.record_version:
        raise BusinessError(409, "VERSION_CONFLICT", "课堂进度已更新，请重新读取")
    tasks = {task["id"]: task for activity in row.plan["activities"] for task in activity["tasks"]}
    split_ids = (
        body.split_task_ids if body.split_task_ids is not None
        else row.execution.get("split_task_ids", [])
    )
    if len(split_ids) != len(set(split_ids)) or not set(split_ids) <= tasks.keys():
        raise BusinessError(422, "INVALID_ARGUMENT", "拆分开关包含无效任务")
    if body.display_task_id is None:
        valid_display = body.display_step_id is None
    else:
        task = tasks.get(body.display_task_id)
        valid_display = task is not None and (
            any(s["id"] == body.display_step_id for s in task["steps"])
            if body.display_task_id in split_ids else body.display_step_id is None
        )
    if not valid_display:
        raise BusinessError(422, "INVALID_ARGUMENT", "展示步骤不属于指定任务", ["display_step_id"])
    state = ExecutionState.model_validate(row.execution)
    state.split_task_ids = split_ids
    current = {item.task_id: item for item in state.task_states}
    if len({item.task_id for item in body.task_changes}) != len(body.task_changes):
        raise BusinessError(422, "INVALID_ARGUMENT", "同一次操作不能重复修改同一任务")
    transitions = {
        "pending": {"pending", "active", "skipped"},
        "active": {"active", "pending", "done"},
        "done": {"done"},
        "skipped": {"skipped"},
    }
    changed = False
    for item in body.task_changes:
        previous = current.get(item.task_id)
        if previous is None or item.status not in transitions[previous.status]:
            raise BusinessError(409, "INVALID_STATE", "任务状态变化无效，请重新读取课堂")
        changed |= previous.status != item.status
        previous.status = item.status
    if sum(item.status == "active" for item in current.values()) > 1:
        raise BusinessError(409, "INVALID_STATE", "同一时刻只能有一个进行中的任务")
    if (state.display_task_id, state.display_step_id) != (body.display_task_id, body.display_step_id):
        state.display_revision += 1
    state.display_task_id, state.display_step_id = body.display_task_id, body.display_step_id
    row.execution = state.model_dump(mode="json")
    if changed:
        row.record_version += 1
    row.updated_at = datetime.now(UTC)
    db.flush()
    return ExecutionUpdated(execution=state, record_version=row.record_version)
