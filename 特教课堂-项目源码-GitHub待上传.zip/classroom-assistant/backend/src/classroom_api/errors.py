from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException


class BusinessError(Exception):
    def __init__(self, status: int, code: str, message: str, fields: list[str] | None = None):
        self.status = status
        self.code = code
        self.message = message
        self.fields = fields or []


def install_handlers(app: FastAPI):
    @app.exception_handler(BusinessError)
    async def business_error(_request: Request, exc: BusinessError):
        return JSONResponse(
            status_code=exc.status,
            content={
                "data": None,
                "error": {"code": exc.code, "message": exc.message, "fields": exc.fields},
            },
        )

    @app.exception_handler(RequestValidationError)
    async def validation_error(_request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={
                "data": None,
                "error": {
                    "code": "INVALID_ARGUMENT",
                    "message": "输入格式不正确，请检查标注字段",
                    "fields": [".".join(map(str, error["loc"])) for error in exc.errors()],
                },
            },
        )

    @app.exception_handler(HTTPException)
    async def http_error(_request: Request, exc: HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "data": None,
                "error": {
                    "code": "NOT_FOUND" if exc.status_code == 404 else "HTTP_ERROR",
                    "message": str(exc.detail),
                    "fields": [],
                },
            },
        )
