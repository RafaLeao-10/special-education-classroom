import logging

import httpx
from classroom_contracts.agent import AgentRequest, AgentResponse
from classroom_contracts.models import Error
from pydantic import ValidationError

log = logging.getLogger(__name__)


def failure(id: str, code: str, message: str) -> AgentResponse:
    return AgentResponse(
        contract_version="1.0",
        request_id=id,
        status="failed",
        questions=[],
        result=None,
        error=Error(code=code, message=message, fields=[]),
    )


async def run(client: httpx.AsyncClient, request: AgentRequest) -> AgentResponse:
    log.info("agent request job_id=%s", request.request_id)
    try:
        response = await client.post("/internal/v1/agent-runs", json=request.model_dump(mode="json"))
        response.raise_for_status()
        result = AgentResponse.model_validate(response.json())
        if result.request_id != request.request_id:
            raise ValueError("响应标识不匹配")
        expected = {"prepare": "plan", "adjust": "adjustment", "report": "report", "revise": "plan_revision"}[
            request.operation
        ]
        if result.status == "succeeded" and result.result.kind != expected:
            raise ValueError("响应结果类型与请求不匹配")
        return result
    except httpx.TimeoutException:
        return failure(request.request_id, "AGENT_TIMEOUT", "智能服务响应超时，请重新发起生成")
    except httpx.HTTPError:
        return failure(request.request_id, "AGENT_UNAVAILABLE", "智能服务不可用，请检查B是否启动后重试")
    except (ValidationError, ValueError):
        return failure(request.request_id, "AGENT_OUTPUT_INVALID", "智能服务输出不符合当前操作的契约")
