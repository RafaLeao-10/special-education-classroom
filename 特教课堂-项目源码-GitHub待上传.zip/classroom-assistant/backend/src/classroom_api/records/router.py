from classroom_contracts.http import Envelope, Items
from classroom_contracts.models import Record
from classroom_contracts.planned import RecordCorrection, RecordCreate, RecordPatch, RecordSaved
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from classroom_api.auth.access import require_lesson
from classroom_api.auth.service import require_user
from classroom_api.db import get_db

from . import service
from .models import RecordCorrectionRow

router = APIRouter(prefix="/lessons/{id}/records", tags=["records"], dependencies=[Depends(require_lesson)])


@router.get("", response_model=Envelope[Items[Record]])
def listing(id: str, include_void: bool = False, db: Session = Depends(get_db)):
    return Envelope(data=Items(items=service.listing(db, id, include_void)))


@router.post("", status_code=201, response_model=Envelope[RecordSaved])
def create(id: str, body: RecordCreate, db: Session = Depends(get_db)):
    return Envelope(data=service.create(db, id, body))


@router.patch("/{record_id}", response_model=Envelope[RecordSaved])
def update(
    id: str, record_id: str, body: RecordPatch, db: Session = Depends(get_db), user=Depends(require_user)
):
    return Envelope(data=service.update(db, id, record_id, body, user.id))


@router.get("/{record_id}/history", response_model=Envelope[Items[RecordCorrection]])
def history(id: str, record_id: str, db: Session = Depends(get_db)):
    service.get(db, id, record_id)
    rows = db.scalars(
        select(RecordCorrectionRow)
        .where(RecordCorrectionRow.record_id == record_id)
        .order_by(RecordCorrectionRow.revision)
    )
    return Envelope(
        data=Items(
            items=[
                RecordCorrection(
                    revision=r.revision,
                    before=r.before,
                    after=r.after,
                    changed_at=r.changed_at,
                    changed_by=r.changed_by,
                )
                for r in rows
            ]
        )
    )
