"""AgentArts code node: query (original request JSON) -> retrieval_query.

Keep the original query wired to the role agents; this output is only for retrieval.
"""


def main(args: dict) -> dict:
    import json

    request = json.loads(args["query"])
    operation = request["operation"]
    lesson = request["lesson"]
    params = request["params"]
    role_query = {
        "prepare": "课程规划 教学任务设计",
        "adjust": "课中教学调整 " + params.get("action", ""),
        "revise": "教案修改 教学步骤与配套资料同步",
        "report": "课堂记录 证据与补问 教学报告 下一课建议",
    }[operation]
    parts = [role_query, params["teacher_request"][:450], lesson["title"][:100]]
    if operation == "prepare":
        goals = [goal["description"] for student in request["students"] for goal in student["goals"]]
        supports = [support for student in request["students"] for support in student["usual_supports"]]
        parts.extend(["；".join(goals)[:300], "；".join(supports)[:200]])
    elif operation in ("adjust", "revise") and lesson.get("plan"):
        target_ids = (
            params["target_task_ids"] if operation == "adjust" else request["scope"]["affected_task_ids"]
        )
        tasks = [
            task
            for activity in lesson["plan"]["activities"]
            for task in activity["tasks"]
            if task["id"] in target_ids
        ]
        methods = {"task_analysis": "任务分析", "discrete_trial": "离散试次", "naturalistic": "自然情境"}
        parts.append(
            "；".join(
                f'{task["title"]} {task["objective"]} {methods[task["practice_format"]]}' for task in tasks
            )[:500]
        )
    return {"retrieval_query": "\n".join(part for part in parts if part)}
