<script setup lang="ts">
import type { LessonPlan } from "../../api/services/lessons";
import AppIcon from "../../components/AppIcon.vue";
import { ElMessageBox } from "element-plus";
import Button from "../../components/Button.vue";

type Activity = LessonPlan["activities"][number];
type Task = Activity["tasks"][number];
defineProps<{
  activity: Activity;
  task: Task;
  step: Task["steps"][number];
  index: number;
  total: number;
  status: string;
  busy: boolean;
  split: boolean;
}>();
const emit = defineEmits<{
  previous: [];
  next: [];
  activate: [];
  complete: [];
  split: [enabled: boolean];
  skip: [];
}>();
async function confirmSkip() {
  try {
    await ElMessageBox.confirm(
      "跳过当前任务后，将直接进入下一项。是否继续？",
      "跳过任务",
      { confirmButtonText: "跳过", cancelButtonText: "再想想", type: "warning" },
    );
    emit("skip");
  } catch {
    /* 点“再想想”或关闭弹窗：什么都不做 */
  }
}
const labels: Record<string, string> = {
  pending: "尚未开始",
  active: "正在教学",
  done: "任务已结束",
  skipped: "已跳过",
};
</script>
<template>
  <section class="focus-task">
    <div class="focus-top">
      <span class="status-pill">{{ labels[status] }}</span
      ><span class="subtle">{{ index + 1 }} / {{ total }} 个教学节点</span>
    </div>
    <p class="eyebrow">{{ activity.title }}</p>
    <h2>{{ task.title }}</h2>
    <p class="task-objective">{{ task.objective }}</p>
    <el-switch v-click-blur :model-value="split" :disabled="busy" active-text="拆分指令"
      aria-label="当前任务拆分指令" @update:model-value="$emit('split', Boolean($event))" />
    <p class="subtle">关闭时查看任务详细说明；打开后逐条查看指令，也可按需要生成更细的拆分建议。</p>
    <template v-if="split">
    <div class="instruction-block">
      <span>现在，对孩子说</span>
      <p>“{{ step.instruction }}”</p>
    </div>
    <div class="observation-grid">
      <div>
        <span>期待的反应</span>
        <p>{{ step.expected_response }}</p>
      </div>
      <div>
        <span>完成的标准</span>
        <p>{{ step.completion_criterion }}</p>
      </div>
      <div>
        <span>留意什么</span>
        <p>{{ step.observation_focus }}</p>
      </div>
      <div>
        <span>需要时这样示范</span>
        <p>{{ step.demonstration || "按孩子的需要提供支持" }}</p>
      </div>
    </div>
    </template>
    <div v-else class="task-detail">
      <h3>教学详细说明</h3>
      <p v-if="task.teacher_preparation"><strong>课前准备：</strong>{{ task.teacher_preparation }}</p>
      <article v-for="detail in task.steps" :key="detail.id">
        <p>{{ detail.instruction }}</p>
        <p v-if="detail.expected_response"><strong>学生回应：</strong>{{ detail.expected_response }}</p>
        <p v-if="detail.completion_criterion"><strong>完成标准：</strong>{{ detail.completion_criterion }}</p>
        <p v-if="detail.observation_focus"><strong>观察重点：</strong>{{ detail.observation_focus }}</p>
        <p v-if="detail.demonstration"><strong>需要时示范：</strong>{{ detail.demonstration }}</p>
      </article>
    </div>
    <div class="feedback-note">
      <AppIcon name="spark" :size="18" />
      <p>{{ task.feedback_guidance }}</p>
    </div>
    <div class="task-navigation">
      <Button
        v-click-blur
        variant="secondary"
        :disabled="busy || index === 0"
        @click="$emit('previous')"
        >上一项</Button
      >
      <span class="subtle">切换教学内容不记录学生完成次数</span>
      <Button
        v-click-blur
        variant="secondary"
        class="btn-arrow"
        :disabled="busy || index === total - 1"
        @click="$emit('next')"
        >下一项 <AppIcon name="arrow" :size="16"
      /></Button>
    </div>
    <div class="task-progress-actions">
      <Button
        v-click-blur
        v-if="status === 'pending'"
        variant="primary"
        :loading="busy"
        @click="$emit('activate')"
        >开始当前任务</Button
      >
      <Button
        v-click-blur
        v-if="status === 'pending'"
        variant="quiet"
        :disabled="busy"
        @click="confirmSkip"
        >跳过此任务</Button
      >
      <Button
        v-click-blur
        v-if="status === 'active'"
        variant="primary"
        :loading="busy"
        @click="$emit('complete')"
        >结束当前任务并继续</Button
      >
      <span class="subtle">此处只标记教学进度，具体表现请另存速记。</span>
    </div>
  </section>
</template>
