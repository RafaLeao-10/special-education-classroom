"""Export design-only APIs separately; never register these with FastAPI."""

from classroom_contracts.http import Envelope
from classroom_contracts.planned import (
    Transcription,
)
from pydantic import BaseModel


def planned_openapi():
    schemas = {}

    def schema_ref(model: type[BaseModel]):
        schema = model.model_json_schema(ref_template="#/components/schemas/{model}")
        schemas.update(schema.pop("$defs", {}))
        schemas[model.__name__] = schema
        return {"$ref": f"#/components/schemas/{model.__name__}"}

    endpoints = [
        ("/transcriptions", "post", "transcribeAudio", None, Envelope[Transcription]),
    ]
    paths = {}
    for path, method, name, request, response in endpoints:
        operation = {
            "operationId": name,
            "summary": f"设计预留，未实现：{name}",
            "x-implementation-status": "planned",
            "parameters": [
                {"name": part[1:-1], "in": "path", "required": True, "schema": {"type": "string"}}
                for part in path.split("/")
                if part.startswith("{")
            ],
            "responses": {
                "200": {
                    "description": "预留成功响应；当前服务不提供此能力",
                    "content": {"application/json": {"schema": schema_ref(response)}},
                }
            },
        }
        if request:
            operation["requestBody"] = {
                "required": True,
                "content": {"application/json": {"schema": schema_ref(request)}},
            }
        if path == "/transcriptions":
            operation["requestBody"] = {
                "required": True,
                "content": {
                    "multipart/form-data": {
                        "schema": {
                            "type": "object",
                            "required": ["file"],
                            "properties": {
                                "file": {"type": "string", "format": "binary"},
                                "language": {"type": "string", "default": "zh"},
                            },
                        },
                    }
                },
            }
        if name == "createReportJob":
            operation["responses"]["202"] = operation["responses"].pop("200")
        paths.setdefault(f"/api/v1{path}", {})[method] = operation
    return {
        "openapi": "3.1.0",
        "info": {"title": "Classroom design-only contracts (NOT IMPLEMENTED)", "version": "1.0-planned"},
        "paths": paths,
        "components": {"schemas": schemas},
    }
