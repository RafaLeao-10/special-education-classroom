<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import {
classroomApi,
type ClassroomRecord,
} from "../../api/services/classroom";

const props = defineProps<{ lessonId: string }>();

const records = ref<ClassroomRecord[]>([]);
const loading = ref(true);
const error = ref("");

// 三条序列：颜色是平台既有的记录类别色（与统计表一致）
const SERIES = [
{ key: "independent", title: "独立完成", color: "#466454" },
{ key: "prompted", title: "提示后完成", color: "#96794a" },
{ key: "not_completed", title: "未完成", color: "#b3564f" },
] as const;

// 图例开关：隐藏哪条序列
const visible = ref<Record<string, boolean>>({
independent: true,
prompted: true,
not_completed: true,
});

type Point = {
x: number; // 毫秒时间戳（桶中点）
label: string;
independent: number;
prompted: number;
not_completed: number;
};

function fmt(t: number) {
return new Date(t).toLocaleTimeString("zh-CN", {
    hour: "2-digit",
    minute: "2-digit",
});
}

const points = computed<Point[]>(() => {
const pts = records.value
    .filter((r) => r.counts && r.observed_at)
    .map((r) => ({ t: new Date(r.observed_at).getTime(), counts: r.counts! }))
    .sort((a, b) => a.t - b.t);
if (!pts.length) return [];
// 桶数 = min(8, 记录数)：记录少时一桶一条，多时按时间均分
const n = Math.min(8, pts.length);
if (n === pts.length) {
    return pts.map((p) => ({
    x: p.t,
    label: fmt(p.t),
    independent: p.counts.independent,
    prompted: p.counts.prompted,
    not_completed: p.counts.not_completed,
    }));
}
const span = pts[pts.length - 1].t - pts[0].t;
const width = span / n;
const out: Point[] = [];
for (let i = 0; i < n; i++) {
    const from = pts[0].t + i * width;
    const to = i === n - 1 ? Infinity : from + width;
    const bucket = pts.filter((p) => p.t >= from && p.t < to);
    const mid = from + width / 2;
    out.push({
    x: mid,
    label: fmt(mid),
    independent: bucket.reduce((s, p) => s + p.counts.independent, 0),
    prompted: bucket.reduce((s, p) => s + p.counts.prompted, 0),
    not_completed: bucket.reduce((s, p) => s + p.counts.not_completed, 0),
    });
}
return out;
});

// 几何：SVG viewBox 600×240，四周留边
const W = 600;
const H = 240;
const PAD = { top: 16, right: 16, bottom: 30, left: 36 };
const innerW = W - PAD.left - PAD.right;
const innerH = H - PAD.top - PAD.bottom;

const maxValue = computed(() => {
let m = 1;
for (const p of points.value) {
    m = Math.max(m, p.independent, p.prompted, p.not_completed);
}
// 向上取整到 2 的倍数，网格刻度干净
return Math.ceil(m / 2) * 2;
});

function xOf(p: Point) {
const first = points.value[0].x;
const last = points.value[points.value.length - 1].x;
const span = last - first || 1;
// 单条记录时居中而不是贴左
if (points.value.length === 1) return PAD.left + innerW / 2;
return PAD.left + ((p.x - first) / span) * innerW;
}

function yOf(v: number) {
return PAD.top + innerH - (v / maxValue.value) * innerH;
}

const gridLines = computed(() => {
const step = maxValue.value / 4;
const lines: { y: number; value: number }[] = [];
for (let i = 0; i <= 4; i++) {
    lines.push({ y: yOf(i * step), value: i * step });
}
return lines;
});

function polyPoints(series: (typeof SERIES)[number]) {
return points.value
    .map((p) => `${xOf(p).toFixed(1)},${yOf(p[series.key]).toFixed(1)}`)
    .join(" ");
}

async function load() {
loading.value = true;
error.value = "";
try {
    records.value = await classroomApi.records(props.lessonId);
} catch (e) {
    error.value = (e as Error).message;
} finally {
    loading.value = false;
}
}
onMounted(load);
</script>

<template>
<p v-if="loading" class="subtle">正在读取行为记录…</p>
<p v-else-if="error" role="alert" class="inline-error">{{ error }}</p>
<p v-else-if="!points.length" class="subtle">
    还没有带计数的观察记录，趋势图暂无数据。
</p>
<div v-else class="trend-chart">
    <div class="trend-legend">
    <el-checkbox
        v-for="s in SERIES"
        :key="s.key"
        :model-value="visible[s.key]"
        @update:model-value="visible[s.key] = Boolean($event)"
    >
        <span class="trend-dot" :style="{ background: s.color }" />{{
        s.title
        }}
    </el-checkbox>
    </div>
    <svg
    viewBox="0 0 600 240"
    role="img"
    :aria-label="`行为计数趋势：${SERIES.map((s) => `${s.title}共${points.length}个时间点`).join('，')}`"
    >
    <!-- y 网格与刻度 -->
    <g v-for="line in gridLines" :key="line.y">
        <line
        :x1="PAD.left"
        :x2="W - PAD.right"
        :y1="line.y"
        :y2="line.y"
        class="trend-grid"
        />
        <text
        :x="PAD.left - 8"
        :y="line.y + 4"
        text-anchor="end"
        class="trend-axis-text"
        >
        {{ line.value }}
        </text>
    </g>
    <!-- x 时间刻度：点少全标，点多只标首尾 -->
    <text
        v-for="(p, i) in points"
        :key="p.x"
        :x="xOf(p)"
        :y="H - 10"
        text-anchor="middle"
        class="trend-axis-text"
    >
        {{ i === 0 || i === points.length - 1 || points.length <= 4 ? p.label : "" }}
    </text>
    <!-- 三条序列 -->
    <g v-for="s in SERIES" :key="s.key" v-show="visible[s.key]">
        <polyline
        :points="polyPoints(s)"
        fill="none"
        :stroke="s.color"
        stroke-width="2"
        stroke-linejoin="round"
        />
        <circle
        v-for="p in points"
        :key="p.x"
        :cx="xOf(p)"
        :cy="yOf(p[s.key])"
        r="4"
        :fill="s.color"
        >
        <title>{{ s.title }}：{{ p.label }} {{ p[s.key] }} 次</title>
        </circle>
    </g>
    </svg>
</div>
</template>