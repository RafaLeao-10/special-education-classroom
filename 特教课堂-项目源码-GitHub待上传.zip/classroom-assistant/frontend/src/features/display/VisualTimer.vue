<script setup lang="ts">
import { computed } from "vue";

const props = defineProps<{ remainingSec: number; totalSec: number }>();

const text = computed(() => {
const mm = String(Math.floor(props.remainingSec / 60)).padStart(2, "0");
const ss = String(props.remainingSec % 60).padStart(2, "0");
return `${mm}:${ss}`;
});
const warn = computed(() => props.remainingSec <= 60 && props.remainingSec > 0);
const pct = computed(() =>
props.totalSec > 0 ? Math.min(1, props.remainingSec / props.totalSec) : 0,
);
// 圆环半径（viewBox 140 内），周长用于 stroke-dasharray
const R = 58;
const C = 2 * Math.PI * R;
</script>

<template>
<div class="visual-timer" :class="{ 'is-warn': warn }">
    <svg viewBox="0 0 140 140" aria-hidden="true">
    <circle class="timer-ring-bg" cx="70" cy="70" :r="R" />
    <circle
        class="timer-ring"
        cx="70"
        cy="70"
        :r="R"
        :stroke-dasharray="C"
        :stroke-dashoffset="C * (1 - pct)"
    />
    </svg>
    <span class="timer-text">{{ text }}</span>
</div>
</template>