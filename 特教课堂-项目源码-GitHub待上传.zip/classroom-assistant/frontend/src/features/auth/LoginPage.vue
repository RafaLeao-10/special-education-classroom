<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";
import { auth } from "../../api/services/auth";
import { currentUser } from "../../app/session";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
const router = useRouter();
const username = ref("teacher");
const password = ref("");
const busy = ref(false);
const error = ref("");
async function login() {
  busy.value = true;
  error.value = "";
  try {
    currentUser.value = (await auth.login(username.value, password.value)).user;
    await router.push("/");
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    busy.value = false;
  }
}
</script>
<template>
  <div class="login-layout">
    <div class="login-story">
      <span class="brand-symbol"><AppIcon name="leaf" :size="28" /></span>
      <p class="eyebrow">用心教学 · 日日相伴</p>
      <h1>每一个小进步，<br />都值得用心陪伴。</h1>
      <p>
        为特殊教育教师留一处安静的工作空间。<br />备课有章法，课堂有支持，成长有记录。
      </p>
      <div class="login-story-footer">
        特教课堂辅助平台<span>教师工作台</span>
      </div>
    </div>
    <section class="login-card">
      <p class="eyebrow">欢迎回来</p>
      <h2>回到你的教学工作台</h2>
      <p class="subtle">登录后，开始准备下一堂用心的课。</p>
      <el-alert v-if="error" :title="error" type="error" :closable="false" />
      <el-form label-position="top" @submit.prevent="login">
        <el-form-item label="教师账号">
          <el-input v-model="username" autocomplete="username" />
        </el-form-item>
        <el-form-item label="密码">
          <el-input
            v-model="password"
            type="password"
            show-password
            autocomplete="current-password"
          />
        </el-form-item>
        <Button native-type="submit" variant="primary" :loading="busy">
          登录工作台
        </Button>
      </el-form>
      <p class="login-hint">本地演示 · 账号 teacher / 密码 classroom-demo</p>
    </section>
  </div>
</template>
