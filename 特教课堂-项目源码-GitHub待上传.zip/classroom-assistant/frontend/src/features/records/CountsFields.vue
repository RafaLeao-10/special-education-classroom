<script setup lang="ts">
import { countFields, type Counts } from "./counts";
const counts = defineModel<Counts>({ required: true });
</script>
<template>
  <div class="counts-fields">
    <label v-for="[key, label] in countFields" :key="key"
      ><span>{{ label }}</span
      ><el-input-number
        :model-value="counts[key]"
        @update:model-value="counts[key] = $event ?? 0"
        :min="0"
        :precision="0"
        :aria-label="label"
    /></label>
  </div>
</template>
