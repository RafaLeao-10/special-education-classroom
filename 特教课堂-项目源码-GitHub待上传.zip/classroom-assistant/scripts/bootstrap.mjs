import { available, ensureConfig, pnpm, run } from "./process.mjs";

async function main() {
  if (Number(process.versions.node.split(".")[0]) !== 24)
    throw new Error("需要Node.js 24 LTS：https://nodejs.org/");
  ensureConfig();
  const externalDatabase = process.argv.includes("--external-db");
  const missing = [];
  if (!available("uv", ["--version"]))
    missing.push("uv：https://docs.astral.sh/uv/getting-started/installation/");
  if (!externalDatabase && !available("docker", ["compose", "version"]))
    missing.push("Docker Compose：https://docs.docker.com/desktop/");
  if (missing.length)
    throw new Error(`缺少前置工具，请安装后重试：\n${missing.join("\n")}`);
  await pnpm(["install", "--frozen-lockfile"]);
  await run("uv", ["sync", "--all-packages", "--group", "dev", "--locked"]);
  console.log(
    externalDatabase
      ? "依赖已安装。请配置.env中的两条PostgreSQL URL，再运行pnpm db:migrate → pnpm db:seed。"
      : "依赖已安装。下一步：pnpm db:up → pnpm db:migrate → pnpm db:seed",
  );
}
main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
