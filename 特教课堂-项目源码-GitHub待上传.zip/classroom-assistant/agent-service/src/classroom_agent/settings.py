from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")
    agent_provider: Literal["mock", "agentarts"] = "agentarts"
    mock_scenario: Literal["normal", "failed"] = "normal"
    mock_delay_ms: int = Field(default=250, ge=0)
    agentarts_invoke_url: str = ""
    agentarts_api_key: str = Field(default="", repr=False)
    agentarts_timeout_sec: int = Field(default=180, gt=0)

    @property
    def configured(self) -> bool:
        return self.agent_provider == "mock" or bool(self.agentarts_invoke_url and self.agentarts_api_key)
