from datetime import UTC, datetime
from uuid import uuid4

from classroom_contracts.models import Report, ReportContent, ReportDraft
from classroom_contracts.planned import ReportAction, ReportPatch, ReportSummary, TeacherReportCreate
from sqlalchemy import select
from sqlalchemy.orm import Session

from classroom_api.errors import BusinessError
from classroom_api.lessons import service as lessons
from classroom_api.records.queries import ids_for_lesson

from .models import ReportRow


def get(db: Session, report_id: str) -> ReportRow:
    row = db.get(ReportRow, report_id)
    if row is None:
        raise BusinessError(404, "NOT_FOUND", "报告不存在")
    return row


def to_dto(db: Session, row: ReportRow) -> Report:
    lesson = lessons.get(db, row.lesson_id)
    values = {name: getattr(row, name) for name in Report.model_fields if name != "is_stale"}
    return Report(
        **values,
        is_stale=(
            row.source_plan_version != lesson.plan_version
            or row.source_record_version != lesson.record_version
        ),
    )


def listing(db: Session, lesson_id: str):
    lessons.get(db, lesson_id)
    rows = db.scalars(
        select(ReportRow)
        .where(ReportRow.lesson_id == lesson_id)
        .order_by(ReportRow.generated_at.desc(), ReportRow.id)
    )
    return [ReportSummary.model_validate(to_dto(db, row).model_dump()) for row in rows]


def validate_content(db: Session, lesson, content: ReportContent):
    if not content.overview.strip():
        raise BusinessError(422, "INVALID_ARGUMENT", "请填写课堂概览", ["content.overview"])
    from classroom_api.lessons.models import AdjustmentRow, PlanSnapshotRow

    plans = [lesson.plan] if lesson.plan else []
    plans.extend(db.scalars(select(PlanSnapshotRow.plan).where(PlanSnapshotRow.lesson_id == lesson.id)))
    activities = {a["id"] for plan in plans for a in plan["activities"]}
    tasks = {t["id"] for plan in plans for a in plan["activities"] for t in a["tasks"]}
    groups = {g["id"] for plan in plans for g in plan["groups"]}
    if (
        any(s.activity_id not in activities for s in content.activity_summaries)
        or any(s.student_id not in lesson.student_ids for s in content.student_summaries)
        or any(s.group_id not in groups for s in content.group_summaries)
    ):
        raise BusinessError(422, "INVALID_ARGUMENT", "报告引用的学生或活动不属于本课")
    for item in content.recommendations + content.missing_information:
        allowed = {"class": {lesson.id}, "student": set(lesson.student_ids), "group": groups}
        if item.subject.id not in allowed[item.subject.type] or (item.task_id and item.task_id not in tasks):
            raise BusinessError(422, "INVALID_ARGUMENT", "报告建议引用的对象或任务无效")
    record_ids = {
        id
        for item in (
            content.activity_summaries
            + content.student_summaries
            + content.group_summaries
            + content.recommendations
        )
        for id in item.record_ids
    }
    if record_ids and not record_ids <= ids_for_lesson(db, lesson.id):
        raise BusinessError(422, "INVALID_ARGUMENT", "报告引用的记录不属于本课")
    adjustment_ids = {a.adjustment_id for a in content.adjustment_summaries}
    adjustment_ids.update(id for a in content.activity_summaries for id in a.adjustment_ids)
    existing = set(db.scalars(select(AdjustmentRow.id).where(AdjustmentRow.lesson_id == lesson.id)))
    if not adjustment_ids <= existing:
        raise BusinessError(422, "INVALID_ARGUMENT", "报告引用的调整不属于本课")


def save_agent_draft(db: Session, lesson, job_id: str, draft: ReportDraft) -> Report:
    if lesson.status != "completed":
        raise BusinessError(409, "INVALID_STATE", "请结课后保存智能报告")
    validate_content(db, lesson, draft.content)
    row = ReportRow(
        id=str(uuid4()),
        lesson_id=lesson.id,
        client_request_id=job_id,
        revision=1,
        status="draft",
        authoring_mode="agent",
        source_plan_version=lesson.plan_version,
        source_record_version=lesson.record_version,
        content=draft.content.model_dump(mode="json"),
        statistics=[r.model_dump(mode="json") for r in draft.statistics],
        references=[r.model_dump(mode="json") for r in draft.references],
        generated_at=datetime.now(UTC),
        confirmed_at=None,
    )
    db.add(row)
    db.flush()
    return to_dto(db, row)


def create(db: Session, lesson_id: str, body: TeacherReportCreate, statistics) -> Report:
    lesson = lessons.get(db, lesson_id, lock=True)
    existing = db.scalar(
        select(ReportRow).where(
            ReportRow.lesson_id == lesson_id, ReportRow.client_request_id == body.client_request_id
        )
    )
    if existing:
        if existing.revision == 1 and (
            existing.content != body.content.model_dump(mode="json")
            or existing.source_plan_version != body.expected_plan_version
            or existing.source_record_version != body.expected_record_version
        ):
            raise BusinessError(409, "REQUEST_CONFLICT", "同一报告提交标识不能用于不同内容")
        return to_dto(db, existing)
    if lesson.status != "completed":
        raise BusinessError(409, "INVALID_STATE", "结课后可以保存课堂报告，课中请先保存速记")
    if (body.expected_plan_version, body.expected_record_version) != (
        lesson.plan_version,
        lesson.record_version,
    ):
        raise BusinessError(409, "VERSION_CONFLICT", "课堂记录已变化，请重新读取最新记录后保存报告")
    if (statistics.source_plan_version, statistics.source_record_version) != (
        lesson.plan_version,
        lesson.record_version,
    ):
        raise BusinessError(409, "VERSION_CONFLICT", "统计期间记录已变化，请重新读取后保存")
    validate_content(db, lesson, body.content)
    row = ReportRow(
        id=str(uuid4()),
        lesson_id=lesson_id,
        client_request_id=body.client_request_id,
        revision=1,
        status="draft",
        authoring_mode="teacher",
        source_plan_version=lesson.plan_version,
        source_record_version=lesson.record_version,
        content=body.content.model_dump(mode="json"),
        statistics=[r.model_dump(mode="json") for r in statistics.rows],
        references=[],
        generated_at=datetime.now(UTC),
        confirmed_at=None,
    )
    db.add(row)
    db.flush()
    return to_dto(db, row)


def editable(db: Session, report_id: str, revision: int):
    initial = get(db, report_id)
    lesson = lessons.get(db, initial.lesson_id, lock=True)
    row = db.scalar(
        select(ReportRow)
        .where(ReportRow.id == report_id)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    return lesson, row


def update(db: Session, report_id: str, body: ReportPatch) -> Report:
    lesson, row = editable(db, report_id, body.expected_revision)
    if row.revision != body.expected_revision:
        if (
            row.revision == body.expected_revision + 1
            and row.status == "draft"
            and row.content == body.content.model_dump(mode="json")
        ):
            return to_dto(db, row)
        raise BusinessError(409, "VERSION_CONFLICT", "报告已更新，请重新读取后再操作")
    if row.status != "draft":
        raise BusinessError(409, "INVALID_STATE", "请先将已确认报告重新打开为草稿")
    validate_content(db, lesson, body.content)
    row.content = body.content.model_dump(mode="json")
    row.revision += 1
    db.flush()
    return to_dto(db, row)


def act(db: Session, report_id: str, body: ReportAction) -> Report:
    lesson, row = editable(db, report_id, body.expected_revision)
    desired = "confirmed" if body.action == "confirm" else "draft"
    if row.revision != body.expected_revision:
        if row.revision == body.expected_revision + 1 and row.status == desired:
            return to_dto(db, row)
        raise BusinessError(409, "VERSION_CONFLICT", "报告已更新，请重新读取后再操作")
    if body.action == "confirm":
        if to_dto(db, row).is_stale:
            raise BusinessError(409, "VERSION_CONFLICT", "记录已更正，请根据最新记录另存报告后确认")
        row.status = "confirmed"
        row.confirmed_at = datetime.now(UTC)
    else:
        row.status = "draft"
        row.confirmed_at = None
    row.revision += 1
    db.flush()
    return to_dto(db, row)


def choices(db, student_ids, owner_id):
    from classroom_contracts.planned import ReportChoice

    from classroom_api.lessons.models import LessonRow

    result = []
    for report, lesson in db.execute(
        select(ReportRow, LessonRow)
        .join(LessonRow, ReportRow.lesson_id == LessonRow.id)
        .where(ReportRow.status == "confirmed", LessonRow.owner_id == owner_id)
        .order_by(ReportRow.generated_at.desc())
    ):
        value = to_dto(db, report)
        if not value.is_stale and set(lesson.student_ids) <= set(student_ids):
            result.append(
                ReportChoice(
                    **ReportSummary.model_validate(value.model_dump()).model_dump(),
                    lesson_title=lesson.title,
                    student_ids=lesson.student_ids,
                )
            )
    return result
