import asyncio
from uuid import uuid4

from classroom_agent.settings import Settings
from classroom_contracts.agent import AgentResponse, PlanResult, PrepareRequest
from classroom_contracts.models import (
    Activity,
    Error,
    LessonPlan,
    Step,
    StudentTarget,
    Task,
    TeachingResource,
    TextBlock,
)


def failure(request: PrepareRequest, code: str, message: str) -> AgentResponse:
    return AgentResponse(
        contract_version="1.0",
        request_id=request.request_id,
        status="failed",
        questions=[],
        result=None,
        error=Error(code=code, message=message, fields=[]),
    )


def build_plan(request: PrepareRequest) -> LessonPlan:
    """Project example. Student abilities and long-term goals are never invented."""
    students = request.students
    materials = request.lesson.available_materials
    names = "、".join(material.name for material in materials) or "无需专门材料的指认与交流活动"
    task_id = str(uuid4())
    targets = [
        StudentTarget(
            student_id=student.id,
            goal_ids=[goal.id for goal in student.goals],
            completion_criterion="按教师所选目标观察本次物品归位反应。",
            accepted_response_modes=student.communication_modes,
            routine_support_ids=[],
            adaptation_note="",
        )
        for student in students
    ]
    instructions = [f"看一看{names}，选择一种材料。", "把选好的材料放回教师指定的位置。"]
    task = Task(
        id=task_id,
        title="材料选择与归位（项目模拟示例）",
        participant_ids=request.lesson.student_ids,
        objective="围绕教师已有目标，练习材料选择与归位。",
        student_targets=targets,
        practice_format="task_analysis",
        material_ids=[material.id for material in materials],
        teacher_preparation=f"准备本次已有材料：{names}；明确归位位置。",
        feedback_guidance="按已有教学安排反馈，并区分常规支持与追加成人提示。",
        recording_unit="step",
        planned_opportunities=None,
        steps=[
            Step(
                id=str(uuid4()),
                order=index,
                instruction=instruction,
                expected_response="选择材料" if index == 1 else "将材料放至指定位置",
                completion_criterion="观察教师指定的操作是否完成",
                observation_focus="完成情况及追加成人提示",
                demonstration="",
                display_blocks=[TextBlock(type="text", text=instruction)],
            )
            for index, instruction in enumerate(instructions, 1)
        ],
        knowledge_refs=[],
    )
    return LessonPlan(
        title=request.lesson.title,
        groups=[],
        supports=[],
        activities=[
            Activity(
                id=str(uuid4()),
                title="材料选择与归位",
                order=1,
                activity_type="routine",
                duration_min=request.lesson.planned_duration_min,
                participant_ids=request.lesson.student_ids,
                group_id=None,
                tasks=[task],
            )
        ],
        resources=[
            TeachingResource(
                id=str(uuid4()),
                title="材料归位步骤单",
                type="activity_steps",
                task_ids=[task_id],
                blocks=[TextBlock(type="text", text="选择材料 → 放回指定位置。项目示例。")],
            )
        ],
        references=[],
    )


class MockProvider:
    def __init__(self, settings: Settings):
        self.settings = settings

    async def generate(self, request: PrepareRequest) -> AgentResponse:
        await asyncio.sleep(self.settings.mock_delay_ms / 1000)
        if self.settings.mock_scenario == "failed":
            return failure(request, "MOCK_FAILURE", "本地模拟失败场景，请将MOCK_SCENARIO改回normal后重试")
        if (
            {student.id for student in request.students} != set(request.lesson.student_ids)
            or not request.students
            or any(not student.goals or not student.communication_modes for student in request.students)
        ):
            return failure(
                request, "MOCK_CONTEXT_INSUFFICIENT", "请补齐本课学生目标和沟通方式"
            )
        return AgentResponse(
            contract_version="1.0",
            request_id=request.request_id,
            status="succeeded",
            questions=[],
            result=PlanResult(kind="plan", data=build_plan(request)),
            error=None,
        )
