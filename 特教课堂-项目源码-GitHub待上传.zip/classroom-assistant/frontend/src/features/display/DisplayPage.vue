<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import AppIcon from "../../components/AppIcon.vue";
import BlocksRenderer from "../../components/BlocksRenderer.vue";
import FirstThenBoard from "./FirstThenBoard.vue";
import VisualTimer from "./VisualTimer.vue";
import { useDisplay } from "./useDisplay";
import { useCountdown } from "./useCountdown";
import { useChime } from "./chime";
import { useDisplayChannel } from "./useDisplayChannel";
import { displayGet, displaySet } from "./displayStore";
import TokenBoard from "./TokenBoard.vue";
import { useTokenStars } from "./useTokenStars";
import { useKiosk } from "./useKiosk";
import { applyLowStimulus } from "../../app/lowStimulus";

const token = String(useRoute().params.token);
const router = useRouter();

// 配置初值：query 优先，其次本地记忆，最后默认
const reward = ref(String(useRoute().query.reward ?? ""));
const goal = ref(Number(useRoute().query.goal) || 5);
const durationMin = ref(Number(useRoute().query.duration) || 25);
const soundOn = ref(
  useRoute().query.sound === "0" ? false : displayGet<boolean>("sound") ?? true,
);

const calm = ref(
  useRoute().query.calm === "1"
    ? true
    : displayGet<boolean>("calm") ?? false,
);
watch(
  calm,
  (v) => {
    displaySet("calm", v);
    applyLowStimulus(v);
  },
  { immediate: true },
);

const kiosk = useKiosk();
const chime = useChime(soundOn);
const { totalSec, remainingSec, start: startCountdown, onExpired } =
  useCountdown(durationMin.value);
onExpired(() => chime.play("expire"));


const { state, error } = useDisplay(token, {
  onRevision: () => {
    // 老师端切换教学节点：重置倒计时 + 提示音（加星在 P1-3 接上）
    startCountdown(durationMin.value);
    chime.play("step");
  },
});

// 页面在开课之后才打开时：首次看到 in_progress 也起一次倒计时
let begun = false;
watch(
  () => state.value?.status,
  (s) => {
    if (s === "in_progress" && !begun) {
      begun = true;
      startCountdown(durationMin.value);
    }
  },
);

// 频道：每次轮询成功后喊 hello；收 config 更新配置并同步 query
const lessonId = computed(() => state.value?.lesson_id);
const tokenStars = useTokenStars(lessonId, goal, {
  onCelebrate: () => chime.play("goal"),
});
// 加星走独立 watcher：与 useDisplay 的回调拆开，避免初始化顺序互相引用成环
watch(
  () => state.value?.display_revision,
  (rev) => {
    if (rev !== undefined) tokenStars.addByRevision(rev);
  },
);
const channel = useDisplayChannel(lessonId, {
  onConfig: (cfg) => {
    if (cfg.reward !== undefined) reward.value = cfg.reward;
    if (cfg.goal !== undefined) goal.value = cfg.goal;
    if (cfg.duration !== undefined) durationMin.value = cfg.duration;
    if (cfg.sound !== undefined) soundOn.value = cfg.sound;
    syncQuery();
  },
  onStars: (delta) => tokenStars.manualAdd(delta),
  onReset: () => tokenStars.reset(),
});
watch(state, () => {
  if (state.value) channel.post({ kind: "hello" });
});

function syncQuery() {
  const params = new URLSearchParams();
  if (reward.value) params.set("reward", reward.value);
  params.set("goal", String(goal.value));
  params.set("duration", String(durationMin.value));
  params.set("sound", soundOn.value ? "1" : "0");
  params.set("calm", calm.value ? "1" : "0");
  router.replace({ query: Object.fromEntries(params) });
}

watch(soundOn, (v) => displaySet("sound", v));
async function startDisplay() {
  // 音频解锁和全屏请求都必须发生在用户手势里
  chime.unlock();
  await kiosk.enter();
}

function toggleKiosk() {
  if (kiosk.isFullscreen.value) void kiosk.exit();
  else void kiosk.enter();
}

</script>

<template>
  <div class="display-root" :class="{ 'is-fullscreen': kiosk.isFullscreen.value, 'is-idle': kiosk.idle.value }" :data-calm="calm ? '1' : undefined">
    <!-- 等待屏 -->
    <main
      v-if="!state || state.status === 'draft' || state.status === 'ready'"
      class="display-waiting"
    >
      <span aria-hidden="true">✧</span>
      <h1>准备好，一起开始</h1>
      <p>等待老师开始课堂</p>
      <button class="display-start" @click="startDisplay">我准备好了</button>
    </main>

    <!-- 结束屏 -->
    <main v-else-if="state.status === 'completed'" class="display-waiting">
      <span aria-hidden="true">✧</span>
      <h1>这一堂课结束了</h1>
      <p>谢谢你的参与</p>
    </main>

    <!-- 进行中 -->
    <div v-else class="display-stage">
      <header class="display-header">
        <p class="eyebrow">{{ state.activity_title }}</p>
        <VisualTimer :remaining-sec="remainingSec" :total-sec="totalSec" />
      </header>
      <Transition name="display-step" mode="out-in">
        <div
          class="display-main"
          :key="state.display_revision"
        >
          <h1 class="display-task-title">{{ state.task_title }}</h1>
          <BlocksRenderer :blocks="state.blocks" :assets="state.assets" />
          <p v-if="state.total_steps > 1" class="display-step-label">
            第 {{ state.step_order }} 步 / 共 {{ state.total_steps }} 步
          </p>
        </div>
      </Transition>
      <footer class="display-footer">
        <FirstThenBoard :task="state.task_title" :reward="reward" />
      <TokenBoard
          :stars="tokenStars.stars.value"
          :goal="goal"
          :celebrating="tokenStars.celebrating.value"
        />
      </footer>
    </div>

    <!-- 悬浮工具栏 -->
    <div class="display-chrome">
      <button type="button" @click="calm = !calm">
        <AppIcon name="moon" :size="16" />{{
          calm ? "低刺激开" : "低刺激关"
        }}
      </button>
      <button type="button" @click="soundOn = !soundOn">
        <AppIcon :name="soundOn ? 'volume' : 'mute'" :size="16" />
        {{ soundOn ? "音效开" : "音效关" }}
      </button>
      <button type="button" @click="tokenStars.manualAdd(1)">
        <AppIcon name="star" :size="16" />加一星
      </button>
      <button type="button" @click="tokenStars.manualAdd(-1)">减一星</button>
      <button type="button" @click="tokenStars.reset()">清空</button>
      <button type="button" @click="toggleKiosk">
        <AppIcon name="classroom" :size="16" />{{
          kiosk.isFullscreen.value ? "退出全屏" : "全屏"
        }}
      </button>
    </div>

    <p v-if="error" class="display-connection" role="status">
      连接暂时中断，正在重新读取课堂。
    </p>
  </div>
</template>