"""V1 data definitions, including future domains; these do not implement workflows."""

from typing import Annotated, Literal

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, model_validator

from .enums import (
    ActivityType,
    AdjustmentAction,
    CommunicationMode,
    KnowledgeCategory,
    LessonStatus,
    PracticeFormat,
    PromptType,
    RecordingUnit,
    RecordKind,
    ReportStatus,
    ResourceType,
    ReviewStatus,
    SourceKind,
    SupportType,
    TaskStatus,
)

Id = Annotated[
    str, Field(pattern=r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
]
Positive = Annotated[int, Field(gt=0, strict=True)]
NonNegative = Annotated[int, Field(ge=0, strict=True)]


class DTO(BaseModel):
    model_config = ConfigDict(extra="ignore")


class InputDTO(DTO):
    model_config = ConfigDict(extra="forbid")


class Goal(DTO):
    id: Id
    description: str
    criterion: str | None


class Student(DTO):
    id: Id
    name: str
    communication_modes: list[CommunicationMode]
    goals: list[Goal]
    observed_abilities: list[str]
    usual_supports: list[str]
    interests: list[str]
    notes: str
    revision: Positive


class Material(DTO):
    id: Id
    name: str
    quantity: NonNegative | None
    asset_id: Id | None


class Group(DTO):
    id: Id
    label: str
    student_ids: list[Id]


class Support(DTO):
    id: Id
    type: SupportType
    description: str
    asset_id: Id | None


class TextBlock(DTO):
    type: Literal["text"]
    text: str


class ImageBlock(DTO):
    type: Literal["image"]
    asset_id: Id
    alt: str


class TableBlock(DTO):
    type: Literal["table"]
    headers: list[str]
    rows: list[list[str]]

    @model_validator(mode="after")
    def matching_columns(self):
        if any(len(row) != len(self.headers) for row in self.rows):
            raise ValueError("表格每行列数须与表头一致")
        return self


Block = Annotated[TextBlock | ImageBlock | TableBlock, Field(discriminator="type")]


class Step(DTO):
    id: Id
    order: Positive
    instruction: str
    expected_response: str
    completion_criterion: str
    observation_focus: str
    demonstration: str
    display_blocks: list[Block]


class StudentTarget(DTO):
    student_id: Id
    goal_ids: list[Id]
    completion_criterion: str
    accepted_response_modes: list[CommunicationMode]
    routine_support_ids: list[Id]
    adaptation_note: str


class Task(DTO):
    id: Id
    title: str
    participant_ids: list[Id]
    objective: str
    student_targets: list[StudentTarget]
    practice_format: PracticeFormat
    material_ids: list[Id]
    teacher_preparation: str
    feedback_guidance: str
    recording_unit: RecordingUnit
    planned_opportunities: Positive | None
    steps: Annotated[list[Step], Field(min_length=1)]
    knowledge_refs: list[str]


class Activity(DTO):
    id: Id
    title: str
    order: Positive
    activity_type: ActivityType
    duration_min: Positive
    participant_ids: list[Id]
    group_id: Id | None
    tasks: Annotated[list[Task], Field(min_length=1)]


class TeachingResource(DTO):
    id: Id
    title: str
    type: ResourceType
    task_ids: list[Id]
    blocks: list[Block]


class KnowledgeRef(DTO):
    knowledge_id: str
    title: str
    source_title: str
    source_url: str | None
    source_locator: str
    source_kind: SourceKind
    review_status: ReviewStatus


class LessonPlan(DTO):
    title: str
    groups: list[Group]
    supports: list[Support]
    activities: Annotated[list[Activity], Field(min_length=1)]
    resources: list[TeachingResource]
    references: list[KnowledgeRef]


class TaskState(DTO):
    task_id: Id
    status: TaskStatus


class ExecutionState(DTO):
    split_task_ids: list[Id] = Field(default_factory=list)
    task_states: list[TaskState]
    display_task_id: Id | None
    display_step_id: Id | None
    display_revision: NonNegative


class Lesson(DTO):
    id: Id
    title: str
    student_ids: list[Id]
    planned_duration_min: Positive
    available_materials: list[Material]
    previous_report_ids: list[Id]
    copied_from_lesson_id: Id | None = None
    copied_from_plan_version: Positive | None = None
    student_snapshots: list[Student] = Field(default_factory=list)
    snapshot_origin: Literal["captured", "migration", "none"] = "none"
    status: LessonStatus
    plan: LessonPlan | None
    plan_version: NonNegative
    record_version: NonNegative
    execution: ExecutionState
    created_at: AwareDatetime
    updated_at: AwareDatetime


class Counts(DTO):
    independent: NonNegative
    prompted: NonNegative
    completed_unknown_prompt: NonNegative
    not_completed: NonNegative
    not_observed: NonNegative
    not_run: NonNegative
    unknown: NonNegative


class Subject(DTO):
    type: Literal["student", "group", "class"]
    id: Id


class Record(DTO):
    id: Id
    lesson_id: Id
    client_record_id: Id
    kind: RecordKind
    subject: Subject
    activity_id: Id | None
    task_id: Id | None
    step_id: Id | None
    task_plan_version: Positive | None
    counts: Counts | None
    routine_support_ids: list[Id]
    prompt_types: list[PromptType]
    note: str
    observed_at: AwareDatetime
    revision: Positive
    is_void: bool

    @model_validator(mode="after")
    def valid_observation(self):
        if self.kind == "observation":
            if not (self.activity_id and self.task_id and self.task_plan_version and self.counts):
                raise ValueError("观察记录须包含活动、任务、方案版本与计数")
            if sum(self.counts.model_dump().values()) < 1:
                raise ValueError("观察计数总和至少为1")
        elif self.counts is not None:
            raise ValueError("文字速记的counts必须为null")
        return self


class PlanSnapshot(DTO):
    plan_version: Positive
    plan: LessonPlan
    student_snapshots: list[Student] = Field(default_factory=list)
    snapshot_origin: Literal["captured", "migration", "none"] = "none"


class AdjustmentLog(DTO):
    id: Id
    job_id: Id
    action: AdjustmentAction
    from_plan_version: NonNegative
    to_plan_version: Positive
    target_task_ids: list[Id]
    summary: str
    applied_at: AwareDatetime


class StatisticsRow(DTO):
    subject: Subject
    task_id: Id
    step_id: Id | None
    task_plan_version: Positive
    counts: Counts
    known_outcome_count: NonNegative
    completed_count: NonNegative
    record_ids: list[Id]


class ActivitySummary(DTO):
    activity_id: Id
    text: str
    record_ids: list[Id]
    adjustment_ids: list[Id]


class StudentSummary(DTO):
    student_id: Id
    text: str
    record_ids: list[Id]


class GroupSummary(DTO):
    group_id: Id
    text: str
    record_ids: list[Id]


class AdjustmentSummary(DTO):
    adjustment_id: Id
    text: str


class Recommendation(DTO):
    subject: Subject
    task_id: Id | None
    action: str
    basis: str
    record_ids: list[Id]
    knowledge_refs: list[str]


class MissingInformation(DTO):
    subject: Subject
    task_id: Id | None
    field: str
    description: str


class ReportContent(DTO):
    overview: str
    activity_summaries: list[ActivitySummary]
    student_summaries: list[StudentSummary]
    group_summaries: list[GroupSummary]
    adjustment_summaries: list[AdjustmentSummary]
    recommendations: list[Recommendation]
    missing_information: list[MissingInformation]


class ReportDraft(DTO):
    content: ReportContent
    statistics: list[StatisticsRow]
    references: list[KnowledgeRef]


class Report(ReportDraft):
    id: Id
    lesson_id: Id
    revision: Positive
    status: ReportStatus
    source_plan_version: NonNegative
    source_record_version: NonNegative
    is_stale: bool
    generated_at: AwareDatetime
    confirmed_at: AwareDatetime | None
    authoring_mode: Literal["teacher", "agent"] = "agent"


class Asset(DTO):
    preview_pages: list[str] = Field(default_factory=list)
    preview_url: str | None = None
    id: Id
    kind: Literal["image", "file"]
    mime_type: str
    name: str
    alt: str
    url: str
    expires_at: AwareDatetime | None


class DisplayState(DTO):
    status: LessonStatus
    lesson_id: Id
    display_revision: NonNegative
    activity_title: str
    task_title: str
    step_order: NonNegative
    total_steps: NonNegative
    blocks: list[Block]
    assets: list[Asset]


class KnowledgeCard(DTO):
    id: str
    title: str
    category: KnowledgeCategory
    target_skills: list[str]
    prerequisites: list[str]
    content_md: str
    related_ids: list[str]
    sources: list[KnowledgeRef]
    review_status: ReviewStatus
    version: str


class Error(DTO):
    code: str
    message: str
    fields: list[str]
