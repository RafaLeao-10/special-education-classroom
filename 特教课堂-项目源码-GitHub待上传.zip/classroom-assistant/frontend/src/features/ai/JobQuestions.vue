<script setup lang="ts">
import { ref, watch } from "vue";
import type { AiJob, Answer } from "../../api/services/jobs";
import { classroomApi } from "../../api/services/classroom";
import { readDraft, writeDraft } from "../../app/drafts";
import CountsFields from "../records/CountsFields.vue";
import { emptyCounts, type Counts } from "../records/counts";
import Button from "../../components/Button.vue";
const props = defineProps<{ job: AiJob; busy: boolean }>();
const emit = defineEmits<{ submit: [answers: Answer[]] }>();
const values = ref<Record<string, string | Counts>>({});
const error = ref("");
const restored = ref(false);
watch(
  () => [props.job.id, props.job.revision],
  async () => {
    const saved = readDraft<{
      revision: number;
      values: Record<string, string | Counts>;
    }>(`ai-answers:${props.job.id}`);
    restored.value = saved?.revision === props.job.revision;
    values.value = restored.value
      ? saved!.values
      : Object.fromEntries(
          props.job.questions.map((q) => [
            q.id,
            q.answer_type === "counts" ? emptyCounts() : "",
          ]),
        );
    error.value = "";
    if (
      !restored.value &&
      props.job.questions.some((q) => q.answer_type === "counts")
    ) {
      const revision = props.job.revision;
      try {
        const records = await classroomApi.records(props.job.lesson_id);
        if (props.job.revision !== revision) return;
        for (const question of props.job.questions) {
          if (question.target.kind !== "record_counts") continue;
          const target = question.target;
          const record = records.find(
            (r) =>
              r.id === target.record_id &&
              r.revision === target.record_revision,
          );
          const current = values.value[question.id] as Counts;
          if (record?.counts && Object.values(current).every((n) => n === 0))
            values.value[question.id] = { ...record.counts };
        }
      } catch {
        error.value = "未能读取原观察计数，请重新查询任务或填写计数。";
      }
    }
  },
  { immediate: true },
);
watch(
  values,
  (value) =>
    writeDraft(`ai-answers:${props.job.id}`, {
      revision: props.job.revision,
      values: value,
    }),
  { deep: true, flush: "sync" },
);
function send() {
  if (props.busy) return;
  for (const question of props.job.questions) {
    const value = values.value[question.id];
    if (question.answer_type === "counts") {
      if (
        Object.values(value as Counts).some(
          (n) => !Number.isInteger(n) || n < 0,
        ) ||
        Object.values(value as Counts).reduce((sum, n) => sum + n, 0) < 1
      ) {
        error.value = "请至少记录一次实际机会。";
        return;
      }
    } else if (
      question.required &&
      (typeof value !== "string" || !value.trim())
    ) {
      error.value = "请回答本轮必填问题。";
      return;
    }
  }
  error.value = "";
  emit(
    "submit",
    props.job.questions
      .filter((q) => q.required || values.value[q.id] !== "")
      .map((q) => ({ question_id: q.id, value: values.value[q.id] })),
  );
}
</script>
<template>
  <form class="agent-questions" @submit.prevent="send">
    <fieldset :disabled="busy" style="border: 0; padding: 0; margin: 0">
      <h3>请补充这些课堂信息</h3>
      <p v-if="restored" class="subtle">已恢复本机保存的回答草稿。</p>
      <p class="subtle">
        刷新后可继续填写，补充回答不会重复创建生成任务。
      </p>
      <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
      <div
        v-for="question in job.questions"
        :key="question.id"
        class="agent-question"
      >
        <label :for="`answer-${question.id}`"
          >{{ question.text }}{{ question.required ? "（必填）" : "" }}</label
        >
        <template v-if="question.answer_type === 'counts'">
          <p class="subtle">提交后会更正对应观察记录，并保留更正历史。</p>
          <CountsFields
            :model-value="values[question.id] as Counts"
            @update:model-value="values[question.id] = $event"
          />
        </template>
        <el-select
          v-else-if="question.answer_type === 'single_choice'"
          :disabled="busy"
          :id="`answer-${question.id}`"
          v-model="values[question.id]"
          placeholder="请选择"
        >
          <el-option
            v-for="option in question.options"
            :key="option.value"
            :value="option.value"
            :label="option.label"
          />
        </el-select>
        <el-input
          v-else
          :id="`answer-${question.id}`"
          v-model="values[question.id]"
          type="textarea"
          :rows="2"
        />
      </div>
      <Button native-type="submit" variant="primary" :loading="busy"
        >提交补充并继续生成</Button
      >
    </fieldset>
  </form>
</template>
