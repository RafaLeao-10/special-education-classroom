from classroom_contracts.http import Envelope
from classroom_contracts.teaching import LessonStatistics
from fastapi import APIRouter, Depends, Request

from classroom_api.auth.access import require_lesson
from classroom_api.auth.service import require_user

from .service import calculate

router = APIRouter(tags=["statistics"], dependencies=[Depends(require_user)])


@router.get(
    "/lessons/{id}/statistics",
    response_model=Envelope[LessonStatistics],
    dependencies=[Depends(require_lesson)],
)
async def read(id: str, request: Request):
    return Envelope(data=await calculate(request.app, id))
