<script setup lang="ts">
import type { components } from "../api/generated/schema";
defineProps<{
  blocks: components["schemas"]["Step"]["display_blocks"];
  assets?: components["schemas"]["Asset"][];
}>();
</script>
<template>
  <div class="teaching-blocks">
    <template v-for="(block, i) in blocks" :key="i"
      ><p v-if="block.type === 'text'" class="teaching-text">
        {{ block.text }}
      </p>
      <figure v-else-if="block.type === 'image'">
        <img
          :src="
            assets?.find((a) => a.id === block.asset_id)?.url ||
            `/api/v1/assets/${block.asset_id}/content`
          "
          :alt="block.alt"
        />
        <figcaption v-if="block.alt">{{ block.alt }}</figcaption>
      </figure>
      <div v-else class="table-scroll">
        <table>
          <thead>
            <tr>
              <th v-for="(h, j) in block.headers" :key="j">{{ h }}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, j) in block.rows" :key="j">
              <td v-for="(cell, k) in row" :key="k">{{ cell }}</td>
            </tr>
          </tbody>
        </table>
      </div></template
    >
  </div>
</template>
