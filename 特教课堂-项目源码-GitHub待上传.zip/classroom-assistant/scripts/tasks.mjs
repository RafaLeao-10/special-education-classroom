import { join } from "node:path";
import { pnpm, python, root, run } from "./process.mjs";

const migrate = [
  "--package",
  "classroom-api",
  "alembic",
  "-c",
  join(root, "backend/alembic.ini"),
  "upgrade",
  "head",
];
const tasks = {
  "db:up": () =>
    run("docker", [
      "compose",
      "--env-file",
      join(root, ".env"),
      "-f",
      join(root, "infra/compose.dev.yml"),
      "up",
      "-d",
      "--wait",
    ]),
  "db:migrate": () => python(migrate),
  "db:seed": () =>
    python([
      "--package",
      "classroom-api",
      "python",
      "-m",
      "classroom_api.seed",
    ]),
  "demo:lesson": () =>
    python([
      "--package",
      "classroom-api",
      "python",
      "-m",
      "classroom_api.demo",
    ]),
  "dev:api": () =>
    python([
      "--package",
      "classroom-api",
      "uvicorn",
      "classroom_api.main:create_app",
      "--factory",
      "--host",
      "127.0.0.1",
      "--port",
      "8000",
    ]),
  "dev:agent": () =>
    python([
      "--package",
      "classroom-agent",
      "uvicorn",
      "classroom_agent.main:create_app",
      "--factory",
      "--host",
      "127.0.0.1",
      "--port",
      "8001",
    ]),
  "dev:web": () => pnpm(["--filter", "classroom-web", "dev"]),
  "contracts:generate": async () => {
    await python(["python", "scripts/export_contracts.py"]);
    await pnpm([
      "exec",
      "openapi-typescript",
      "contracts/generated/openapi.json",
      "-o",
      "frontend/src/api/generated/schema.d.ts",
    ]);
    await pnpm([
      "exec",
      "openapi-typescript",
      "contracts/generated/planned.openapi.json",
      "-o",
      "frontend/src/api/generated/planned.d.ts",
    ]);
  },
  "contracts:check": () => python(["python", "scripts/check_contracts.py"]),
  check: async () => {
    await python(["ruff", "check", "."]);
    await python(["python", "scripts/check_boundaries.py"]);
    await pnpm(["--filter", "classroom-web", "typecheck"]);
    await tasks["contracts:check"]();
    await pnpm(["--filter", "classroom-web", "build"]);
  },
};
try {
  const task = tasks[process.argv[2]];
  if (!task) throw new Error(`未知任务：${process.argv[2]}`);
  await task();
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
