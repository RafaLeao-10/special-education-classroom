import os
import subprocess
import tempfile
from pathlib import Path

from export_contracts import ROOT, export


def check():
    with tempfile.TemporaryDirectory(prefix="classroom-contracts-") as temporary:
        target = Path(temporary)
        export(target)
        cli = os.environ.get("npm_execpath")
        if not cli:
            raise SystemExit("请运行pnpm contracts:check，以使用工作区中的类型生成工具")
        for source, output in (("openapi.json", "schema.d.ts"), ("planned.openapi.json", "planned.d.ts")):
            subprocess.run(
                [
                    os.environ.get("npm_node_execpath", "node"),
                    cli,
                    "exec",
                    "openapi-typescript",
                    str(target / source),
                    "-o",
                    str(target / output),
                ],
                cwd=ROOT,
                check=True,
            )
        comparisons = [
            (target / name, ROOT / "contracts/generated" / name)
            for name in ("openapi.json", "agent.schema.json", "teaching.schema.json", "planned.openapi.json")
        ]
        comparisons.append((target / "schema.d.ts", ROOT / "frontend/src/api/generated/schema.d.ts"))
        comparisons.append((target / "planned.d.ts", ROOT / "frontend/src/api/generated/planned.d.ts"))
        for generated, committed in comparisons:
            if not committed.exists() or generated.read_bytes() != committed.read_bytes():
                raise SystemExit(f"契约已过期：{committed.relative_to(ROOT)}；运行pnpm contracts:generate")
    print("生成契约与源定义一致。")


if __name__ == "__main__":
    check()
