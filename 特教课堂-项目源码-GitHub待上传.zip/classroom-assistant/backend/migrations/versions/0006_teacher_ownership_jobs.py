"""Assign existing data to its original teacher and version job continuations."""

import sqlalchemy as sa
from alembic import op

revision = "0006_teacher_ownership_jobs"
down_revision = "0005_agent_adjustments"
branch_labels = None
depends_on = None


def upgrade():
    for table in ("students", "lessons", "assets"):
        op.add_column(table, sa.Column("owner_id", sa.String(36), nullable=True))
        op.execute(
            sa.text(f"""UPDATE {table} SET owner_id = (
            SELECT id FROM users
            ORDER BY CASE WHEN id = '10000000-0000-4000-8000-000000000001' THEN 0 ELSE 1 END, id
            LIMIT 1
        )""")
        )
        op.alter_column(table, "owner_id", nullable=False)
        op.create_foreign_key(f"fk_{table}_owner", table, "users", ["owner_id"], ["id"])
        op.create_index(f"ix_{table}_owner_id", table, ["owner_id"])
    op.add_column("ai_jobs", sa.Column("revision", sa.Integer(), nullable=False, server_default="1"))
    op.add_column("ai_jobs", sa.Column("creation_fingerprint", sa.String(64), nullable=True))
    op.add_column("ai_jobs", sa.Column("last_resume_request_id", sa.String(36), nullable=True))
    op.add_column("ai_jobs", sa.Column("last_resume_fingerprint", sa.String(64), nullable=True))
    op.add_column("ai_jobs", sa.Column("last_retry_revision", sa.Integer(), nullable=True))


def downgrade():
    for column in (
        "last_retry_revision",
        "last_resume_fingerprint",
        "last_resume_request_id",
        "creation_fingerprint",
        "revision",
    ):
        op.drop_column("ai_jobs", column)
    for table in ("assets", "lessons", "students"):
        op.drop_index(f"ix_{table}_owner_id", table)
        op.drop_constraint(f"fk_{table}_owner", table, type_="foreignkey")
        op.drop_column(table, "owner_id")
