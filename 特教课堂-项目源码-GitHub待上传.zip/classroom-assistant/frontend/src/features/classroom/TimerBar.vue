<script setup lang="ts">
defineProps<{
elapsedText: string;
elapsedPct: number;
plannedMin: number;
activityTitle: string;
activityRemainText: string;
activityOver: boolean;
}>();
</script>

<template>
<div class="timer-bar">
    <span class="timer-elapsed"
    >已用 {{ elapsedText }} / 计划 {{ plannedMin }} 分钟</span
    >
    <div class="timer-track" aria-hidden="true">
    <i :style="{ width: `${Math.round(elapsedPct * 100)}%` }" />
    </div>
    <span
    v-if="activityTitle"
    class="timer-activity"
    :class="{ over: activityOver }"
    >{{ activityTitle }} · {{
        activityOver ? "已超时" : `剩余 ${activityRemainText}`
    }}</span
    >
</div>
</template>