from alembic import context
from classroom_api.ai_jobs.models import JobRow  # noqa: F401
from classroom_api.assets.models import AssetRow  # noqa: F401
from classroom_api.auth.models import SessionRow, UserRow  # noqa: F401
from classroom_api.db import Base
from classroom_api.lessons.models import LessonRow  # noqa: F401
from classroom_api.records.models import RecordCorrectionRow, RecordRow  # noqa: F401
from classroom_api.reports.models import ReportRow  # noqa: F401
from classroom_api.settings import Settings
from classroom_api.students.models import StudentRow  # noqa: F401
from sqlalchemy import create_engine, pool

url = Settings().database_url
if context.is_offline_mode():
    context.configure(url=url, target_metadata=Base.metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()
else:
    engine = create_engine(url, poolclass=pool.NullPool, connect_args={"connect_timeout": 5})
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=Base.metadata)
        with context.begin_transaction():
            context.run_migrations()
    engine.dispose()
