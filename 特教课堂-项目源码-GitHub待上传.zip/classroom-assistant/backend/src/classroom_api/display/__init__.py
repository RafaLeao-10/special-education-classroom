"""Read-only child display composed from current display blocks."""
