<script setup lang="ts">
import { emptyCounts, type Counts } from "./counts";
import Button from "../../components/Button.vue";
const counts = defineModel<Counts>({ required: true });
const buttons = [
  ["independent", "独立完成 +1"],
  ["prompted", "提示后完成 +1"],
  ["not_completed", "未完成 +1"],
  ["unknown", "未知 +1"],
] as const;
</script>
<template>
  <div class="quick-counts">
    <strong>快捷计数</strong>
    <div class="report-actions">
      <Button
        v-click-blur
        v-for="[key, label] in buttons"
        :key="key"
        size="sm"
        variant="secondary"
        @click="counts[key] += 1"
        >{{ label }}</Button
      ><Button
        v-click-blur
        size="sm"
        variant="quiet"
        @click="counts = emptyCounts()"
        >清空待保存次数</Button
      >
    </div>
    <p class="subtle">点击增加下方次数，再点击“保存观察计数”。</p>
  </div>
</template>
