import { onUnmounted, watch, type Ref } from "vue";

export interface DisplayConfig {
reward?: string;
goal?: number;
duration?: number;
sound?: boolean;
}

export type ChannelMsg =
| { kind: "hello" }
| { kind: "config"; payload: DisplayConfig }
| { kind: "stars"; delta: number }
| { kind: "reset" };

export function useDisplayChannel(
lessonId: Ref<string | undefined>,
handlers: {
    onConfig?: (cfg: DisplayConfig) => void;
    onStars?: (delta: number) => void;
    onReset?: () => void;
    onHello?: () => void;
} = {},
) {
let channel: BroadcastChannel | null = null;

function ensure() {
    const id = lessonId.value;
    if (!id) return;
    if (!channel || channel.name !== `classroom:display:${id}`) {
    channel?.close();
    channel = new BroadcastChannel(`classroom:display:${id}`);
    channel.onmessage = (event: MessageEvent<ChannelMsg>) => {
        const msg = event.data;
        if (!msg || typeof msg !== "object") return;
        if (msg.kind === "config") handlers.onConfig?.(msg.payload);
        else if (msg.kind === "stars") handlers.onStars?.(msg.delta);
        else if (msg.kind === "reset") handlers.onReset?.();
        else if (msg.kind === "hello") handlers.onHello?.();
    };
    }
}

function post(msg: ChannelMsg) {
    try {
    ensure();
    channel?.postMessage(msg);
    } catch {
    // 个别环境不支持 BroadcastChannel：静默降级，不影响主流程
    }
}

watch(lessonId, ensure, { immediate: true });
onUnmounted(() => channel?.close());

return { post };
}