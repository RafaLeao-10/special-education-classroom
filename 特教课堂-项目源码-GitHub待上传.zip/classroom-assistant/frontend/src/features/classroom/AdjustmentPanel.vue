<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import type { Lesson } from "../../api/services/lessons";
import { jobsApi } from "../../api/services/jobs";
import type { components } from "../../api/generated/schema";
import { useAiJob } from "../ai/useAiJob";
import JobStatus from "../ai/JobStatus.vue";
import { readDraft, writeDraft } from "../../app/drafts";
import Button from "../../components/Button.vue";
type Params = components["schemas"]["AdjustParams"];
const props = defineProps<{
  lesson: Lesson;
  currentTaskId?: string;
  currentStepId?: string;
  disabled: boolean;
}>();
const emit = defineEmits<{ adopted: [] }>();
const {
  job,
  error,
  running,
  available,
  serviceMessage,
  hasPending,
  retry,
  start,
  resume,
  restore,
  apply,
  poll,
} = useAiJob(props.lesson.id, "adjust");
const action = ref<Params["action"]>("simplify_instruction");
const instructionMode = ref<"simplify" | "split">("simplify");
const targetTaskId = ref("");
const selectedSteps = ref<string[]>([]);
const replacementMaterial = ref("");
const scope = `adjust-request:${props.lesson.id}`;
const teacherRequest = ref(readDraft<string>(scope) || "");
watch(teacherRequest, (value) => writeDraft(scope, value));
const saving = ref(false);
const saveError = ref("");
const history = ref<Awaited<ReturnType<typeof jobsApi.adjustments>>>([]);
const tasks = computed(
  () => props.lesson.plan?.activities.flatMap((a) => a.tasks) || [],
);
const states = computed(
  () =>
    new Map(
      props.lesson.execution.task_states.map((s) => [s.task_id, s.status]),
    ),
);
const eligible = computed(() =>
  tasks.value.filter((t) => {
    if (action.value !== "adjust_next_activity")
      return !["done", "skipped"].includes(states.value.get(t.id) || "");
    const activity = props.lesson.plan?.activities.find((a) =>
      a.tasks.some((task) => task.id === t.id),
    );
    return activity?.tasks.every(
      (task) => states.value.get(task.id) === "pending",
    );
  }),
);
const target = computed(() =>
  tasks.value.find((t) => t.id === targetTaskId.value),
);
const splitAllowed = computed(() => props.lesson.execution.split_task_ids?.includes(targetTaskId.value) || false);
watch([targetTaskId, splitAllowed], () => {
  if (!splitAllowed.value) instructionMode.value = "simplify";
});
const proposal = computed(() =>
  job.value?.result?.kind === "adjustment" ? job.value.result.data : null,
);
const stale = computed(
  () =>
    !!proposal.value &&
    (job.value!.base_plan_version !== props.lesson.plan_version ||
      job.value!.base_record_version !== props.lesson.record_version),
);
watch(
  [action, () => props.currentTaskId],
  () => {
    targetTaskId.value =
      eligible.value.find((t) => t.id === props.currentTaskId)?.id ||
      eligible.value[0]?.id ||
      "";
    selectedSteps.value = [];
  },
  { immediate: true },
);
watch(targetTaskId, () => {
  selectedSteps.value = [];
});
watch(instructionMode, (mode) => {
  if (mode === "split" && !selectedSteps.value.length)
    selectedSteps.value = [
      target.value?.steps.find((s) => s.id === props.currentStepId)?.id ||
        target.value?.steps[0]?.id ||
        "",
    ].filter(Boolean);
});
const materialName = (id: string) =>
  props.lesson.available_materials.find((m) => m.id === id)?.name || id;
function generate() {
  return start({
    action: action.value,
    instruction_mode:
      action.value === "simplify_instruction"
        ? instructionMode.value
        : "simplify",
    target_task_ids: [targetTaskId.value],
    step_ids: splitAllowed.value ? selectedSteps.value : [],
    replacement_material_id:
      action.value === "replace_material" ? replacementMaterial.value : null,
    teacher_request:
      instructionMode.value === "split" &&
      action.value === "simplify_instruction"
        ? `将选定操作拆成多个独立、依次执行的步骤，提供原步骤与新步骤对应关系，并同步配套资料。${teacherRequest.value}`
        : teacherRequest.value,
  });
}
async function adopt() {
  saving.value = true;
  saveError.value = "";
  try {
    const result = await apply();
    if (!result) return;
    emit("adopted");
    history.value = await jobsApi.adjustments(props.lesson.id);
  } catch (e) {
    saveError.value = (e as Error).message;
  } finally {
    saving.value = false;
  }
}
onMounted(async () => {
  try {
    await restore();
    history.value = await jobsApi.adjustments(props.lesson.id);
  } catch (e) {
    saveError.value = (e as Error).message;
  }
});
</script>
<template>
  <section class="agent-panel">
    <p class="eyebrow">智能调整</p>
    <h2>课堂智能调整</h2>
    <p class="subtle">
      先查看调整建议，确认采用后更新课堂指令，原教案与观察记录保留。
    </p>
    <p class="subtle">{{ serviceMessage }}</p>
    <div class="agent-form-grid">
      <label
        >调整方式<el-select v-model="action">
          <el-option
            value="simplify_instruction"
            label="指令调整：简化 / 拆步"
          /><el-option value="replace_material" label="替换材料" />
          <el-option value="add_demonstration" label="增加示范" /><el-option
            value="adjust_next_activity"
            label="调整后续活动"
          /> </el-select
      ></label>
      <label
        >调整任务<el-select
          v-model="targetTaskId"
          placeholder="选择尚未结束的任务"
        >
          <el-option
            v-for="task in eligible"
            :key="task.id"
            :value="task.id"
            :label="task.title"
          /> </el-select
      ></label>
      <label v-if="action === 'replace_material'"
        >替换为<el-select
          v-model="replacementMaterial"
          placeholder="选择本课已有材料"
        >
          <el-option
            v-for="material in lesson.available_materials"
            :key="material.id"
            :value="material.id"
            :label="material.name"
          /> </el-select
      ></label>
    </div>
    <el-radio-group
      v-if="action === 'simplify_instruction'"
      v-model="instructionMode"
      aria-label="指令调整方式"
    >
      <el-radio-button value="simplify">简化说法</el-radio-button>
      <el-radio-button value="split" :disabled="!splitAllowed">实时拆成多步</el-radio-button>
    </el-radio-group>
    <p v-if="!splitAllowed && action === 'simplify_instruction'" class="subtle">需要拆分时，请先打开该任务的“拆分指令”开关。</p>
    <template v-if="splitAllowed && target && action !== 'adjust_next_activity'">
      <p class="subtle">可选具体步骤，留空表示整个任务。</p>
      <el-checkbox-group v-model="selectedSteps"
        ><el-checkbox
          v-for="step in target.steps"
          :key="step.id"
          :value="step.id"
          >{{ step.order }}. {{ step.instruction }}</el-checkbox
        ></el-checkbox-group
      >
    </template>
    <el-input
      v-model="teacherRequest"
      type="textarea"
      :rows="2"
      :placeholder="
        instructionMode === 'split' && action === 'simplify_instruction'
          ? '例如：把归位操作拆成找标记、走到书架、放入绘本三个步骤。'
          : '例如：把指令缩短，保留动作或手势回应方式。'
      "
    />
    <Button
      variant="secondary"
      :loading="running"
      :disabled="
        disabled ||
        !available ||
        !targetTaskId ||
        (action === 'replace_material' && !replacementMaterial)
      "
      @click="generate"
      >生成调整建议</Button
    >
    <p v-if="!eligible.length" class="subtle">当前没有符合范围的待调整任务。</p>
    <JobStatus
      :job="job"
      :running="running"
      :error="error"
      :pending="hasPending"
      @retry="retry"
      @resume="resume"
      @poll="poll"
    />
    <div v-if="proposal && !job?.applied_resource" class="agent-preview">
      <p v-if="stale" class="preview-notice">
        课堂资料已更新，这份建议来自旧版本，请按最新资料重新生成。
      </p>
      <h3>{{ proposal.summary }}</h3>
      <p>{{ proposal.reason }}</p>
      <article
        v-for="update in proposal.task_updates"
        :key="update.task_id"
        class="agent-task-preview"
      >
        <h4>{{ update.replacement.title }}</h4>
        <p>
          材料：{{
            update.replacement.material_ids.map(materialName).join("、")
          }}
        </p>
        <div v-if="update.step_splits?.length" class="preview-notice">
          <p v-for="split in update.step_splits" :key="split.source_step_id">
            原步骤“{{
              tasks
                .find((t) => t.id === update.task_id)
                ?.steps.find((s) => s.id === split.source_step_id)?.instruction
            }}” →
            {{
              split.replacement_step_ids.length
            }}
            个独立步骤。采用后从第一个新步骤继续，已有记录保留原教案版本。
          </p>
        </div>
        <div
          v-for="step in update.replacement.steps"
          :key="step.id"
          class="agent-step-comparison"
        >
          <p
            v-if="
              tasks
                .find((t) => t.id === update.task_id)
                ?.steps.some((s) => s.id === step.id)
            "
            class="subtle"
          >
            原指令：{{
              tasks
                .find((t) => t.id === update.task_id)
                ?.steps.find((s) => s.id === step.id)?.instruction
            }}
          </p>
          <p>
            <strong>{{ step.order }}. </strong>{{ step.instruction }}
          </p>
          <p v-if="step.demonstration">示范：{{ step.demonstration }}</p>
        </div>
      </article>
      <p v-if="proposal.resource_updates.length" class="subtle">
        同步更新资料：{{
          proposal.resource_updates.map((resource) => resource.title).join("、")
        }}
      </p>
      <template v-if="proposal.future_activity_replacement"
        ><h4>后续活动安排</h4>
        <article
          v-for="activity in proposal.future_activity_replacement.activities"
          :key="activity.id"
          class="agent-task-preview"
        >
          <h4>{{ activity.title }} · {{ activity.duration_min }} 分钟</h4>
          <div v-for="task in activity.tasks" :key="task.id">
            <strong>{{ task.title }}</strong>
            <p>{{ task.objective }}</p>
            <ol>
              <li v-for="step in task.steps" :key="step.id">
                {{ step.instruction
                }}<span v-if="step.demonstration">
                  · 示范：{{ step.demonstration }}</span
                >
              </li>
            </ol>
          </div>
        </article>
      </template>
      <Button
        variant="secondary"
        :loading="saving"
        :disabled="disabled || running || stale"
        @click="adopt"
        >确认采用并更新课堂</Button
      >
    </div>
    <p v-if="saveError" class="inline-error" role="alert">{{ saveError }}</p>
    <details v-if="history.length">
      <summary>已采用的调整（{{ history.length }}）</summary>
      <p v-for="entry in history" :key="entry.id">
        教案 v{{ entry.from_plan_version }} → v{{ entry.to_plan_version }}：{{
          entry.summary
        }}
      </p>
    </details>
  </section>
</template>
