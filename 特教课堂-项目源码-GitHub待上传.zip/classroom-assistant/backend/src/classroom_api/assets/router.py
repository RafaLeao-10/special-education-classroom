from classroom_contracts.http import Envelope, Items
from classroom_contracts.models import Asset
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from classroom_api.auth.service import require_user
from classroom_api.db import get_db
from classroom_api.display.state import by_token, image_ids
from classroom_api.errors import BusinessError

from . import service
from .models import AssetRow

router = APIRouter(tags=["assets"])


@router.post("/assets", status_code=201, response_model=Envelope[Asset], dependencies=[Depends(require_user)])
async def upload(
    request: Request,
    file: UploadFile = File(...),
    alt: str = Form(""),
    db: Session = Depends(get_db),
    user=Depends(require_user),
):
    data = await file.read()
    return Envelope(
        data=await run_in_threadpool(service.store,
            db,
            request.app.state.settings.asset_dir,
            file.filename or "图片",
            file.content_type,
            alt,
            data,
            user.id,
        )
    )


@router.get("/assets", response_model=Envelope[Items[Asset]], dependencies=[Depends(require_user)])
def listing(request: Request, db: Session = Depends(get_db), user=Depends(require_user)):
    return Envelope(
        data=Items(
            items=[
                service.to_dto(r, folder=request.app.state.settings.asset_dir)
                for r in db.scalars(
                    select(AssetRow).where(AssetRow.owner_id == user.id).order_by(AssetRow.name, AssetRow.id)
                )
            ]
        )
    )


@router.get("/assets/{id}/content", response_class=FileResponse)
def content(id: str, request: Request, display_token: str | None = None, preview: bool = False, page: int | None = None, db: Session = Depends(get_db)):
    owner_id = None
    if display_token:
        if id not in image_ids(by_token(db, display_token)):
            raise BusinessError(404, "NOT_FOUND", "当前展示未使用此素材")
    else:
        owner_id = require_user(request, db).id
    row = service.get(db, id, owner_id=owner_id)
    path = request.app.state.settings.asset_dir / row.storage_name
    if page is not None:
        pages = service.slide_files(request.app.state.settings.asset_dir, row.storage_name)
        if page < 1 or page > len(pages):
            raise BusinessError(404, "NOT_FOUND", "课件页不存在")
        return FileResponse(pages[page - 1], media_type="image/png")
    if preview and row.mime_type not in service.IMAGE_TYPES:
        path = path.with_suffix(".pdf")
        if not path.is_file():
            raise BusinessError(404, "NOT_FOUND", "课件预览文件缺失，请重新上传")
        return FileResponse(path, media_type="application/pdf", content_disposition_type="inline")
    if not path.is_file():
        raise BusinessError(404, "NOT_FOUND", "素材文件缺失，请恢复素材目录")
    return FileResponse(path, media_type=row.mime_type)
