export function localTimeInput(value: string) {
  const date = new Date(value);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}
export function isoFromLocal(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error("请填写有效的发生时间");
  return date.toISOString();
}
