<script setup lang="ts">
import { onMounted, ref } from "vue";
import { reportsApi, type ReportArchive } from "../../api/services/reports";
import { studentsApi, type Student } from "../../api/services/students";
import { archiveFilters } from "./archiveFilters";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
const archive = ref<ReportArchive>();
const students = ref<Student[]>([]);
const query = ref("");
const studentId = ref("");
const status = ref("");
const from = ref("");
const to = ref("");
const loading = ref(false);
const error = ref("");
let sequence = 0;
async function load(page = 1) {
  const serial = ++sequence;
  loading.value = true;
  error.value = "";
  try {
    const result = await reportsApi.archive(
      archiveFilters(
        query.value,
        studentId.value,
        status.value,
        from.value,
        to.value,
        page,
      ),
    );
    if (serial === sequence) archive.value = result;
  } catch (e) {
    if (serial === sequence) error.value = (e as Error).message;
  } finally {
    if (serial === sequence) loading.value = false;
  }
}
function reset() {
  query.value = studentId.value = status.value = from.value = to.value = "";
  void load();
}
onMounted(async () => {
  try {
    students.value = (await studentsApi.list()).items;
  } catch (e) {
    error.value = (e as Error).message;
  }
  await load();
});
</script>
<template>
  <div class="page-title">
    <div>
      <router-link to="/" class="back-link">← 返回工作台</router-link>
      <span class="stage-tag stage-lavender">课后 · 报告</span>
      <h1>把课堂里的成长，好好留存</h1>
      <p class="page-description">按学生、日期和状态，查阅每一次已保存报告。</p>
    </div>
    <span class="feature-emblem lavender"
      ><AppIcon name="report" :size="30"
    /></span>
  </div>
  <section class="report-archive-intro">
    <div>
      <p class="eyebrow">报告档案室</p>
      <h2>你的报告档案室</h2>
      <p>找到 {{ archive?.total || 0 }} 份报告</p>
      <span class="status-pill">每份报告保留自己的正文、统计与来源</span>
    </div>
    <AppIcon name="report" :size="65" />
  </section>
  <section class="archive-search">
    <div class="archive-filter-grid">
      <label
        >课程或报告内容<el-input
          v-model="query"
          clearable
          placeholder="输入课程名或报告概览关键词"
          aria-label="报告关键词"
          @keyup.enter="load()" /></label
      ><label
        >参与学生<el-select
          v-model="studentId"
          clearable
          placeholder="全部学生"
          aria-label="筛选报告学生"
          @change="load()"
          ><el-option
            v-for="s in students"
            :key="s.id"
            :value="s.id"
            :label="s.name" /></el-select></label
      ><label
        >报告状态<el-select
          v-model="status"
          clearable
          placeholder="全部状态"
          aria-label="筛选报告状态"
          @change="load()"
          ><el-option value="draft" label="草稿" /><el-option
            value="confirmed"
            label="已确认" /><el-option
            value="stale"
            label="记录已更新" /></el-select></label
      ><label
        >报告保存日期 从<el-date-picker
          v-model="from"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="开始日期"
          aria-label="报告开始日期" /></label
      ><label
        >至<el-date-picker
          v-model="to"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="结束日期（含当天）"
          aria-label="报告结束日期"
      /></label>
    </div>
    <div class="report-actions">
      <Button variant="primary" :loading="loading" @click="load()"
        >查询报告</Button
      ><Button variant="secondary" :disabled="loading" @click="reset"
        >清空筛选</Button
      >
    </div>
  </section>
  <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
  <p v-if="loading" class="subtle">正在查询报告…</p>
  <section
    v-else-if="archive && !archive.items.length && !error"
    class="empty-state"
  >
    <h2>没有匹配的报告</h2>
    <p>可以调整学生、日期或关键词，也可以从已结课课程填写报告。</p>
  </section>
  <div v-if="archive" class="lesson-grid">
    <router-link
      v-for="report in archive.items"
      :key="report.id"
      :to="{
        path: `/lessons/${report.lesson_id}/report`,
        query: { report_id: report.id },
      }"
      class="lesson-card"
      ><div class="entry-top">
        <span class="entry-icon lavender"><AppIcon name="report" /></span
        ><span class="status-pill"
          >{{ report.status === "confirmed" ? "已确认" : "草稿"
          }}{{ report.is_stale ? " · 记录已更新" : "" }}</span
        >
      </div>
      <h3>{{ report.lesson_title }}</h3>
      <p>{{ report.student_names.join("、") }}</p>
      <p class="report-card-excerpt">{{ report.overview }}</p>
      <p class="subtle">
        {{
          new Date(report.generated_at).toLocaleString("zh-CN", {
            hour12: false,
          })
        }}
      </p>
      <span class="entry-link"
        >打开这份报告 <AppIcon name="arrow" :size="18" /></span
    ></router-link>
  </div>
  <el-pagination
    v-if="archive && archive.total > archive.page_size"
    :current-page="archive.page"
    :page-size="archive.page_size"
    :total="archive.total"
    layout="prev,pager,next"
    @current-change="load"
  />
  <details
    v-if="archive?.unreported_lessons.length"
    class="editor-details pending-reports"
  >
    <summary>
      待填写报告的已结课课程（{{ archive.unreported_lessons.length }}节）
    </summary>
    <router-link
      v-for="lesson in archive.unreported_lessons"
      :key="lesson.id"
      :to="`/lessons/${lesson.id}/report`"
      class="list-row"
      ><strong>{{ lesson.title }}</strong
      ><span>回顾课堂记录并填写报告 →</span></router-link
    >
  </details>
</template>
