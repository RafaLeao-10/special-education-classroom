import { client, unwrap } from "../client";
export const displayApi = {
  link: async (id: string) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/display-link", {
        params: { path: { id } },
        body: {},
      }),
    ),
  state: async (token: string) =>
    unwrap(
      await client.GET("/api/v1/display/{token}", {
        params: { path: { token } },
      }),
    ),
};
