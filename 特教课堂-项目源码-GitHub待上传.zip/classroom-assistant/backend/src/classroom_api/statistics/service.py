import httpx
from classroom_contracts.models import StatisticsRow
from classroom_contracts.teaching import LessonStatistics, StatisticsInput
from pydantic import TypeAdapter, ValidationError

from classroom_api.errors import BusinessError
from classroom_api.lessons import service as lessons
from classroom_api.records import service as records


async def calculate(app, lesson_id):
    # Close the read snapshot before HTTP. Report writes subsequently check these versions.
    with app.state.sessions.begin() as db:
        lesson = lessons.to_dto(lessons.get(db, lesson_id))
        body = StatisticsInput(records=records.listing(db, lesson_id))
    try:
        response = await app.state.teaching_client.post(
            "/internal/v1/statistics", json=body.model_dump(mode="json")
        )
        response.raise_for_status()
        rows = TypeAdapter(list[StatisticsRow]).validate_python(response.json())
    except (httpx.HTTPError, ValidationError, ValueError) as exc:
        raise BusinessError(
            503, "STATISTICS_UNAVAILABLE", "统计服务暂不可用，请启动B服务后重试；已保存内容仍可读取"
        ) from exc
    return LessonStatistics(
        lesson_id=lesson_id,
        source_plan_version=lesson.plan_version,
        source_record_version=lesson.record_version,
        rows=rows,
    )
