from datetime import datetime

from classroom_api.db import Base
from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column


class JobRow(Base):
    __tablename__ = "ai_jobs"
    __table_args__ = (
        UniqueConstraint("lesson_id", "client_request_id", name="uq_job_client_request"),
        Index("ix_job_queue", "status", "created_at"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    creation_fingerprint: Mapped[str | None] = mapped_column(String(64), nullable=True)
    last_resume_request_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    last_resume_fingerprint: Mapped[str | None] = mapped_column(String(64), nullable=True)
    last_retry_revision: Mapped[int | None] = mapped_column(Integer, nullable=True)
    lesson_id: Mapped[str] = mapped_column(ForeignKey("lessons.id"), index=True)
    client_request_id: Mapped[str] = mapped_column(String(36))
    operation: Mapped[str] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20))
    params: Mapped[dict] = mapped_column(JSONB)
    input_snapshot: Mapped[dict] = mapped_column(JSONB)
    base_plan_version: Mapped[int] = mapped_column(Integer)
    base_record_version: Mapped[int] = mapped_column(Integer)
    questions: Mapped[list] = mapped_column(JSONB)
    answers: Mapped[list] = mapped_column(JSONB)
    result: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    error: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    applied_resource: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
