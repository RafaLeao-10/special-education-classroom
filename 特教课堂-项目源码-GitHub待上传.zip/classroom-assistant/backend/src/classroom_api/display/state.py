from sqlalchemy import select

from classroom_api.errors import BusinessError
from classroom_api.lessons.models import LessonRow


def by_token(db, token):
    row = db.scalar(select(LessonRow).where(LessonRow.display_token == token))
    if row is None:
        raise BusinessError(404, "NOT_FOUND", "展示链接不存在")
    return row


def current(row):
    if row.status != "in_progress" or not row.plan:
        return None
    for activity in row.plan["activities"]:
        for task in activity["tasks"]:
            if task["id"] != row.execution["display_task_id"]:
                continue
            if row.execution["display_step_id"] is None:
                return activity, task, None
            for step in task["steps"]:
                if step["id"] == row.execution["display_step_id"]:
                    return activity, task, step
    return None


def image_ids(row):
    item = current(row)
    if not item:
        return set()
    blocks = item[2]["display_blocks"] if item[2] else [
        b for step in item[1]["steps"] for b in step["display_blocks"]
    ]
    return {b["asset_id"] for b in blocks if b["type"] == "image"}
