from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from classroom_api.db import Base


class RecordRow(Base):
    __tablename__ = "classroom_records"
    __table_args__ = (UniqueConstraint("lesson_id", "client_record_id", name="uq_record_client"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    lesson_id: Mapped[str] = mapped_column(ForeignKey("lessons.id"), index=True)
    client_record_id: Mapped[str] = mapped_column(String(36))
    revision: Mapped[int] = mapped_column(Integer)
    is_void: Mapped[bool] = mapped_column(Boolean)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    details: Mapped[dict] = mapped_column(JSONB)


class RecordCorrectionRow(Base):
    __tablename__ = "record_corrections"
    record_id: Mapped[str] = mapped_column(ForeignKey("classroom_records.id"), primary_key=True)
    revision: Mapped[int] = mapped_column(Integer, primary_key=True)
    before: Mapped[dict] = mapped_column(JSONB)
    after: Mapped[dict] = mapped_column(JSONB)
    changed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    changed_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
