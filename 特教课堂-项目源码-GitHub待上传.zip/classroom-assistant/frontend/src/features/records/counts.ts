import type { ClassroomRecord } from "../../api/services/classroom";
export type Counts = NonNullable<ClassroomRecord["counts"]>;
export const countFields = [
  ["independent", "独立完成"],
  ["prompted", "提示后完成"],
  ["completed_unknown_prompt", "完成但提示不明"],
  ["not_completed", "未完成"],
  ["not_observed", "未观察"],
  ["not_run", "未实施"],
  ["unknown", "未知"],
] as const;
export const promptOptions = [
  ["verbal", "口头提示"],
  ["gestural", "手势提示"],
  ["model", "示范提示"],
  ["physical", "身体辅助"],
  ["other", "其他提示"],
] as const;
export function emptyCounts(): Counts {
  return Object.fromEntries(countFields.map(([k]) => [k, 0])) as Counts;
}
export function describeCounts(counts: Counts | null) {
  return counts
    ? countFields.map(([k, l]) => `${l} ${counts[k]}`).join(" · ")
    : "文字速记";
}
