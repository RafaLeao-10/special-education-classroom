from classroom_api.auth.access import require_lesson
from classroom_api.auth.service import require_user
from classroom_api.db import get_db
from classroom_contracts.http import (
    Envelope,
    Items,
    LessonCopy,
    LessonCreate,
    LessonPatch,
    LessonSummary,
    PlanInput,
)
from classroom_contracts.models import Lesson, PlanSnapshot
from classroom_contracts.planned import ExecutionPatch, ExecutionUpdated, LessonAction
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import copying, execution, history, service
from .models import LessonRow

router = APIRouter(prefix="/lessons", tags=["lessons"], dependencies=[Depends(require_user)])


@router.get("", response_model=Envelope[Items[LessonSummary]])
def listing(db: Session = Depends(get_db), user=Depends(require_user)):
    return Envelope(
        data=Items(
            items=[
                LessonSummary(id=row.id, title=row.title, status=row.status, updated_at=row.updated_at)
                for row in db.scalars(
                    select(LessonRow)
                    .where(LessonRow.owner_id == user.id)
                    .order_by(LessonRow.updated_at.desc())
                )
            ]
        )
    )


@router.post("", status_code=201, response_model=Envelope[Lesson])
def create(body: LessonCreate, db: Session = Depends(get_db), user=Depends(require_user)):
    return Envelope(data=service.create(db, body, user.id))


@router.get("/{id}", response_model=Envelope[Lesson], dependencies=[Depends(require_lesson)])
def read(id: str, db: Session = Depends(get_db)):
    return Envelope(data=service.to_dto(service.get(db, id)))


@router.patch("/{id}", response_model=Envelope[Lesson], dependencies=[Depends(require_lesson)])
def update(id: str, body: LessonPatch, db: Session = Depends(get_db)):
    return Envelope(data=service.update(db, id, body))


@router.put("/{id}/plan", response_model=Envelope[Lesson], dependencies=[Depends(require_lesson)])
def put_plan(id: str, body: PlanInput, db: Session = Depends(get_db)):
    return Envelope(data=service.put_plan(db, id, body))


@router.post("/{id}/actions", response_model=Envelope[Lesson], dependencies=[Depends(require_lesson)])
def action(id: str, body: LessonAction, db: Session = Depends(get_db)):
    return Envelope(data=execution.act(db, id, body))


@router.patch(
    "/{id}/execution", response_model=Envelope[ExecutionUpdated], dependencies=[Depends(require_lesson)]
)
def update_execution(id: str, body: ExecutionPatch, db: Session = Depends(get_db)):
    return Envelope(data=execution.update(db, id, body))


@router.get(
    "/{id}/plan-snapshots",
    response_model=Envelope[Items[PlanSnapshot]],
    dependencies=[Depends(require_lesson)],
)
def plan_snapshots(id: str, db: Session = Depends(get_db)):
    service.get(db, id)
    return Envelope(
        data=Items(
            items=[
                PlanSnapshot(
                    plan_version=r.plan_version,
                    plan=r.plan,
                    student_snapshots=r.student_snapshots,
                    snapshot_origin=r.snapshot_origin,
                )
                for r in history.snapshots(db, id)
            ]
        )
    )


@router.post(
    "/{id}/copies", status_code=201, response_model=Envelope[Lesson], dependencies=[Depends(require_lesson)]
)
def copy(id: str, body: LessonCopy, db: Session = Depends(get_db)):
    return Envelope(data=copying.copy_lesson(db, id, body))
