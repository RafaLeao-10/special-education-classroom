import { onMounted, onUnmounted, type Ref } from "vue";
import { onBeforeRouteLeave } from "vue-router";
export function useUnsavedChanges(dirty: Ref<boolean>) {
  const beforeUnload = (event: BeforeUnloadEvent) => {
    if (dirty.value) {
      event.preventDefault();
      event.returnValue = "";
    }
  };
  onMounted(() => window.addEventListener("beforeunload", beforeUnload));
  onUnmounted(() => window.removeEventListener("beforeunload", beforeUnload));
  onBeforeRouteLeave(
    () => !dirty.value || window.confirm("还有尚未保存的内容，确定离开吗？"),
  );
}
