export interface GraphNode {
  id: string;
  label: string;
  type: string;
  summary: string;
  detail:string;
  points:string[];
  audience:string;
  source_url: string | null;
  source_title: string;
  source_locator: string;
  review_status: "draft" | "reviewed";
}
export interface GraphEdge {
  source: string;
  target: string;
  relation: string;
}
export interface KnowledgeGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}
