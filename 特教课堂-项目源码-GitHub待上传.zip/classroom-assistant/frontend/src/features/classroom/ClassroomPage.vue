<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import AppIcon from "../../components/AppIcon.vue";
import RecordNotebook from "../records/RecordNotebook.vue";
import { useUnsavedChanges } from "../../app/useUnsavedChanges";
import CloneLessonDialog from "../lessons/CloneLessonDialog.vue";
import PresentationPanel from "./PresentationPanel.vue";
import FocusTask from "./FocusTask.vue";
import AdjustmentPanel from "./AdjustmentPanel.vue";
import { useClassroom } from "./useClassroom";
import ProjectorDialog from "./ProjectorDialog.vue";
import { useClassroomShortcuts } from "./useShortcuts";
import { pendingCounts } from "../records/pendingCounts";
import TimerBar from "./TimerBar.vue";
import { useLessonTimer } from "./useLessonTimer";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

const id = String(useRoute().params.id);
const router = useRouter();
const noteDirty = ref(false);
const projectorOpen = ref(false);
const helpVisible = ref(false);
const adjustmentOpen = ref(false);
const notesOpen = ref(false);
const slidesOpen = ref(false);
useUnsavedChanges(noteDirty);
const {
  lesson,
  students,
  mode,
  loading,
  busy,
  error,
  sequence,
  index,
  current,
  currentState,
  load,
  begin,
  move,
  activate,
  completeTask,
  toggleSplit,
  finish,
  skipTask,
} = useClassroom(id);
const timer = useLessonTimer(id, {
  inProgress: computed(() => lesson.value?.status === "in_progress"),
  plannedMin: computed(() => lesson.value?.planned_duration_min ?? 0),
  currentActivity: computed(() => current.value?.activity),
});
const taskCount = computed(
  () =>
    lesson.value?.plan?.activities.reduce((n, a) => n + a.tasks.length, 0) || 0,
);
const labels = {
  draft: "教案草稿",
  ready: "教案已确认",
  in_progress: "课堂进行中",
  completed: "课堂已结束",
};
async function endClass() {
  // 结课后先到小结页看清单；报告从小结页底部进入
  if (await finish()) await router.push(`/lessons/${id}/review`);
}

const shortcutEnabled = computed(
  () =>
    mode.value === "focus" &&
    lesson.value?.status === "in_progress" &&
    !adjustmentOpen.value &&
    !loading.value,
);
useClassroomShortcuts(shortcutEnabled, {
  prev: () => move(-1),
  next: () => move(1),
  toggleTask: () => {
    const st = currentState.value;
    if (st === "pending") void activate();
    else if (st === "active") void completeTask();
    else void move(1);
  },
  quickCount: (key) => {
    pendingCounts.value[key] += 1;
  },
  toggleSplit: () => {
    if (!current.value) return;
    const split =
      lesson.value?.execution.split_task_ids?.includes(current.value.task.id) ??
      false;
    void toggleSplit(current.value.task.id, !split);
  },
  help: () => {
    helpVisible.value = true;
  },
});
onMounted(load);
</script>
<template>
  <div class="page-title">
    <div>
      <router-link to="/classroom" class="back-link"
        >← 返回课堂教案</router-link
      >
      <span class="stage-tag stage-sand">课中 · 课堂</span>
      <h1>{{ lesson?.title || "课堂工作台" }}</h1>
      <p class="page-description">先看见全课的方向，再照顾眼前的每一步。</p>
    </div>
    <ButtonGroup>
    <Button variant="ghost" :disabled="busy" @click="load">重新读取</Button>
    <CloneLessonDialog
      v-if="lesson"
      :lesson="lesson"
      :disabled="busy || noteDirty"
    />
    <Button :to="`/lessons/${id}/print`" variant="ghost">打印教案</Button>
    <Button v-if="mode === 'focus'" variant="secondary" @click="mode = 'outline'"
      >回顾全课大纲</Button
    >
    <Button variant="secondary" @click="projectorOpen = true"
      >投屏大屏</Button
    >
  </ButtonGroup>
  </div>
  <p v-if="error" role="alert" class="inline-error">{{ error }}</p>
  <p v-if="loading" class="subtle">正在读取课堂…</p>
  <section v-else-if="!lesson?.plan" class="empty-state">
    <AppIcon name="book" :size="34" />
    <h2>这堂课还没有保存教案</h2>
    <Button :to="`/lessons/${id}/prepare`" variant="primary">去完成备课</Button>
  </section>
  <template v-else>
    <div class="classroom-status-bar">
      <span class="status-pill">{{ labels[lesson.status] }}</span>
      <span class="subtle">进度与已保存速记会保留，刷新后可继续。</span>
      <Button
        v-if="lesson.status === 'completed'"
        :to="`/lessons/${id}/report`"
        variant="ghost"
        size="sm"
        class="btn-arrow"
        >查看课堂回顾与报告 <AppIcon name="arrow" :size="16" /></Button
      >
    </div>
    <TimerBar
      v-if="lesson.status === 'in_progress'"
      :elapsed-text="timer.elapsedText.value"
      :elapsed-pct="timer.elapsedPct.value"
      :planned-min="lesson.planned_duration_min"
      :activity-title="current?.activity.title ?? ''"
      :activity-remain-text="timer.activityRemainText.value"
      :activity-over="timer.activityOver.value"
    />
    <template v-if="mode === 'outline'">
      <div class="outline-summary">
        <div>
          <span>计划时长</span
          ><strong
            >{{ lesson.planned_duration_min }}<small> 分钟</small></strong
          >
        </div>
        <div>
          <span>教学活动</span
          ><strong
            >{{ lesson.plan.activities.length }}<small> 个</small></strong
          >
        </div>
        <div>
          <span>具体任务</span
          ><strong>{{ taskCount }}<small> 项</small></strong>
        </div>
        <div>
          <span>可用材料</span
          ><strong
            >{{ lesson.available_materials.length }}<small> 种</small></strong
          >
        </div>
      </div>
      <div class="classroom-outline-layout">
        <section class="outline-panel">
          <p class="eyebrow">全课大纲</p>
          <h2>全课大纲与任务</h2>
          <article
            v-for="activity in lesson.plan.activities"
            :key="activity.id"
            class="outline-activity"
          >
            <span class="activity-number">{{
              String(activity.order).padStart(2, "0")
            }}</span>
            <div>
              <div class="activity-heading">
                <h3>{{ activity.title }}</h3>
                <span>{{ activity.duration_min }} 分钟</span>
              </div>
              <div
                v-for="task in activity.tasks"
                :key="task.id"
                class="outline-task"
              >
                <h4>{{ task.title }}</h4>
                <p>{{ task.objective }}</p>
                <el-switch :model-value="lesson.execution.split_task_ids?.includes(task.id) || false"
                  :disabled="busy || noteDirty || lesson.status !== 'in_progress'"
                  active-text="拆分指令" :aria-label="`${task.title}拆分指令`"
                  @update:model-value="toggleSplit(task.id, Boolean($event))" />
                <p v-if="lesson.status !== 'in_progress'" class="subtle">开课后可按任务开启拆分指令。</p>
                <ol v-if="lesson.execution.split_task_ids?.includes(task.id)">
                  <li v-for="step in task.steps" :key="step.id">
                    {{ step.instruction }}
                  </li>
                </ol>
                <div v-else><p v-for="detail in task.steps" :key="detail.id">{{ detail.instruction }}</p></div>
              </div>
            </div>
          </article>
        </section>
        <section class="classroom-ready">
          <span class="feature-emblem sand"
            ><AppIcon name="classroom" :size="28"
          /></span>
          <h2>
            {{
              lesson.status === "completed"
                ? "这一堂课，值得回望"
                : "准备好，开始这一堂课"
            }}
          </h2>
          <p>
            正式开课后展示完整任务说明，需要时逐任务开启拆分指令；旁边保留课件、观察和速记空间。
          </p>
          <Button
            v-if="['draft', 'ready'].includes(lesson.status)"
            variant="primary"
            :loading="busy"
            :disabled="!sequence.length"
            @click="begin"
            >{{
              lesson.status === "draft" ? "确认教案并开课" : "开始课堂"
            }}</Button
          >
          <Button
            v-if="lesson.status === 'in_progress'"
            variant="primary"
            @click="mode = 'focus'"
            >继续课堂</Button
          >
          <Button
            v-if="lesson.status === 'completed'"
            :to="`/lessons/${id}/report`"
            variant="primary"
            >课后回顾与报告</Button
          >
          <div class="ready-materials">
            <h3>课前材料清单</h3>
            <p
              v-for="material in lesson.available_materials"
              :key="material.id"
            >
              <AppIcon name="check" :size="15" />{{ material.name
              }}<span v-if="material.quantity !== null"
                >× {{ material.quantity }}</span
              >
            </p>
          </div>
          <Button
            v-if="['draft', 'ready'].includes(lesson.status)"
            :to="`/lessons/${id}/prepare`"
            variant="ghost"
            size="sm"
            >返回调整教案</Button
          >
        </section>
      </div>
    </template>
    <div v-else-if="current" :class="['classroom-focus-layout', { 'has-drawer': notesOpen || slidesOpen }]">
      <div class="classroom-focus-main">
        <div v-if="lesson.status === 'in_progress'" class="adjustment-launch">
          <Button variant="primary" size="md" @click="adjustmentOpen = true">✦ 智能调整</Button>
        </div>
        <FocusTask
          v-bind="current"
          :index="index"
          :total="sequence.length"
          :status="currentState"
          :busy="busy || noteDirty || lesson.status !== 'in_progress'"
          :split="lesson.execution.split_task_ids?.includes(current.task.id) || false"
          @split="toggleSplit(current.task.id, $event)"
          @previous="move(-1)"
          @next="move(1)"
          @activate="activate"
          @complete="completeTask"
          @skip="skipTask"
        />
        <p class="shortcut-hint">
          键盘操作：← → 切换 · Enter 开始/结束 · 1-4 计数 · S 拆分 · ? 帮助
        </p>
        <div class="classroom-finish">
          <div>
            <h3>准备好回顾这一堂课了吗？</h3>
            <p class="subtle">
              请先保存速记。结课后可补充、更正记录并保存报告；未结束任务标记为跳过。
            </p>
          </div>
          <Button variant="secondary" :loading="busy" @click="endClass"
            >结束课堂并回顾</Button
          >
        </div>
      </div>
      <aside :class="['classroom-drawer', { 'is-open': notesOpen || slidesOpen }]" aria-label="课堂侧边工具">
        <div class="drawer-tabs">
          <button type="button" :aria-expanded="notesOpen" aria-controls="classroom-notes" @click="notesOpen = !notesOpen"><span>{{ notesOpen ? '›' : '‹' }}</span> 课堂速记</button>
          <button type="button" :aria-expanded="slidesOpen" aria-controls="classroom-slides" @click="slidesOpen = !slidesOpen"><span>{{ slidesOpen ? '›' : '‹' }}</span> PPT 课件</button>
        </div>
        <div v-show="notesOpen || slidesOpen" class="drawer-content">
          <div id="classroom-notes" v-show="notesOpen" class="drawer-panel drawer-notes">
      <RecordNotebook
        :lesson="lesson"
        :students="students"
        :activity-id="current.activity.id"
        :task-id="current.task.id"
        :step-id="lesson.execution.split_task_ids?.includes(current.task.id) ? current.step.id : undefined"
        @saved="lesson.record_version = Math.max(lesson.record_version, $event)"
        @dirty="noteDirty = $event"
      />
          </div>
          <div id="classroom-slides" v-show="slidesOpen" :class="['drawer-panel', 'drawer-slides', { 'is-solo': !notesOpen }]">
            <PresentationPanel :lesson-id="id" />
          </div>
        </div>
      </aside>
    </div>
    <el-dialog v-if="current && lesson.status === 'in_progress'" v-model="adjustmentOpen" title="智能调整" width="min(760px, 92vw)" class="classroom-adjustment-dialog">
      <AdjustmentPanel
        :lesson="lesson"
        :current-task-id="current.task.id"
        :current-step-id="lesson.execution.split_task_ids?.includes(current.task.id) ? current.step.id : undefined"
        :disabled="busy || noteDirty"
        @adopted="load"
      />
    </el-dialog>
  </template>
      <ProjectorDialog
        v-model="projectorOpen"
        :lesson-id="id"
        :default-duration-min="
          current?.activity.duration_min ?? lesson?.planned_duration_min ?? 25
        "
      />
      <el-dialog v-model="helpVisible" title="课堂快捷键" width="420px">
        <table class="shortcut-help">
          <tr><td><kbd>←</kbd> / <kbd>→</kbd></td><td>切换上一个 / 下一个教学节点</td></tr>
          <tr><td><kbd>Enter</kbd></td><td>开始当前任务 / 结束当前任务并继续 / 下一项</td></tr>
          <tr><td><kbd>1</kbd> <kbd>2</kbd> <kbd>3</kbd> <kbd>4</kbd></td><td>快捷计数：独立 / 提示后 / 未完成 /未知</td></tr>
          <tr><td><kbd>S</kbd></td><td>开关当前任务的拆分指令</td></tr>
          <tr><td><kbd>?</kbd></td><td>显示本帮助</td></tr>
        </table>
      </el-dialog>
</template>

<style scoped>
.classroom-focus-layout { display: block; }
.classroom-focus-main { width: min(100%, 1080px); margin: 0 auto; }
.classroom-focus-main :deep(.focus-task) { background: #f3f7ef; border: 1px solid #dce8d8; border-radius: 22px; padding: clamp(24px, 4vw, 44px); }
.classroom-focus-main :deep(.focus-task h2) { font-size: clamp(26px, 3vw, 34px); }
.adjustment-launch { display: flex; justify-content: center; margin: 0 0 12px; }
.adjustment-launch :deep(.btn) { min-width: 148px; }
@media (min-width: 1050px) { .classroom-focus-layout.has-drawer { padding-right: min(400px, 34vw); } }
.classroom-drawer { position: fixed; right: 0; top: 0; z-index: 100; height: 100dvh; width: 0; transition: width .2s ease; }
.classroom-drawer.is-open { width: min(440px, calc(100vw - 64px)); box-shadow: -12px 0 32px rgba(49, 69, 58, .13); }
.drawer-tabs { position: absolute; top: 32%; right: 100%; display: grid; gap: 8px; }
.drawer-tabs button { width: 48px; min-height: 108px; padding: 10px 7px; border: 1px solid #d6e2d8; border-right: 0; border-radius: 12px 0 0 12px; background: #f2f7f1; color: #415f51; font: inherit; cursor: pointer; writing-mode: vertical-rl; letter-spacing: .08em; }
.drawer-tabs button:nth-child(2) { background: #eef4f3; }
.drawer-tabs button span { font-size: 22px; line-height: 1; writing-mode: horizontal-tb; }
.drawer-tabs button:focus-visible { outline: 3px solid #72957d; outline-offset: 2px; }
.drawer-content { display: flex; flex-direction: column; height: 100%; background: #f6f8f4; }
.drawer-panel { flex: 1 1 0; min-height: 0; overflow: auto; padding: 20px; }
.drawer-notes { background: #faf8f0; }
.drawer-slides { background: #eef5f3; }
.drawer-slides.is-solo { display: flex; flex-direction: column; }
.drawer-slides.is-solo :deep(.presentation-panel) { width: 100%; margin-block: auto; }
.drawer-panel + .drawer-panel { border-top: 1px solid #d6e2dc; }
.drawer-panel :deep(.notes-panel), .drawer-panel :deep(.presentation-panel) { background: transparent; border: 0; box-shadow: none; padding: 0; }
:global(.classroom-adjustment-dialog .agent-panel) { margin-top: 0; background: #f0f6f1; }
@media (max-width: 600px) { .classroom-focus-main { padding-right: 36px; } .drawer-tabs button { width: 40px; } .drawer-panel { padding: 16px; } }
</style>
