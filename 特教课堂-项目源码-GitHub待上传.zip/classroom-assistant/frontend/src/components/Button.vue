<script setup lang="ts">
import { RouterLink, type RouteLocationRaw } from "vue-router";
import AppIcon from "./AppIcon.vue";

withDefaults(
defineProps<{
    /** 层级：primary 主 / secondary 次 / ghost 轻 / quiet 回避（提示词 §2）*/
    variant?: "primary" | "secondary" | "ghost" | "quiet";
    /** 尺寸：sm 38 / md 46 / lg 56（提示词 §3）*/
    size?: "sm" | "md" | "lg";
    /** AppIcon 图标名，没有就纯文字（提示词 §10：不是每个按钮都需要图标）*/
    icon?: string;
    loading?: boolean;
    disabled?: boolean;
    /** 撑满容器宽度（底部固定操作条、移动端整行主操作用，提示词 §4.6）*/
    block?: boolean;
    nativeType?: "button" | "submit";
    /** B5 新增：传了 to 就渲染成 router-link（站内导航），不传还是普通 button */
    to?: RouteLocationRaw;
    /** B5 新增：传了 href 就渲染成 <a target="_blank">（打开外部文件/链接）*/
    href?: string;
}>(),
{ variant: "secondary", size: "md", nativeType: "button" }
);

const emit = defineEmits<{ click: [ev: MouseEvent] }>();
</script>

<template>
<RouterLink
    v-if="to"
    :to="to"
    class="btn"
    :class="[`btn-${variant}`, `btn-${size}`, { 'is-loading': loading, 'is-block': block }]"
    :aria-busy="loading || undefined"
    @click="emit('click', $event)"
>
    <span v-if="loading" class="btn-spinner" aria-hidden="true"></span>
    <AppIcon v-else-if="icon" :name="icon" class="btn-icon" />
    <slot />
</RouterLink>
<a
    v-else-if="href"
    :href="href"
    target="_blank"
    rel="noopener"
    class="btn"
    :class="[`btn-${variant}`, `btn-${size}`, { 'is-loading': loading, 'is-block': block }]"
    :aria-busy="loading || undefined"
    @click="emit('click', $event)"
>
    <span v-if="loading" class="btn-spinner" aria-hidden="true"></span>
    <AppIcon v-else-if="icon" :name="icon" class="btn-icon" />
    <slot />
</a>
<button
    v-else
    class="btn"
    :class="[`btn-${variant}`, `btn-${size}`, { 'is-loading': loading, 'is-block': block }]"
    :aria-busy="loading || undefined"
    :type="nativeType"
    :disabled="disabled"
    @click="emit('click', $event)"
>
    <span v-if="loading" class="btn-spinner" aria-hidden="true"></span>
    <AppIcon v-else-if="icon" :name="icon" class="btn-icon" />
    <slot />
</button>
</template>