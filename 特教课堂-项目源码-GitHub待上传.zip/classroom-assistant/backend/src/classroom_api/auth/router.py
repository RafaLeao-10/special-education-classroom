from classroom_api.db import get_db
from classroom_contracts.http import Empty, Envelope, LoginInput, Ok, User, UserData
from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session

from . import service
from .models import SessionRow, UserRow

router = APIRouter(prefix="/auth", tags=["auth"])


def user_data(user: UserRow):
    return UserData(user=User(id=user.id, name=user.name))


@router.post("/login", response_model=Envelope[UserData])
def login(body: LoginInput, request: Request, response: Response, db: Session = Depends(get_db)):
    user, token = service.login(db, body.username, body.password, request.app.state.settings)
    response.set_cookie(service.COOKIE, token, httponly=True, samesite="lax", max_age=43200)
    return Envelope(data=user_data(user))


@router.get("/me", response_model=Envelope[UserData])
def me(user: UserRow = Depends(service.require_user)):
    return Envelope(data=user_data(user))


@router.post("/logout", response_model=Envelope[Ok])
def logout(
    body: Empty,
    request: Request,
    response: Response,
    db: Session = Depends(get_db),
    user: UserRow = Depends(service.require_user),
):
    token = request.cookies[service.COOKIE]
    session = db.get(SessionRow, service.token_hash(token, request.app.state.settings))
    db.delete(session)
    response.delete_cookie(service.COOKIE)
    return Envelope(data=Ok(ok=True))
