import hashlib
import json
from datetime import UTC, datetime
from uuid import uuid4

from classroom_api.errors import BusinessError
from classroom_api.lessons import service as lessons
from classroom_contracts.agent import Answer, Question
from classroom_contracts.http import AgentJobCreate, AiJob
from classroom_contracts.models import Counts
from classroom_contracts.planned import JobResume, JobRetry, RecordPatch
from pydantic import TypeAdapter, ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from .context import build_context
from .models import JobRow


def to_dto(row: JobRow) -> AiJob:
    return AiJob.model_validate({name: getattr(row, name) for name in AiJob.model_fields})


def get(db: Session, id: str) -> JobRow:
    row = db.get(JobRow, id)
    if row is None:
        raise BusinessError(404, "NOT_FOUND", "生成任务不存在")
    return row


def fingerprint(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def require_phase(lesson, operation):
    allowed = {
        "prepare": ("draft",),
        "adjust": ("in_progress",),
        "report": ("completed",),
        "revise": ("draft",),
    }
    if lesson.status not in allowed[operation]:
        raise BusinessError(409, "INVALID_STATE", "课堂阶段已变化，请重新读取后再生成")


def require_no_active(db: Session, lesson_id: str, operation: str):
    active = db.scalar(
        select(JobRow.id).where(
            JobRow.lesson_id == lesson_id,
            JobRow.operation.in_(
                ("prepare", "revise") if operation in ("prepare", "revise") else (operation,)
            ),
            JobRow.status.in_(("queued", "running")),
        )
    )
    if active:
        raise BusinessError(409, "GENERATION_RUNNING", "本课已有同类生成任务，请恢复查询该任务")


def create(db: Session, lesson_id: str, body: AgentJobCreate) -> AiJob:
    lesson = lessons.get(db, lesson_id, lock=True)
    signature = fingerprint(body.model_dump(mode="json", exclude={"client_request_id"}))
    existing = db.scalar(
        select(JobRow).where(
            JobRow.lesson_id == lesson_id, JobRow.client_request_id == body.client_request_id
        )
    )
    if existing:
        if existing.operation != body.operation or (
            existing.creation_fingerprint and existing.creation_fingerprint != signature
        ):
            raise BusinessError(409, "REQUEST_CONFLICT", "同一提交标识不能用于不同的生成内容")
        return to_dto(existing)
    require_phase(lesson, body.operation)
    if body.operation == "adjust" and body.params.instruction_mode == "split":
        if not set(body.params.target_task_ids) <= set(lesson.execution.get("split_task_ids", [])):
            raise BusinessError(409, "INVALID_STATE", "请先打开目标任务的拆分指令开关")
    require_no_active(db, lesson_id, body.operation)
    id = str(uuid4())
    now = datetime.now(UTC)
    request = build_context(db, id, lessons.to_dto(lesson), body)
    row = JobRow(
        id=id,
        revision=1,
        creation_fingerprint=signature,
        lesson_id=lesson_id,
        client_request_id=body.client_request_id,
        operation=body.operation,
        status="queued",
        params=body.params.model_dump(),
        input_snapshot=request.model_dump(mode="json"),
        base_plan_version=lesson.plan_version,
        base_record_version=lesson.record_version,
        questions=[],
        answers=[],
        result=None,
        error=None,
        applied_resource=None,
        created_at=now,
        updated_at=now,
    )
    db.add(row)
    db.flush()
    return to_dto(row)


def resume(db: Session, id: str, body: JobResume, actor: str) -> AiJob:
    from classroom_api.records import service as records

    initial = get(db, id)
    lesson = lessons.get(db, initial.lesson_id, lock=True)
    row = db.scalar(
        select(JobRow).where(JobRow.id == id).with_for_update().execution_options(populate_existing=True)
    )
    signature = fingerprint(body.model_dump(mode="json", exclude={"client_request_id"}))
    if row.last_resume_request_id == body.client_request_id:
        if row.last_resume_fingerprint != signature:
            raise BusinessError(409, "REQUEST_CONFLICT", "同一补问提交标识的回答内容不同")
        return to_dto(row)
    if row.revision != body.expected_revision:
        raise BusinessError(409, "VERSION_CONFLICT", "补问已更新或已提交，请重新查询当前任务")
    if row.status != "needs_input":
        raise BusinessError(409, "INVALID_STATE", "该任务当前没有待回答的问题")
    require_no_active(db, lesson.id, row.operation)
    if (lesson.plan_version, lesson.record_version) != (row.base_plan_version, row.base_record_version):
        raise BusinessError(409, "VERSION_CONFLICT", "课堂资料已变化，请根据最新记录重新生成")
    questions = {q.id: q for q in map(Question.model_validate, row.questions)}
    answers = {a.question_id: a for a in body.answers}
    if len(answers) != len(body.answers) or not answers.keys() <= questions.keys():
        raise BusinessError(422, "INVALID_ARGUMENT", "补问答案重复或不属于本次问题")
    if any(q.required and q.id not in answers for q in questions.values()):
        raise BusinessError(422, "INVALID_ARGUMENT", "请回答本轮必要问题")
    params = dict(row.params)
    require_phase(lesson, row.operation)
    for key, answer in answers.items():
        question = questions[key]
        if question.answer_type == "counts":
            if not isinstance(answer.value, Counts) or question.target.kind != "record_counts":
                raise BusinessError(422, "INVALID_ARGUMENT", "观察计数补问需要填写七项计数")
            target = question.target
            record = records.to_dto(records.get(db, lesson.id, target.record_id))
            if record.is_void:
                raise BusinessError(409, "INVALID_STATE", "补问引用的观察记录已作废")
            records.update(
                db,
                lesson.id,
                target.record_id,
                RecordPatch(expected_revision=target.record_revision, counts=answer.value),
                actor,
            )
        else:
            if not isinstance(answer.value, str) or (question.required and not answer.value.strip()):
                raise BusinessError(422, "INVALID_ARGUMENT", "请填写补问答案")
            if question.answer_type == "single_choice" and answer.value not in {
                o.value for o in question.options
            }:
                raise BusinessError(422, "INVALID_ARGUMENT", "请选择补问提供的选项")
            if question.target.kind == "request":
                field = question.target.field.removeprefix("params.")
                if field == "teacher_request":
                    params[field] = params.get(field, "") + f"\n教师补充（{question.text}）：{answer.value}"
                elif field in params:
                    try:
                        params[field] = (
                            (
                                json.loads(answer.value)
                                if answer.value.strip().startswith("[")
                                else [answer.value]
                            )
                            if field.endswith("_ids")
                            else answer.value
                        )
                    except ValueError as exc:
                        raise BusinessError(422, "INVALID_ARGUMENT", "标识列表请使用JSON数组填写") from exc
                else:
                    raise BusinessError(422, "INVALID_ARGUMENT", "补问引用了当前操作不支持的字段")
    try:
        request_body = TypeAdapter(AgentJobCreate).validate_python(
            {
                "client_request_id": row.client_request_id,
                "operation": row.operation,
                "params": params,
            }
        )
    except ValidationError as exc:
        raise BusinessError(422, "INVALID_ARGUMENT", "补充后的请求字段不符合约定") from exc
    combined = {a["question_id"]: Answer.model_validate(a) for a in row.answers}
    combined.update(answers)
    request = build_context(db, row.id, lessons.to_dto(lesson), request_body, combined.values())
    row.params = params
    row.answers = [a.model_dump(mode="json") for a in combined.values()]
    row.input_snapshot = request.model_dump(mode="json")
    row.base_record_version = lesson.record_version
    row.status, row.result, row.error, row.questions = "queued", None, None, []
    row.last_resume_request_id = body.client_request_id
    row.last_resume_fingerprint = signature
    row.revision += 1
    row.updated_at = datetime.now(UTC)
    db.flush()
    return to_dto(row)


def retry(db: Session, id: str, body: JobRetry) -> AiJob:
    initial = get(db, id)
    lesson = lessons.get(db, initial.lesson_id, lock=True)
    row = db.scalar(
        select(JobRow).where(JobRow.id == id).with_for_update().execution_options(populate_existing=True)
    )
    if row.last_retry_revision == body.expected_revision:
        return to_dto(row)
    if row.status != "failed" or row.revision != body.expected_revision:
        raise BusinessError(409, "VERSION_CONFLICT", "任务状态已变化，请先重新查询")
    require_phase(lesson, row.operation)
    require_no_active(db, lesson.id, row.operation)
    request_body = TypeAdapter(AgentJobCreate).validate_python(
        {"client_request_id": row.client_request_id, "operation": row.operation, "params": row.params}
    )
    request = build_context(
        db, row.id, lessons.to_dto(lesson), request_body, map(Answer.model_validate, row.answers)
    )
    row.input_snapshot = request.model_dump(mode="json")
    row.base_plan_version, row.base_record_version = lesson.plan_version, lesson.record_version
    row.last_retry_revision = body.expected_revision
    row.revision += 1
    row.status, row.result, row.error, row.questions = "queued", None, None, []
    row.updated_at = datetime.now(UTC)
    db.flush()
    return to_dto(row)
