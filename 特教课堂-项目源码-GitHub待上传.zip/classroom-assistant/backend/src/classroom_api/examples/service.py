"""Install curated examples once, using the existing lesson/record/report services."""

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from classroom_contracts.http import LessonCreate
from classroom_contracts.models import LessonPlan
from classroom_contracts.planned import (
    ExecutionPatch,
    LessonAction,
    RecordCreate,
    ReportAction,
    TeacherReportCreate,
)
from classroom_contracts.teaching import LessonStatistics
from sqlalchemy.orm import Session

from classroom_api.lessons import execution
from classroom_api.lessons import service as lessons
from classroom_api.lessons.models import LessonRow
from classroom_api.records import service as records
from classroom_api.records.models import RecordRow
from classroom_api.reports import service as reports
from classroom_api.reports.models import ReportRow

CONTENT = Path(__file__).with_name("lessons.json")


def create_examples(db: Session, owner_id: str):
    for source in json.loads(CONTENT.read_text("utf-8")):
        if db.get(LessonRow, source["id"]) is not None:
            continue
        value = lessons.create(
            db,
            LessonCreate(
                title=source["title"],
                student_ids=source["student_ids"],
                planned_duration_min=source["duration_min"],
                available_materials=source["materials"],
                previous_report_ids=source["previous_report_ids"],
            ),
            owner_id,
        )
        row = db.get(LessonRow, value.id)
        row.id = source["id"]
        db.flush()
        lessons.save_plan(db, row, 0, LessonPlan.model_validate(source["plan"]))
        execution.act(db, row.id, LessonAction(action="confirm_plan", expected_plan_version=row.plan_version))
        if source["status"] == "completed":
            create_replay(db, row, source)


def create_replay(db: Session, lesson: LessonRow, source: dict):
    execution.act(db, lesson.id, LessonAction(action="start", expected_plan_version=lesson.plan_version))
    started_at = datetime.now(UTC) - timedelta(hours=1)
    for item in source["records"]:
        saved = records.create(
            db,
            lesson.id,
            RecordCreate(
                client_record_id=item["id"],
                task_plan_version=lesson.plan_version,
                observed_at=started_at + timedelta(minutes=item["minute"]),
                **{key: value for key, value in item.items() if key not in {"id", "minute"}},
            ),
        )
        db.get(RecordRow, saved.record.id).id = item["id"]
        db.flush()
    tasks = [t for a in lesson.plan["activities"] for t in a["tasks"]]
    for index, task in enumerate(tasks):
        next_task = tasks[index + 1] if index + 1 < len(tasks) else None
        changes = [{"task_id": task["id"], "status": "done"}]
        if next_task:
            changes.append({"task_id": next_task["id"], "status": "active"})
        execution.update(
            db,
            lesson.id,
            ExecutionPatch(
                expected_record_version=lesson.record_version,
                task_changes=changes,
                display_task_id=next_task["id"] if next_task else None,
                display_step_id=None,
            ),
        )
    execution.act(db, lesson.id, LessonAction(action="complete", expected_plan_version=lesson.plan_version))
    report = source["report"]
    result = reports.create(
        db,
        lesson.id,
        TeacherReportCreate(
            client_request_id=report["id"],
            expected_plan_version=lesson.plan_version,
            expected_record_version=lesson.record_version,
            content=report["content"],
        ),
        LessonStatistics(
            lesson_id=lesson.id,
            source_plan_version=lesson.plan_version,
            source_record_version=lesson.record_version,
            rows=report["statistics"],
        ),
    )
    db.get(ReportRow, result.id).id = report["id"]
    db.flush()
    reports.act(db, report["id"], ReportAction(action="confirm", expected_revision=result.revision))
