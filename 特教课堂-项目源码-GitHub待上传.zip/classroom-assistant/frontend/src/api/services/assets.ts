import { client, unwrap } from "../client";
import type { components } from "../generated/schema";
export type Asset = components["schemas"]["Asset"];
export const assetsApi = {
  list: async () => unwrap(await client.GET("/api/v1/assets")).items,
  upload: async (file: File, alt: string) => {
    const form = new FormData();
    form.append("file", file);
    form.append("alt", alt);
    return unwrap(
      await client.POST("/api/v1/assets", {
        body: { file: file.name, alt },
        bodySerializer: () => form,
      }),
    );
  },
};
