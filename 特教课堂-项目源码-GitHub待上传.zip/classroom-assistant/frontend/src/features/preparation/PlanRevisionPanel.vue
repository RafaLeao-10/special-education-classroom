<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import type { Lesson } from "../../api/services/lessons";
import { readDraft, writeDraft } from "../../app/drafts";
import BlocksRenderer from "../../components/BlocksRenderer.vue";
import JobStatus from "../ai/JobStatus.vue";
import { useAiJob } from "../ai/useAiJob";
import Button from "../../components/Button.vue";

const props = defineProps<{ lesson: Lesson; disabled: boolean }>();
const emit = defineEmits<{ adopted: [] }>();
const {
  job,
  error,
  running,
  available,
  serviceMessage,
  hasPending,
  start,
  restore,
  resume,
  retry,
  apply,
  poll,
} = useAiJob(props.lesson.id, "revise");
const draftKey = `revision-request:${props.lesson.id}`;
const request = ref(readDraft<string>(draftKey) || "");
watch(request, (value) => writeDraft(draftKey, value));
const saving = ref(false);
const saveError = ref("");
const proposal = computed(() =>
  job.value?.result?.kind === "plan_revision" ? job.value.result.data : null,
);
const stale = computed(
  () =>
    !!job.value &&
    (job.value.base_plan_version !== props.lesson.plan_version ||
      job.value.base_record_version !== props.lesson.record_version),
);
const tasks = computed(
  () => props.lesson.plan?.activities.flatMap((a) => a.tasks) || [],
);
const resourceTypes: Record<string, string> = {
  execution_sheet: "教学执行单",
  activity_steps: "活动步骤资料",
  worksheet: "配套练习",
  record_sheet: "空白观察记录表",
};
async function adopt() {
  saving.value = true;
  saveError.value = "";
  try {
    if (await apply()) emit("adopted");
  } catch (e) {
    saveError.value = (e as Error).message;
  } finally {
    saving.value = false;
  }
}
onMounted(restore);
</script>

<template>
  <section class="agent-panel">
    <p class="eyebrow">教案同步修订</p>
    <h2>同步受影响的教学内容</h2>
    <p class="subtle">
      人工修改后，先保存教案草稿，再由教学实施 Agent
      更新相关任务、指令、支持与反馈、教学资料。教师明确写好的指令会保留。
    </p>
    <el-input
      v-model="request"
      type="textarea"
      :rows="2"
      placeholder="可补充这次修改的意图，例如：保留我写好的短句，按新的手势回应方式调整示范与练习。"
    />
    <Button
      variant="secondary"
      :loading="running"
      :disabled="disabled || !available || lesson.status !== 'draft'"
      @click="start({ teacher_request: request })"
      >按最新教案生成局部更新</Button
    >
    <p class="subtle">
      {{ disabled ? "请先保存教案及备课条件，再同步。" : serviceMessage }}
    </p>
    <JobStatus
      :job="job"
      :running="running"
      :error="error"
      :pending="hasPending"
      hide-classroom-link
      @retry="retry"
      @resume="resume"
      @poll="poll"
    />
    <div v-if="proposal && !job?.applied_resource" class="agent-preview">
      <p v-if="stale" class="preview-notice">
        教案已变化，请保存最新修改后重新生成。
      </p>
      <h3>{{ proposal.summary }}</h3>
      <p class="subtle">采用后将更新教案。</p>
      <article
        v-for="update in proposal.task_updates"
        :key="update.task_id"
        class="agent-task-preview"
      >
        <h4>{{ update.replacement.title }}</h4>
        <p>目标：{{ update.replacement.objective }}</p>
        <p>
          材料：{{
            update.replacement.material_ids
              .map(
                (id) =>
                  lesson.available_materials.find((m) => m.id === id)?.name ||
                  id,
              )
              .join("、")
          }}
        </p>
        <p>教师准备：{{ update.replacement.teacher_preparation }}</p>
        <p>反馈方式：{{ update.replacement.feedback_guidance }}</p>
        <p>
          记录：{{
            update.replacement.recording_unit === "step" ? "按步骤" : "按任务"
          }}；计划机会数：{{
            update.replacement.planned_opportunities ?? "未设定"
          }}（计划安排）
        </p>
        <div
          v-for="target in update.replacement.student_targets"
          :key="target.student_id"
        >
          <strong>{{
            lesson.student_snapshots?.find((s) => s.id === target.student_id)
              ?.name || "参与学生"
          }}</strong>
          <p>达成标准：{{ target.completion_criterion }}</p>
          <p v-if="target.routine_support_ids.length">
            常规支持：{{
              target.routine_support_ids
                .map(
                  (id) =>
                    lesson.plan?.supports.find((s) => s.id === id)
                      ?.description || id,
                )
                .join("、")
            }}
          </p>
          <p v-if="target.adaptation_note">
            个别支持：{{ target.adaptation_note }}
          </p>
        </div>
        <ol>
          <li v-for="step in update.replacement.steps" :key="step.id">
            <strong>{{ step.instruction }}</strong>
            <p>
              预期反应：{{ step.expected_response }}；完成标准：{{
                step.completion_criterion
              }}
            </p>
            <p>观察重点：{{ step.observation_focus }}</p>
            <p v-if="step.demonstration">
              示范与提示：{{ step.demonstration }}
            </p>
          </li>
        </ol>
        <details>
          <summary>对照已保存的原步骤</summary>
          <ol>
            <li
              v-for="step in tasks.find((t) => t.id === update.task_id)
                ?.steps || []"
              :key="step.id"
            >
              {{ step.instruction }}
            </li>
          </ol>
        </details>
      </article>
      <article
        v-for="resource in proposal.resource_updates"
        :key="resource.id"
        class="agent-task-preview"
      >
        <p class="eyebrow">{{ resourceTypes[resource.type] }}</p>
        <h4>{{ resource.title }}</h4>
        <BlocksRenderer :blocks="resource.blocks" />
      </article>
      <p v-if="proposal.removed_resource_ids.length">
        将移除过期资料：{{
          proposal.removed_resource_ids
            .map(
              (id) =>
                lesson.plan?.resources.find((r) => r.id === id)?.title ||
                "旧资料",
            )
            .join("、")
        }}
      </p>
      <Button
        variant="secondary"
        :loading="saving"
        :disabled="disabled || running || stale || lesson.status !== 'draft'"
        @click="adopt"
        >采用并保存更新</Button
      >
    </div>
    <p v-if="job?.applied_resource" class="subtle">
      这轮更新已采用保存，可以查看最新教案并进入课堂。
    </p>
    <p v-if="saveError" class="inline-error" role="alert">{{ saveError }}</p>
  </section>
</template>
