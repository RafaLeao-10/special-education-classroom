"""Refresh teaching content locally around a teacher's saved edits."""

from classroom_api.errors import BusinessError
from classroom_contracts.agent import PlanRevision, RevisionScope
from classroom_contracts.models import LessonPlan, Student

from . import service


def task_map(plan):
    return {t.id: t for a in plan.activities for t in a.tasks} if plan else {}


def scope_for(lesson, students, baseline, previous_input, protected=()):
    current = lesson.plan
    tasks, old_tasks = task_map(current), task_map(baseline.plan if baseline else None)
    previous_lesson = previous_input.get("lesson", {})
    old_materials = {m["id"]: m for m in previous_lesson.get("available_materials", [])}
    materials = {m.id: m.model_dump(mode="json") for m in lesson.available_materials}
    material_changes = {
        id for id in materials.keys() | old_materials.keys() if materials.get(id) != old_materials.get(id)
    }
    old_students = {s["id"]: Student.model_validate(s) for s in previous_input.get("students", [])}
    student_changes = {s.id for s in students if s != old_students.get(s.id)}
    old_activities = {a.id: a for a in baseline.plan.activities} if baseline else {}
    old_positions = (
        {t.id: (a.id, i) for a in baseline.plan.activities for i, t in enumerate(a.tasks)} if baseline else {}
    )
    changed = set()
    for activity in current.activities:
        old = old_activities.get(activity.id)
        activity_changed = old is None or activity.model_dump(exclude={"tasks"}) != old.model_dump(
            exclude={"tasks"}
        )
        for position, task in enumerate(activity.tasks):
            if (
                task != old_tasks.get(task.id)
                or activity_changed
                or old_positions.get(task.id) != (activity.id, position)
                or set(task.material_ids) & material_changes
                or set(task.participant_ids) & student_changes
                or lesson.planned_duration_min != previous_lesson.get("planned_duration_min")
            ):
                changed.add(task.id)
    for task in tasks.values():
        if baseline:
            support_ids = {id for t in task.student_targets for id in t.routine_support_ids}
            current_supports = {s.id: s for s in current.supports if s.id in support_ids}
            old_supports = {s.id: s for s in baseline.plan.supports if s.id in support_ids}
            if current_supports != old_supports:
                changed.add(task.id)
    removed = old_tasks.keys() - tasks.keys()
    affected_resources = set()
    old_resources = {r.id: r for r in baseline.plan.resources} if baseline else {}
    for resource in current.resources:
        old = old_resources.get(resource.id)
        related = set(resource.task_ids) | (set(old.task_ids) if old else set())
        if resource != old:
            changed.update(resource.task_ids)
        if resource != old or related & (changed | removed):
            affected_resources.add(resource.id)
    # A shared sheet must be refreshed even when its affected task was found later above.
    for resource in current.resources:
        if set(resource.task_ids) & changed:
            affected_resources.add(resource.id)
    old_steps = {s.id: s for task in old_tasks.values() for s in task.steps}
    locked = {
        s.id
        for task in tasks.values()
        for s in task.steps
        if s.instruction.strip()
        and (s.id in protected or s.id not in old_steps or s.instruction != old_steps[s.id].instruction)
    }
    return RevisionScope(
        baseline_plan_version=baseline.plan_version if baseline else None,
        affected_task_ids=[id for id in tasks if id in changed],
        removed_task_ids=sorted(removed),
        affected_resource_ids=[r.id for r in current.resources if r.id in affected_resources],
        protected_step_ids=sorted(locked),
    )


def apply(db, lesson, scope: RevisionScope, proposal: PlanRevision):
    if lesson.status != "draft" or lesson.plan is None:
        raise BusinessError(409, "INVALID_STATE", "请在开课前保存教案，再同步教学内容")
    plan = LessonPlan.model_validate(lesson.plan)
    original = task_map(plan)
    updates = {u.task_id: u.replacement for u in proposal.task_updates}
    if len(updates) != len(proposal.task_updates) or updates.keys() != set(scope.affected_task_ids):
        raise BusinessError(422, "INVALID_ARGUMENT", "同步结果须完整覆盖受影响任务，不能修改范围外任务")
    fixed = (
        "id",
        "participant_ids",
        "practice_format",
        "material_ids",
        "recording_unit",
        "planned_opportunities",
    )
    target_fields = {"student_id", "goal_ids", "accepted_response_modes", "routine_support_ids"}
    for id, new in updates.items():
        old = original[id]
        if any(getattr(old, k) != getattr(new, k) for k in fixed):
            raise BusinessError(422, "INVALID_ARGUMENT", "同步须沿用教师最新选定的材料、教学方式和记录口径")
        if [t.model_dump(include=target_fields) for t in old.student_targets] != [
            t.model_dump(include=target_fields) for t in new.student_targets
        ]:
            raise BusinessError(422, "INVALID_ARGUMENT", "同步不能改变教师已选定的学生目标、回应和支持")
        steps = {s.id: s for s in new.steps}
        if any(
            s.id not in steps or steps[s.id].instruction != s.instruction
            for s in old.steps
            if s.id in scope.protected_step_ids
        ):
            raise BusinessError(422, "INVALID_ARGUMENT", "同步结果改动了教师明确写好的指令，请保留后重新生成")
    existing = {r.id: r for r in plan.resources}
    resource_updates = {r.id: r for r in proposal.resource_updates}
    removals = set(proposal.removed_resource_ids)
    affected_resources = set(scope.affected_resource_ids)
    if (
        len(resource_updates) != len(proposal.resource_updates)
        or resource_updates.keys() & removals
        or not removals <= affected_resources
        or not affected_resources <= resource_updates.keys() | removals
    ):
        raise BusinessError(422, "INVALID_ARGUMENT", "请更新或移除全部受影响的旧资料")
    for id, resource in resource_updates.items():
        if (id in existing and id not in affected_resources) or (
            id not in existing and not set(resource.task_ids) & set(scope.affected_task_ids)
        ):
            raise BusinessError(422, "INVALID_ARGUMENT", "教学资料更新超出了受影响范围")
    for activity in plan.activities:
        activity.tasks = [updates.get(t.id, t) for t in activity.tasks]
    plan.resources = [resource_updates.pop(r.id, r) for r in plan.resources if r.id not in removals]
    plan.resources.extend(resource_updates.values())
    for task_id in scope.affected_task_ids:
        types = {r.type for r in plan.resources if task_id in r.task_ids}
        if not {"execution_sheet", "activity_steps", "record_sheet"} <= types:
            raise BusinessError(422, "INVALID_ARGUMENT", "请补齐受影响任务的执行单、步骤资料和空白观察记录表")
    return service.save_plan(db, lesson, lesson.plan_version, plan, allow_draft=True)
