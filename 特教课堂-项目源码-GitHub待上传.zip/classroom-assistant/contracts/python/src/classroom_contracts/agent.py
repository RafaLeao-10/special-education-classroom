"""B-owned protocol for preparation, classroom adjustments and reports."""

from typing import Annotated, Literal

from pydantic import Field, model_validator

from .enums import AdjustmentAction
from .models import (
    DTO,
    Activity,
    AdjustmentLog,
    Counts,
    Error,
    Id,
    InputDTO,
    KnowledgeRef,
    Lesson,
    LessonPlan,
    PlanSnapshot,
    Positive,
    Record,
    Report,
    ReportDraft,
    Student,
    Task,
    TeachingResource,
)


class PrepareParams(InputDTO):
    teacher_request: str


class ReviseParams(InputDTO):
    teacher_request: str


class ReportParams(InputDTO):
    teacher_request: str


class AdjustParams(InputDTO):
    action: AdjustmentAction
    instruction_mode: Literal["simplify", "split"] = "simplify"
    target_task_ids: list[Id]
    step_ids: list[Id] = Field(default_factory=list)
    replacement_material_id: Id | None
    teacher_request: str


class RequestTarget(DTO):
    kind: Literal["request"]
    field: str


class RecordCountsTarget(DTO):
    kind: Literal["record_counts"]
    record_id: Id
    record_revision: Positive


class QuestionOption(DTO):
    value: str
    label: str


class Question(DTO):
    id: str
    text: str
    answer_type: Literal["text", "single_choice", "counts"]
    options: list[QuestionOption]
    target: Annotated[RequestTarget | RecordCountsTarget, Field(discriminator="kind")]
    required: bool

    @model_validator(mode="after")
    def valid_answer_format(self):
        if self.answer_type == "counts":
            valid = self.target.kind == "record_counts" and not self.options
        elif self.answer_type == "single_choice":
            values = [option.value for option in self.options]
            valid = self.target.kind == "request" and bool(values) and len(values) == len(set(values))
        else:
            valid = self.target.kind == "request" and not self.options
        if not valid:
            raise ValueError("补问的回答方式、选项与目标不匹配")
        return self


class Answer(DTO):
    question_id: str
    value: str | Counts


class StepSplit(DTO):
    source_step_id: Id
    replacement_step_ids: Annotated[list[Id], Field(min_length=2)]


class TaskUpdate(DTO):
    task_id: Id
    replacement: Task
    step_splits: list[StepSplit] = Field(default_factory=list)


class FutureActivityReplacement(DTO):
    replace_activity_ids: list[Id]
    activities: list[Activity]


class AdjustmentProposal(DTO):
    action: AdjustmentAction
    summary: str
    reason: str
    task_updates: list[TaskUpdate]
    future_activity_replacement: FutureActivityReplacement | None
    resource_updates: list[TeachingResource]
    references: list[KnowledgeRef]


class RevisionScope(DTO):
    baseline_plan_version: int | None
    affected_task_ids: list[Id]
    removed_task_ids: list[Id]
    affected_resource_ids: list[Id]
    protected_step_ids: list[Id]


class PlanRevision(DTO):
    summary: str
    task_updates: list[TaskUpdate]
    resource_updates: list[TeachingResource]
    removed_resource_ids: list[Id]


class PlanRevisionResult(DTO):
    kind: Literal["plan_revision"]
    data: PlanRevision


class PlanResult(DTO):
    kind: Literal["plan"]
    data: LessonPlan


class AdjustmentResult(DTO):
    kind: Literal["adjustment"]
    data: AdjustmentProposal


class ReportResult(DTO):
    kind: Literal["report"]
    data: ReportDraft


AgentResult = Annotated[
    PlanResult | AdjustmentResult | ReportResult | PlanRevisionResult, Field(discriminator="kind")
]


class AgentContext(InputDTO):
    contract_version: Literal["1.0"]
    request_id: Id
    lesson: Lesson
    students: list[Student]
    records: list[Record]
    plan_snapshots: list[PlanSnapshot]
    adjustments: list[AdjustmentLog]
    previous_reports: list[Report]
    answers: list[Answer]


class PrepareRequest(AgentContext):
    operation: Literal["prepare"]
    params: PrepareParams


class AdjustRequest(AgentContext):
    operation: Literal["adjust"]
    params: AdjustParams


class ReviseRequest(AgentContext):
    operation: Literal["revise"]
    params: ReviseParams
    scope: RevisionScope


class ReportRequest(AgentContext):
    operation: Literal["report"]
    params: ReportParams


AgentRequest = Annotated[
    PrepareRequest | AdjustRequest | ReportRequest | ReviseRequest, Field(discriminator="operation")
]


class AgentResponse(DTO):
    contract_version: Literal["1.0"]
    request_id: Id
    status: Literal["succeeded", "needs_input", "failed"]
    questions: list[Question]
    result: AgentResult | None
    error: Error | None

    @model_validator(mode="after")
    def consistent_status(self):
        if len({q.id for q in self.questions}) != len(self.questions):
            raise ValueError("补问标识不可重复")
        valid = {
            "succeeded": self.result is not None and self.error is None and not self.questions,
            "failed": self.result is None and self.error is not None and not self.questions,
            "needs_input": self.result is None and self.error is None and bool(self.questions),
        }
        if not valid[self.status]:
            raise ValueError("status与result/questions/error不匹配")
        return self
