<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import {
classroomApi,
type ClassroomRecord,
} from "../../api/services/classroom";
import { readDraft } from "../../app/drafts";

const id = String(useRoute().params.id);
const lesson = ref<Lesson | null>(null);
const records = ref<ClassroomRecord[]>([]);
const loading = ref(true);
const error = ref("");
const recordsError = ref("");

// 课堂用时：复用 P2-3 计时条写的草稿（scope 与 useLessonTimer 完全一致）
type TimerDraft = { startedAt: number; finishedAt?: number };
const timerDraft = readDraft<TimerDraft>(`timer:${id}`);
const usedMin = computed(() => {
if (!timerDraft) return null;
const end = timerDraft.finishedAt ?? Date.now();
return Math.max(0, Math.floor((end - timerDraft.startedAt) / 60000));
});

// task_id → 状态的查询表，方便下面归类时 O(1) 查找
const stateOf = computed(() => {
const map = new Map<string, "pending" | "active" | "done" | "skipped">();
for (const s of lesson.value?.execution.task_states ?? []) {
    map.set(s.task_id, s.status);
}
return map;
});

type TaskRow = { title: string; objective: string; activity: string };
type GroupKey = "done" | "skipped" | "pending";
const groups = computed(() => {
const out: Record<GroupKey, TaskRow[]> = {
    done: [],
    skipped: [],
    pending: [],
};
for (const activity of lesson.value?.plan?.activities ?? []) {
    for (const task of activity.tasks) {
    const status = stateOf.value.get(task.id) ?? "pending";
    // 结课后不应再有 active；万一有，防御性归到"未开始"
    const key: GroupKey = status === "active" ? "pending" : status;
    out[key].push({
        title: task.title,
        objective: task.objective,
        activity: activity.title,
    });
    }
}
return out;
});

const noteCount = computed(
() => records.value.filter((r) => r.kind === "note").length,
);
const observationCount = computed(
() => records.value.filter((r) => r.kind === "observation").length,
);

async function load() {
loading.value = true;
error.value = "";
recordsError.value = "";
// 两个请求并行发出；allSettled 让"记录读取失败"不连累"课堂信息"
const [lessonResult, recordsResult] = await Promise.allSettled([
    lessonsApi.get(id),
    classroomApi.records(id),
]);
if (lessonResult.status === "fulfilled") {
    lesson.value = lessonResult.value;
} else {
    error.value = (lessonResult.reason as Error).message;
}
if (recordsResult.status === "fulfilled") {
    records.value = recordsResult.value;
} else {
    recordsError.value = (recordsResult.reason as Error).message;
}
loading.value = false;
}
onMounted(load);
</script>

<template>
<div class="page-title">
    <div>
    <router-link :to="`/lessons/${id}/classroom`" class="back-link"
        >← 返回课堂</router-link
    >
    <span class="stage-tag stage-sand">课后 · 小结</span>
    <h1>{{ lesson?.title || "课堂小结" }}</h1>
    <p class="page-description">先看一眼这堂课的清单，再整理报告。</p>
    </div>
</div>

<p v-if="error" role="alert" class="inline-error">{{ error }}</p>
<p v-if="loading" class="subtle">正在整理课堂小结…</p>

<template v-else-if="lesson">
    <!-- 未结课直入 URL：提示并引导回课堂 -->
    <section v-if="lesson.status !== 'completed'" class="review-notice">
    <AppIcon name="clock" :size="26" />
    <div>
        <h2>这堂课还没有结束</h2>
        <p>小结只在结课后生成。请先回到课堂，点「结束课堂并回顾」。</p>
    </div>
    <Button :to="`/lessons/${id}/classroom`" variant="primary">回到课堂</Button>
    </section>

    <template v-else>
    <div class="review-stats">
        <div>
        <span>已完成任务</span><strong>{{ groups.done.length }}</strong>
        </div>
        <div>
        <span>已跳过</span><strong>{{ groups.skipped.length }}</strong>
        </div>
        <div>
        <span>未开始</span><strong>{{ groups.pending.length }}</strong>
        </div>
        <div>
        <span>速记</span><strong>{{ noteCount }}</strong>
        </div>
        <div>
        <span>观察记录</span><strong>{{ observationCount }}</strong>
        </div>
        <div>
        <span>课堂用时</span
        ><strong v-if="usedMin !== null"
            >{{ usedMin }}<small> 分钟</small></strong
        ><strong v-else>—</strong>
        </div>
    </div>

    <p v-if="recordsError" role="alert" class="inline-error">
        行为记录读取失败：{{ recordsError }}
    </p>

    <div class="review-lists">
        <section class="review-panel">
        <p class="eyebrow">已完成</p>
        <h2>完成的任务</h2>
        <article
            v-for="row in groups.done"
            :key="row.title"
            class="review-task"
        >
            <h3>{{ row.title }}</h3>
            <p>{{ row.objective }}</p>
            <span class="subtle">{{ row.activity }}</span>
        </article>
        <p v-if="!groups.done.length" class="subtle">没有已完成的任务。</p>
        </section>
        <section class="review-panel">
        <p class="eyebrow">已跳过</p>
        <h2>跳过的任务</h2>
        <article
            v-for="row in groups.skipped"
            :key="row.title"
            class="review-task"
        >
            <h3>{{ row.title }}</h3>
            <p>{{ row.objective }}</p>
            <span class="subtle">{{ row.activity }}</span>
        </article>
        <p v-if="!groups.skipped.length" class="subtle">没有跳过的任务。</p>
        </section>
        <section class="review-panel">
        <p class="eyebrow">未开始</p>
        <h2>未进行的任务</h2>
        <article
            v-for="row in groups.pending"
            :key="row.title"
            class="review-task"
        >
            <h3>{{ row.title }}</h3>
            <p>{{ row.objective }}</p>
            <span class="subtle">{{ row.activity }}</span>
        </article>
        <p v-if="!groups.pending.length" class="subtle">全部任务都处理过了。</p>
        </section>
    </div>

    <div class="review-footer">
        <p class="subtle">小结只在此展示；进入报告后以最新数据为准。</p>
        <Button :to="`/lessons/${id}/report`" variant="primary" class="btn-arrow"   
        >进入报告 <AppIcon name="arrow" :size="18"/></Button
        >
    </div>
    </template>
</template>
</template>