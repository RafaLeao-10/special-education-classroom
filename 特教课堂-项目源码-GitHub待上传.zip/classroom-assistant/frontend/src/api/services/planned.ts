/** Voice transcription remains reserved. Agent jobs now use the implemented jobs service. */
import type { components, paths } from "../generated/planned";
type Schema = components["schemas"];
export interface TranscriptionPort {
  transcribe(audio: Blob, language?: string): Promise<Schema["Transcription"]>;
}
export const plannedEndpoints = {
  transcription: { method: "POST", path: "/api/v1/transcriptions" },
} satisfies Record<string, { method: "POST"; path: keyof paths }>;
