<script setup lang="ts">
import { computed } from "vue";
import type { LessonPlan } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import AssetPicker from "../assets/AssetPicker.vue";
import BlocksEditor from "./BlocksEditor.vue";
import { removeSupport } from "./planDraft";
import Button from "../../components/Button.vue";
const plan = defineModel<LessonPlan>({ required: true });
defineProps<{ students: Student[] }>();
const emit = defineEmits<{ groupChanged: [id: string] }>();
const newId = () => crypto.randomUUID();
const tasks = computed(() => plan.value.activities.flatMap((a) => a.tasks));
const supportTypes = [
  ["visual_steps", "视觉步骤"],
  ["visual_schedule", "视觉日程"],
  ["position_marker", "位置标记"],
  ["communication_board", "沟通板"],
  ["other", "其他"],
] as const;
const resourceTypes = [
  ["execution_sheet", "执行单"],
  ["worksheet", "练习单"],
  ["activity_steps", "步骤单"],
  ["record_sheet", "记录表"],
] as const;
function removeGroup(id: string) {
  plan.value.groups = plan.value.groups.filter((g) => g.id !== id);
  for (const a of plan.value.activities)
    if (a.group_id === id) a.group_id = null;
}
function removeReference(id: string) {
  plan.value.references = plan.value.references.filter(
    (r) => r.knowledge_id !== id,
  );
  for (const t of tasks.value)
    t.knowledge_refs = t.knowledge_refs.filter((k) => k !== id);
}
</script>
<template>
  <details class="editor-details">
    <summary>学生分组与常规支持</summary>
    <h3>本课小组</h3>
    <div v-for="g in plan.groups" :key="g.id" class="editor-target">
      <el-input
        v-model="g.label"
        placeholder="小组名称"
        aria-label="小组名称"
      /><el-select
        v-model="g.student_ids"
        multiple
        aria-label="小组成员"
        @change="emit('groupChanged', g.id)"
        ><el-option
          v-for="s in students"
          :key="s.id"
          :value="s.id"
          :label="s.name" /></el-select
      ><Button size="sm" variant="quiet" @click="removeGroup(g.id)">移除小组</Button>
    </div>
    <Button
      size="sm"
      variant="secondary"
      @click="
        plan.groups.push({
          id: newId(),
          label: '新小组',
          student_ids: students.map((s) => s.id),
        })
      "
      >添加小组</Button
    >
    <h3>常规支持</h3>
    <div v-for="s in plan.supports" :key="s.id" class="editor-target">
      <el-select v-model="s.type" aria-label="支持类型"
        ><el-option
          v-for="[value, label] in supportTypes"
          :key="value"
          :value="value"
          :label="label" /></el-select
      ><el-input
        v-model="s.description"
        placeholder="支持说明"
        aria-label="支持说明"
      /><AssetPicker v-model="s.asset_id" /><Button
        size="sm"
        variant="quiet"
        @click="removeSupport(plan, s.id)"
        >移除支持</Button
      >
    </div>
    <Button
      size="sm"
      variant="secondary"
      @click="
        plan.supports.push({
          id: newId(),
          type: 'visual_steps',
          description: '',
          asset_id: null,
        })
      "
      >添加常规支持</Button
    >
  </details>
  <details class="editor-details">
    <summary>教学资料与参考来源</summary>
    <div
      v-for="(resource, i) in plan.resources"
      :key="resource.id"
      class="editor-target"
    >
      <label
        >资料名称<el-input
          v-model="resource.title"
          aria-label="资料名称" /></label
      ><el-select v-model="resource.type" aria-label="资料类型"
        ><el-option
          v-for="[value, label] in resourceTypes"
          :key="value"
          :value="value"
          :label="label" /></el-select
      ><el-select
        v-model="resource.task_ids"
        multiple
        placeholder="关联任务"
        aria-label="资料关联任务"
        ><el-option
          v-for="t in tasks"
          :key="t.id"
          :value="t.id"
          :label="t.title" /></el-select
      ><BlocksEditor
        v-model="resource.blocks"
        label="编辑资料内容（文字、图片、表格）"
      /><Button
        size="sm"
        variant="quiet"
        @click="plan.resources.splice(i, 1)"
        >移除资料</Button
      >
    </div>
    <Button
      size="sm"
      variant="secondary"
      @click="
        plan.resources.push({
          id: newId(),
          title: '新资料',
          type: 'worksheet',
          task_ids: [],
          blocks: [],
        })
      "
      >添加教学资料</Button
    >
    <h3>参考来源</h3>
    <div
      v-for="ref in plan.references"
      :key="ref.knowledge_id"
      class="editor-target"
    >
      <el-input
        v-model="ref.title"
        placeholder="引用名称"
        aria-label="引用名称"
      /><el-input v-model="ref.source_title" placeholder="来源标题" /><el-input
        v-model="ref.source_locator"
        placeholder="章节、页码或项目说明位置"
      /><el-input
        :model-value="ref.source_url || ''"
        @update:model-value="ref.source_url = $event || null"
        placeholder="来源网址（可空）"
      /><el-select v-model="ref.source_kind"
        ><el-option value="research" label="研究文献" /><el-option
          value="guide"
          label="指南" /><el-option
          value="teacher_experience"
          label="教师经验" /><el-option
          value="project_example"
          label="项目样例" /></el-select
      ><Button
        size="sm"
        variant="quiet"
        @click="removeReference(ref.knowledge_id)"
        >移除来源</Button
      >
    </div>
    <Button
      size="sm"
      variant="secondary"
      @click="
        plan.references.push({
          knowledge_id: newId(),
          title: '',
          source_title: '',
          source_url: null,
          source_locator: '',
          source_kind: 'teacher_experience',
          review_status: 'draft',
        })
      "
      >添加参考来源</Button
    >
  </details>
</template>
