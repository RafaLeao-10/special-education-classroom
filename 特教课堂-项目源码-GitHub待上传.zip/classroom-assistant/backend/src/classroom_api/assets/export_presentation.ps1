param([string]$Source, [string]$Target)
$ErrorActionPreference = 'Stop'
$deck = $null
$office = $null
$previousSecurity = $null
try {
    $office = New-Object -ComObject PowerPoint.Application
    $previousSecurity = $office.AutomationSecurity
    $office.AutomationSecurity = 3
    $deck = $office.Presentations.Open($Source, $true, $false, $false)
    $deck.SaveAs($Target, 32)
    $slidesPath = Join-Path ([System.IO.Path]::GetDirectoryName($Target)) ([System.IO.Path]::GetFileNameWithoutExtension($Target) + '-slides')
    $deck.Export($slidesPath, 'PNG', 1280, 720)
} finally {
    if ($null -ne $deck) { $deck.Close() }
    if ($null -ne $office) {
        if ($null -ne $previousSecurity) { $office.AutomationSecurity = $previousSecurity }
        if ($office.Presentations.Count -eq 0) { $office.Quit() }
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($office)
    }
}
