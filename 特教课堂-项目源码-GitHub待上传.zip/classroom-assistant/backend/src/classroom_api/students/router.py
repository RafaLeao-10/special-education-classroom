from classroom_api.auth.access import require_student
from classroom_api.auth.service import require_user
from classroom_api.db import get_db
from classroom_contracts.http import Envelope, Items, StudentCreate, StudentPatch
from classroom_contracts.models import Student
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import service
from .models import StudentRow

router = APIRouter(prefix="/students", tags=["students"], dependencies=[Depends(require_user)])


@router.get("", response_model=Envelope[Items[Student]])
def listing(db: Session = Depends(get_db), user=Depends(require_user)):
    return Envelope(
        data=Items(
            items=[
                service.to_dto(row)
                for row in db.scalars(
                    select(StudentRow)
                    .where(StudentRow.owner_id == user.id)
                    .order_by(StudentRow.name)
                    .limit(100)
                )
            ]
        )
    )


@router.post("", status_code=201, response_model=Envelope[Student])
def create(body: StudentCreate, db: Session = Depends(get_db), user=Depends(require_user)):
    return Envelope(data=service.create(db, body, user.id))


@router.patch("/{id}", response_model=Envelope[Student], dependencies=[Depends(require_student)])
def update(id: str, body: StudentPatch, db: Session = Depends(get_db)):
    return Envelope(data=service.update(db, id, body))
