"""Pure contracts. No database, settings, HTTP calls or service imports."""
