"""Copy teaching content and remap scoped IDs; never copy classroom facts."""

from uuid import uuid4

from classroom_api.errors import BusinessError
from classroom_api.students.service import get_many
from classroom_contracts.http import LessonCreate
from classroom_contracts.models import LessonPlan
from sqlalchemy import select

from . import service
from .models import LessonRow


def copy_lesson(db, source_id, body):
    source = service.get(db, source_id, lock=True)
    existing = db.scalar(
        select(LessonRow).where(
            LessonRow.copied_from_lesson_id == source_id, LessonRow.copy_request_id == body.client_request_id
        )
    )
    if existing:
        return service.to_dto(existing)
    if source.plan is None:
        raise BusinessError(409, "INVALID_STATE", "请先保存一份教案再复制")
    if source.plan_version != body.expected_plan_version:
        raise BusinessError(409, "VERSION_CONFLICT", "源教案已更新，请重新读取后复制")
    data = service.to_dto(source)
    plan = data.plan.model_copy(deep=True)
    materials = [m.model_dump() for m in data.available_materials]
    objects = materials + plan.groups + plan.supports + plan.activities + plan.resources
    objects += [t for a in plan.activities for t in a.tasks]
    objects += [s for a in plan.activities for t in a.tasks for s in t.steps]
    ids = {(item["id"] if isinstance(item, dict) else item.id): str(uuid4()) for item in objects}
    for item in objects:
        if isinstance(item, dict):
            item["id"] = ids[item["id"]]
        else:
            item.id = ids[item.id]
    people = {s.id: s for s in get_many(db, data.student_ids)}
    for activity in plan.activities:
        if activity.group_id:
            activity.group_id = ids[activity.group_id]
        for task in activity.tasks:
            task.material_ids = [ids[id] for id in task.material_ids]
            for target in task.student_targets:
                target.routine_support_ids = [ids[id] for id in target.routine_support_ids]
                current_goals = {g.id for g in people[target.student_id].goals}
                target.goal_ids = [id for id in target.goal_ids if id in current_goals]
    for resource in plan.resources:
        resource.task_ids = [ids[id] for id in resource.task_ids]
    plan.title = body.title
    lesson = service.create(
        db,
        LessonCreate(
            title=body.title,
            student_ids=data.student_ids,
            planned_duration_min=data.planned_duration_min,
            available_materials=materials,
            previous_report_ids=[],
        ),
        source.owner_id,
    )
    row = service.get(db, lesson.id, lock=True)
    row.copied_from_lesson_id = source_id
    row.copied_from_plan_version = data.plan_version
    row.copy_request_id = body.client_request_id
    return service.save_plan(db, row, 0, LessonPlan.model_validate(plan), allow_draft=True)
