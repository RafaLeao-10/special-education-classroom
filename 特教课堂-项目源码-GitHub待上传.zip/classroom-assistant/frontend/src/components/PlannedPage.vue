<script setup lang="ts">
import { useRoute } from "vue-router";
const route = useRoute();
</script>
<template>
  <section>
    <h1>{{ route.meta.title }}</h1>
    <el-empty description="待开发：本次交付仅实现基础备课链路。" />
    <p class="subtle">
      接手负责人：{{ route.meta.owner }}。接口及开发位置见
      contracts/api-roadmap.md 和对应 handoff 文档。
    </p>
  </section>
</template>
