<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { classroomApi, type RecordInput } from "../../api/services/classroom";
import type { Lesson } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import QuickCounts from "./QuickCounts.vue";
import ObservedAtField from "./ObservedAtField.vue";
import { isoFromLocal } from "./recordTime";
import CountsFields from "./CountsFields.vue";
import { emptyCounts, promptOptions } from "./counts";
import { ApiError } from "../../api/client";
import { clearDraft, readDraft, writeDraft } from "../../app/drafts";
import { pendingCounts } from "./pendingCounts";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

const props = defineProps<{
  lesson: Lesson;
  students: Student[];
  taskId?: string;
  stepId?: string;
}>();
const emit = defineEmits<{
  saved: [version: number];
  dirty: [value: boolean];
}>();
const scope = `observation:${props.lesson.id}`;
type ObservationDraft = {
  plan: Lesson["plan"];
  version: number;
  taskId: string;
  stepId: string;
  subject: string;
  counts: ReturnType<typeof emptyCounts>;
  note: string;
  observedAt: string;
  prompts: RecordInput["prompt_types"];
  supports: string[];
  pending: RecordInput | null;
};
const restored = readDraft<ObservationDraft>(scope);
const frozenPlan = ref<Lesson["plan"]>(restored?.plan || null);
const frozenVersion = ref(restored?.version ?? props.lesson.plan_version);
const plan = computed(() => frozenPlan.value || props.lesson.plan);
const tasks = computed(
  () =>
    plan.value?.activities.flatMap((activity) =>
      activity.tasks.map((task) => ({ activity, task })),
    ) || [],
);
const taskId = ref(
  restored?.taskId || props.taskId || tasks.value[0]?.task.id || "",
);
const selected = computed(() =>
  tasks.value.find((t) => t.task.id === taskId.value),
);
const stepId = ref(
  restored?.stepId ?? props.stepId ?? "",
);
const subject = ref(restored?.subject || `class:${props.lesson.id}`);
const counts = pendingCounts;
pendingCounts.value = restored?.counts || emptyCounts();
const note = ref(restored?.note || "");
const observedAt = ref(restored?.observedAt || "");
const prompts = ref<RecordInput["prompt_types"]>(restored?.prompts || []);
const supports = ref<string[]>(restored?.supports || []);
const pending = ref<RecordInput | null>(restored?.pending || null);
const busy = ref(false);
const error = ref("");
const total = computed(() =>
  Object.values(counts.value).reduce((n, v) => n + (v || 0), 0),
);
const dirty = computed(
  () =>
    !!observedAt.value ||
    total.value > 0 ||
    !!note.value.trim() ||
    !!prompts.value.length ||
    !!supports.value.length,
);
watch(dirty, (v) => emit("dirty", v), { immediate: true });
watch(
  [
    counts,
    note,
    observedAt,
    prompts,
    supports,
    taskId,
    stepId,
    subject,
    pending,
  ],
  () => {
    if (dirty.value || pending.value) {
      if (!frozenPlan.value) {
        frozenPlan.value = JSON.parse(JSON.stringify(props.lesson.plan));
        frozenVersion.value = props.lesson.plan_version;
      }
      writeDraft(scope, {
        plan: frozenPlan.value,
        version: frozenVersion.value,
        taskId: taskId.value,
        stepId: stepId.value,
        subject: subject.value,
        counts: counts.value,
        note: note.value,
        observedAt: observedAt.value,
        prompts: prompts.value,
        supports: supports.value,
        pending: pending.value,
      });
    } else {
      frozenPlan.value = null;
      clearDraft(scope);
    }
  },
  { deep: true, flush: "sync" },
);
watch(
  () => props.taskId,
  (id) => {
    if (!dirty.value && id) taskId.value = id;
  },
);
watch(taskId, () => {
  stepId.value = props.lesson.execution.split_task_ids?.includes(taskId.value) ? selected.value?.task.steps[0]?.id || "" : "";
  subject.value = `class:${props.lesson.id}`;
});
watch(
  () => props.stepId,
  (id) => {
    if (!dirty.value) stepId.value = id || "";
  },
);
const subjects = computed(() => [
  { value: `class:${props.lesson.id}`, label: "整班观察（不拆分至个人）" },
  ...props.students
    .filter((s) => selected.value?.task.participant_ids.includes(s.id))
    .map((s) => ({ value: `student:${s.id}`, label: s.name })),
  ...(plan.value?.groups || [])
    .filter((g) => g.id === selected.value?.activity.group_id)
    .map((g) => ({ value: `group:${g.id}`, label: g.label })),
]);
function discard() {
  counts.value = emptyCounts();
  observedAt.value = "";
  note.value = "";
  prompts.value = [];
  supports.value = [];
  frozenPlan.value = null;
  taskId.value = props.taskId || tasks.value[0]?.task.id || "";
  stepId.value = props.stepId || "";
  clearDraft(scope);
}
async function save() {
  if (!selected.value || !total.value || busy.value) return;
  busy.value = true;
  error.value = "";
  const [type, id] = subject.value.split(":") as [
    RecordInput["subject"]["type"],
    string,
  ];
  const fields = {
    kind: "observation" as const,
    subject: { type, id },
    activity_id: selected.value.activity.id,
    task_id: taskId.value,
    step_id:
      stepId.value || null,
    task_plan_version: frozenVersion.value,
    counts: counts.value,
    routine_support_ids: supports.value,
    prompt_types: prompts.value,
    note: note.value.trim(),
    observed_at: observedAt.value ? isoFromLocal(observedAt.value) : null,
  };
  if (!pending.value)
    pending.value = {
      ...JSON.parse(JSON.stringify(fields)),
      client_record_id: crypto.randomUUID(),
      observed_at: fields.observed_at || new Date().toISOString(),
    };
  try {
    const result = await classroomApi.createRecord(
      props.lesson.id,
      pending.value!,
    );
    pending.value = null;
    discard();
    emit("saved", result.record_version);
  } catch (e) {
    error.value = (e as Error).message;
    if (
      e instanceof ApiError &&
      e.status >= 400 &&
      e.status < 500 &&
      ![408, 429].includes(e.status)
    )
      pending.value = null;
  } finally {
    busy.value = false;
  }
}
</script>
<template>
  <div class="observation-form">
    <label>观察任务</label
    ><el-select
      v-model="taskId"
      :disabled="busy || dirty || !!pending"
      aria-label="观察任务"
      ><el-option
        v-for="t in tasks"
        :key="t.task.id"
        :value="t.task.id"
        :label="`${t.activity.title} · ${t.task.title}`"
    /></el-select>
    <template v-if="selected"
      ><p class="subtle">
        本任务按{{
          stepId ? "步骤" : "任务"
        }}计数，方案 v{{
          frozenPlan ? frozenVersion : lesson.plan_version
        }}。只记录实际次数。
      </p>
      <template v-if="stepId || lesson.execution.split_task_ids?.includes(taskId)"
        ><label>观察步骤</label
        ><el-select
          v-model="stepId"
          :disabled="busy || dirty || !!pending"
          aria-label="观察步骤"
          ><el-option value="" label="整个任务" /><el-option
            v-for="s in selected.task.steps"
            :key="s.id"
            :value="s.id"
            :label="`${s.order}. ${s.instruction}`" /></el-select
      ></template>
      <label>观察对象</label
      ><el-select
        v-model="subject"
        :disabled="busy || dirty || !!pending"
        aria-label="观察对象"
        ><el-option
          v-for="s in subjects"
          :key="s.value"
          :value="s.value"
          :label="s.label"
      /></el-select>
      <fieldset
        :disabled="busy || !!pending"
        style="border: 0; padding: 0; margin: 0"
      >
        <QuickCounts v-model="counts" /><CountsFields
          v-model="counts"
        /><ObservedAtField v-model="observedAt" />
        <label>追加成人提示（可多选）</label
        ><el-select
          v-model="prompts"
          :disabled="busy || !!pending"
          multiple
          aria-label="追加成人提示"
          ><el-option
            v-for="[value, label] in promptOptions"
            :key="value"
            :value="value"
            :label="label"
        /></el-select>
        <template v-if="plan?.supports.length"
          ><label>本次常规支持</label
          ><el-select v-model="supports" :disabled="busy || !!pending" multiple
            ><el-option
              v-for="s in plan.supports"
              :key="s.id"
              :value="s.id"
              :label="s.description" /></el-select
        ></template>
        <label>观察备注</label
        ><el-input
          v-model="note"
          type="textarea"
          :rows="2"
          aria-label="观察备注"
          placeholder="补充具体情境（可留空）"
        />
        <p class="subtle">
          独立完成可使用既定常规支持；追加成人提示单独记录。未观察、未实施和未知不算已知结果。
        </p>
      </fieldset>
      <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
      <ButtonGroup>
        <Button
          variant="primary"
          :loading="busy"
          :disabled="total < 1"
          @click="save"
          >{{ pending ? "重试保存原观察" : "保存观察计数" }}</Button
        >
        <Button
          v-if="dirty && !pending"
          variant="quiet"
          :disabled="busy"
          @click="discard"
          >清空本条观察</Button
        >
      </ButtonGroup>
      <p v-if="dirty" class="draft-label">
        本机已保留草稿。请先保存或清空本条，再切换观察对象、任务或步骤。
      </p>
    </template>
    <p v-else>请先选择一个任务。</p>
  </div>
</template>
