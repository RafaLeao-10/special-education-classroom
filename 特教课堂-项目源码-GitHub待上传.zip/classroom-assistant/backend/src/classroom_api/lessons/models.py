from datetime import datetime

from classroom_api.db import Base
from sqlalchemy import DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column


class LessonRow(Base):
    __tablename__ = "lessons"
    __table_args__ = (
        UniqueConstraint("copied_from_lesson_id", "copy_request_id", name="uq_lesson_copy_request"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    student_ids: Mapped[list] = mapped_column(JSONB)
    planned_duration_min: Mapped[int] = mapped_column(Integer)
    available_materials: Mapped[list] = mapped_column(JSONB)
    previous_report_ids: Mapped[list] = mapped_column(JSONB)
    student_snapshots: Mapped[list] = mapped_column(JSONB, default=list)
    snapshot_origin: Mapped[str] = mapped_column(String(20), default="none")
    copied_from_lesson_id: Mapped[str | None] = mapped_column(ForeignKey("lessons.id"), nullable=True)
    copied_from_plan_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    copy_request_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    display_token: Mapped[str | None] = mapped_column(String(80), nullable=True, unique=True)
    status: Mapped[str] = mapped_column(String(30))
    plan: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    plan_version: Mapped[int] = mapped_column(Integer)
    record_version: Mapped[int] = mapped_column(Integer)
    execution: Mapped[dict] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class PlanSnapshotRow(Base):
    __tablename__ = "plan_snapshots"
    lesson_id: Mapped[str] = mapped_column(ForeignKey("lessons.id"), primary_key=True)
    plan_version: Mapped[int] = mapped_column(Integer, primary_key=True)
    plan: Mapped[dict] = mapped_column(JSONB)
    student_snapshots: Mapped[list] = mapped_column(JSONB, default=list)
    snapshot_origin: Mapped[str] = mapped_column(String(20), default="captured")


class AdjustmentRow(Base):
    __tablename__ = "adjustments"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    lesson_id: Mapped[str] = mapped_column(ForeignKey("lessons.id"), index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("ai_jobs.id"), unique=True)
    details: Mapped[dict] = mapped_column(JSONB)
    applied_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
