"""Check follow-up targets against the supplied snapshot, without database access."""

from classroom_contracts.agent import AgentRequest, AgentResponse


def validate_questions(request: AgentRequest, response: AgentResponse):
    records = {record.id: record for record in request.records if not record.is_void}
    count_targets = set()
    task_ids = (
        {t.id for a in request.lesson.plan.activities for t in a.tasks} if request.lesson.plan else set()
    )
    step_ids = (
        {s.id for a in request.lesson.plan.activities for t in a.tasks for s in t.steps}
        if request.lesson.plan
        else set()
    )
    material_ids = {m.id for m in request.lesson.available_materials}
    for question in response.questions:
        target = question.target
        if target.kind == "record_counts":
            record = records.get(target.record_id)
            if (
                request.operation != "report"
                or record is None
                or record.kind != "observation"
                or record.revision != target.record_revision
                or record.id in count_targets
            ):
                raise ValueError("计数补问未对应当前有效观察记录")
            count_targets.add(record.id)
            continue
        field = target.field.removeprefix("params.")
        if field == "teacher_request":
            continue
        options = {option.value for option in question.options}
        allowed = {"replacement_material_id": material_ids, "target_task_ids": task_ids, "step_ids": step_ids}
        if (
            request.operation != "adjust"
            or field not in allowed
            or question.answer_type != "single_choice"
            or not options <= allowed[field]
        ):
            raise ValueError("补问字段或选项不属于当前调整范围")
