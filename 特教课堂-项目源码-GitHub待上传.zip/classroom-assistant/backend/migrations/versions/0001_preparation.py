"""V1.1: only five tables required for the preparation chain."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "0001_preparation"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("username", sa.String(100), nullable=False, unique=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("password_hash", sa.String(250), nullable=False),
    )
    op.create_table(
        "sessions",
        sa.Column("token_hash", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "students",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("details", JSONB, nullable=False),
        sa.Column("revision", sa.Integer, nullable=False),
    )
    op.create_table(
        "lessons",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("student_ids", JSONB, nullable=False),
        sa.Column("planned_duration_min", sa.Integer, nullable=False),
        sa.Column("available_materials", JSONB, nullable=False),
        sa.Column("previous_report_ids", JSONB, nullable=False),
        sa.Column("status", sa.String(30), nullable=False),
        sa.Column("plan", JSONB, nullable=True),
        sa.Column("plan_version", sa.Integer, nullable=False),
        sa.Column("record_version", sa.Integer, nullable=False),
        sa.Column("execution", JSONB, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "ai_jobs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("lesson_id", sa.String(36), sa.ForeignKey("lessons.id"), nullable=False),
        sa.Column("client_request_id", sa.String(36), nullable=False),
        sa.Column("operation", sa.String(20), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("params", JSONB, nullable=False),
        sa.Column("input_snapshot", JSONB, nullable=False),
        sa.Column("base_plan_version", sa.Integer, nullable=False),
        sa.Column("base_record_version", sa.Integer, nullable=False),
        sa.Column("questions", JSONB, nullable=False),
        sa.Column("answers", JSONB, nullable=False),
        sa.Column("result", JSONB, nullable=True),
        sa.Column("error", JSONB, nullable=True),
        sa.Column("applied_resource", JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("lesson_id", "client_request_id", name="uq_job_client_request"),
    )
    op.create_index("ix_ai_jobs_lesson_id", "ai_jobs", ["lesson_id"])
    op.create_index("ix_job_queue", "ai_jobs", ["status", "created_at"])


def downgrade():
    for table in ("ai_jobs", "lessons", "students", "sessions", "users"):
        op.drop_table(table)
