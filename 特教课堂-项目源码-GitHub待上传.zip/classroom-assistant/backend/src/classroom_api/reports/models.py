from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from classroom_api.db import Base


class ReportRow(Base):
    __tablename__ = "reports"
    __table_args__ = (UniqueConstraint("lesson_id", "client_request_id", name="uq_report_client"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    lesson_id: Mapped[str] = mapped_column(ForeignKey("lessons.id"), index=True)
    client_request_id: Mapped[str] = mapped_column(String(36))
    revision: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20))
    authoring_mode: Mapped[str] = mapped_column(String(20))
    source_plan_version: Mapped[int] = mapped_column(Integer)
    source_record_version: Mapped[int] = mapped_column(Integer)
    content: Mapped[dict] = mapped_column(JSONB)
    statistics: Mapped[list] = mapped_column(JSONB)
    references: Mapped[list] = mapped_column(JSONB)
    generated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
