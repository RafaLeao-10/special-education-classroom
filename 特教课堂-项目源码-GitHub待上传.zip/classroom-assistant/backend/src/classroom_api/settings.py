from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")
    database_url: str = "postgresql+psycopg://classroom:classroom_local@127.0.0.1:5432/classroom"
    test_database_url: str = "postgresql+psycopg://classroom:classroom_local@127.0.0.1:5432/classroom_test"
    session_secret: str = ""
    demo_username: str = "teacher"
    demo_password: str = "classroom-demo"
    asset_dir: Path = ROOT / ".data" / "assets"
    agent_gateway_url: str = "http://127.0.0.1:8001"
    agent_connect_timeout_sec: float = 10
    agent_read_timeout_sec: float = 210
