<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import {
  classroomApi,
  type ClassroomRecord,
  type RecordInput,
} from "../../api/services/classroom";
import type { Lesson } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
import RecordEntry from "./RecordEntry.vue";
import ObservationForm from "./ObservationForm.vue";
import ObservedAtField from "./ObservedAtField.vue";
import { isoFromLocal } from "./recordTime";
import { ApiError } from "../../api/client";
import { clearDraft, readDraft, writeDraft } from "../../app/drafts";
const props = defineProps<{
  lesson: Lesson;
  students: Student[];
  activityId?: string;
  taskId?: string;
  stepId?: string;
  reportMode?: boolean;
}>();
const emit = defineEmits<{
  saved: [version: number];
  dirty: [value: boolean];
}>();
const observationDirty = ref(false);
const records = ref<ClassroomRecord[]>([]);
const scope = `note:${props.lesson.id}`;
type Context = Pick<
  RecordInput,
  "activity_id" | "task_id" | "step_id" | "task_plan_version"
>;
type NoteDraft = {
  text: string;
  observedAt: string;
  subject: string;
  context: Context | null;
  pending: RecordInput | null;
};
const restored = readDraft<NoteDraft>(scope);
const draft = ref(restored?.text || "");
const observedAt = ref(restored?.observedAt || "");
const context = ref<Context | null>(restored?.context || null);
const pending = ref<RecordInput | null>(restored?.pending || null);
const editingRecords = ref(new Set<string>());
function recordDirty(id: string, value: boolean) {
  if (value) editingRecords.value.add(id);
  else editingRecords.value.delete(id);
}
const subject = ref(restored?.subject || `class:${props.lesson.id}`);
const includeVoid = ref(false);
const mode = ref<"text" | "voice" | "observation">("text");
watch(
  () =>
    !!draft.value.trim() ||
    !!observedAt.value ||
    observationDirty.value ||
    editingRecords.value.size > 0,
  (value) => emit("dirty", value),
  { immediate: true },
);
const loading = ref(true);
const busy = ref(false);
const error = ref("");
watch(
  [draft, observedAt, subject, pending],
  () => {
    if (draft.value.trim() || observedAt.value || pending.value) {
      context.value ||= {
        activity_id: props.activityId || null,
        task_id: props.taskId || null,
        step_id: props.stepId || null,
        task_plan_version: props.taskId ? props.lesson.plan_version : null,
      };
      writeDraft(scope, {
        text: draft.value,
        observedAt: observedAt.value,
        subject: subject.value,
        context: context.value,
        pending: pending.value,
      });
    } else {
      context.value = null;
      clearDraft(scope);
    }
  },
  { deep: true, flush: "sync" },
);
const subjects = computed(() => [
  { value: `class:${props.lesson.id}`, label: "整堂课经过" },
  ...props.students
    .filter((s) => props.lesson.student_ids.includes(s.id))
    .map((s) => ({ value: `student:${s.id}`, label: s.name })),
  ...(props.lesson.plan?.groups || []).map((g) => ({
    value: `group:${g.id}`,
    label: g.label,
  })),
]);
const taskNames = computed(
  () =>
    new Map(
      props.lesson.plan?.activities.flatMap((a) =>
        a.tasks.map((t) => [t.id, t.title] as const),
      ),
    ),
);
async function load() {
  error.value = "";
  try {
    records.value = await classroomApi.records(
      props.lesson.id,
      includeVoid.value,
    );
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    loading.value = false;
  }
}
async function save() {
  if (!draft.value.trim() || busy.value) return;
  error.value = "";
  busy.value = true;
  const [type, id] = subject.value.split(":") as [
    RecordInput["subject"]["type"],
    string,
  ];
  const fields = {
    kind: "note" as const,
    subject: { type, id },
    ...context.value!,
    counts: null,
    routine_support_ids: [],
    prompt_types: [],
    note: draft.value.trim(),
    observed_at: observedAt.value ? isoFromLocal(observedAt.value) : null,
  };
  if (!pending.value)
    pending.value = {
      ...fields,
      client_record_id: crypto.randomUUID(),
      observed_at: fields.observed_at || new Date().toISOString(),
    };
  try {
    const result = await classroomApi.createRecord(
      props.lesson.id,
      pending.value,
    );
    draft.value = "";
    observedAt.value = "";
    pending.value = null;
    clearDraft(scope);
    emit("saved", result.record_version);
    await load();
  } catch (e) {
    error.value = (e as Error).message;
    if (
      e instanceof ApiError &&
      e.status >= 400 &&
      e.status < 500 &&
      ![408, 429].includes(e.status)
    )
      pending.value = null;
  } finally {
    busy.value = false;
  }
}
async function changed(version: number) {
  emit("saved", version);
  await load();
}
onMounted(load);
</script>
<template>
  <section class="notes-panel">
    <div class="section-heading compact">
      <div>
        <p class="eyebrow">{{ reportMode ? '课后 · 记录' : '观察与速记' }}</p>
        <h2>{{ reportMode ? '补充记录' : '教师速记' }}</h2>
      </div>
      <AppIcon name="edit" :size="20" />
    </div>
    <p class="subtle">保存实际发生的情况。文字不会自动变成学生完成次数。</p>
    <template v-if="['in_progress', 'completed'].includes(lesson.status)">
      <div class="segmented-control" aria-label="速记输入方式">
        <button :class="{ active: mode === 'text' }" @click="mode = 'text'">
          <AppIcon name="edit" :size="16" />文字速记
        </button>
        <button
          :class="{ active: mode === 'observation' }"
          @click="mode = 'observation'"
        >
          观察计数
        </button>
        <button :class="{ active: mode === 'voice' }" @click="mode = 'voice'">
          <AppIcon name="mic" :size="16" />语音输入
        </button>
      </div>
      <div v-show="mode === 'text'" class="note-composer">
        <label for="record-subject">记录对象</label>
        <el-select
          id="record-subject"
          v-model="subject"
          :disabled="busy || !!pending"
          aria-label="速记记录对象"
          ><el-option
            v-for="item in subjects"
            :key="item.value"
            :value="item.value"
            :label="item.label"
        /></el-select>
        <label for="quick-note">{{
          taskId ? "当前任务观察" : "课后补充观察"
        }}</label>
        <el-input
          id="quick-note"
          v-model="draft"
          :disabled="busy || !!pending"
          type="textarea"
          :rows="4"
          placeholder="例如：需要手势提示后，将绘本放回盒中。"
        />
        <p v-if="context?.task_id" class="subtle">
          关联任务：{{ taskNames.get(context.task_id) || "原课堂任务" }} · 方案
          v{{ context.task_plan_version }}。切换课堂任务不会改变这条速记的归属。
        </p>
        <fieldset
          :disabled="busy || !!pending"
          style="border: 0; padding: 0; margin: 0"
        >
          <ObservedAtField v-model="observedAt" />
        </fieldset>
        <Button
          variant="primary"
          :loading="busy"
          :disabled="!draft.trim()"
          @click="save"
          >{{ pending ? "重试保存原速记" : "保存速记" }}</Button
        >
        <p class="draft-label">
          {{
            draft.trim()
              ? "有尚未保存的文字，已在本机保留草稿"
              : "点击保存后写入数据库，刷新仍可查看"
          }}
        </p>
      </div>
      <ObservationForm
        v-show="mode === 'observation'"
        :lesson="lesson"
        :students="students"
        :task-id="taskId"
        :step-id="stepId"
        @saved="changed"
        @dirty="observationDirty = $event"
      />
      <div v-show="mode === 'voice'" class="voice-placeholder">
        <AppIcon name="mic" :size="25" /><strong>语音转写待接入</strong>
        <p>语音转写功能正在准备。</p>
      </div>
    </template>
    <div class="record-list-heading">
      <h3>
        已保存记录 <span>{{ records.length }}</span>
      </h3>
      <el-checkbox v-model="includeVoid" @change="load">含作废记录</el-checkbox>
      <Button size="sm" variant="ghost" @click="load">刷新记录</Button>
    </div>
    <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
    <p v-if="loading" class="subtle">正在读取记录…</p>
    <p v-else-if="!records.length" class="subtle">还没有已保存的记录。</p>
    <div class="note-feed">
      <RecordEntry
        v-for="record in [...records].reverse()"
        :key="record.id"
        :record="record"
        :label="
          subjects.find(
            (s) => s.value === `${record.subject.type}:${record.subject.id}`,
          )?.label || '本课记录'
        "
        :task-label="
          record.task_id
            ? `${taskNames.get(record.task_id) || '历史任务'} · 方案 v${record.task_plan_version}`
            : '课程速记'
        "
        @saved="changed"
        @dirty="recordDirty(record.id, $event)"
      />
    </div>
  </section>
</template>
