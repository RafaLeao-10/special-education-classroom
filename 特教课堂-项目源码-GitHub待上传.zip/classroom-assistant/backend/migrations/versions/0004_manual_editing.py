"""Independent copied lessons with retry identity and source version."""

import sqlalchemy as sa
from alembic import op

revision = "0004_manual_editing"
down_revision = "0003_nonagent_week"
branch_labels = depends_on = None


def upgrade():
    op.add_column(
        "lessons",
        sa.Column("copied_from_lesson_id", sa.String(36), sa.ForeignKey("lessons.id"), nullable=True),
    )
    op.add_column("lessons", sa.Column("copied_from_plan_version", sa.Integer(), nullable=True))
    op.add_column("lessons", sa.Column("copy_request_id", sa.String(36), nullable=True))
    op.create_unique_constraint(
        "uq_lesson_copy_request", "lessons", ["copied_from_lesson_id", "copy_request_id"]
    )


def downgrade():
    op.drop_constraint("uq_lesson_copy_request", "lessons", type_="unique")
    for column in ("copy_request_id", "copied_from_plan_version", "copied_from_lesson_id"):
        op.drop_column("lessons", column)
