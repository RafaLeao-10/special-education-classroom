"""Classroom plan history, records/corrections and teacher-written reports."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "0002_classroom"
down_revision = "0001_preparation"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "plan_snapshots",
        sa.Column("lesson_id", sa.String(36), sa.ForeignKey("lessons.id"), primary_key=True),
        sa.Column("plan_version", sa.Integer(), primary_key=True),
        sa.Column("plan", JSONB, nullable=False),
    )
    op.execute(
        "INSERT INTO plan_snapshots (lesson_id, plan_version, plan) "
        "SELECT id, plan_version, plan FROM lessons WHERE plan IS NOT NULL"
    )
    op.create_table(
        "classroom_records",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("lesson_id", sa.String(36), sa.ForeignKey("lessons.id"), nullable=False),
        sa.Column("client_record_id", sa.String(36), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False),
        sa.Column("is_void", sa.Boolean(), nullable=False),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("details", JSONB, nullable=False),
        sa.UniqueConstraint("lesson_id", "client_record_id", name="uq_record_client"),
    )
    op.create_index("ix_classroom_records_lesson_id", "classroom_records", ["lesson_id"])
    op.create_table(
        "record_corrections",
        sa.Column("record_id", sa.String(36), sa.ForeignKey("classroom_records.id"), primary_key=True),
        sa.Column("revision", sa.Integer(), primary_key=True),
        sa.Column("before", JSONB, nullable=False),
        sa.Column("after", JSONB, nullable=False),
        sa.Column("changed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("changed_by", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
    )
    op.create_table(
        "reports",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("lesson_id", sa.String(36), sa.ForeignKey("lessons.id"), nullable=False),
        sa.Column("client_request_id", sa.String(36), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("authoring_mode", sa.String(20), nullable=False),
        sa.Column("source_plan_version", sa.Integer(), nullable=False),
        sa.Column("source_record_version", sa.Integer(), nullable=False),
        sa.Column("content", JSONB, nullable=False),
        sa.Column("statistics", JSONB, nullable=False),
        sa.Column("references", JSONB, nullable=False),
        sa.Column("generated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("confirmed_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("lesson_id", "client_request_id", name="uq_report_client"),
    )
    op.create_index("ix_reports_lesson_id", "reports", ["lesson_id"])


def downgrade():
    for table in ("reports", "record_corrections", "classroom_records", "plan_snapshots"):
        op.drop_table(table)
