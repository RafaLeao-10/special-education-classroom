"""Deterministic teaching tools, separate from the Agent protocol."""

from .models import DTO, Id, InputDTO, NonNegative, Record, StatisticsRow


class StatisticsInput(InputDTO):
    records: list[Record]


class LessonStatistics(DTO):
    lesson_id: Id
    source_plan_version: NonNegative
    source_record_version: NonNegative
    rows: list[StatisticsRow]


class DisplayLink(DTO):
    url: str
