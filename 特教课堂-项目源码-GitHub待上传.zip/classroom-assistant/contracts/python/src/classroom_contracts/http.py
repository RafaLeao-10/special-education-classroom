"""A-owned HTTP DTOs: implemented preparation chain only."""

from typing import Annotated, Generic, Literal, TypeVar

from pydantic import AwareDatetime, Field, model_validator

from .agent import AdjustParams, AgentResult, Answer, PrepareParams, Question, ReportParams, ReviseParams
from .enums import CommunicationMode, JobStatus, LessonStatus, Operation
from .models import (
    DTO,
    Error,
    Id,
    InputDTO,
    LessonPlan,
    NonNegative,
    Positive,
)

T = TypeVar("T")


class Envelope(DTO, Generic[T]):
    data: T | None
    error: Error | None = None


class Items(DTO, Generic[T]):
    items: list[T]


class Empty(InputDTO):
    pass


class Ok(DTO):
    ok: bool


class User(DTO):
    id: Id
    name: str


class UserData(DTO):
    user: User


class LoginInput(InputDTO):
    username: str
    password: str


class GoalInput(InputDTO):
    id: Id | None = None
    description: Annotated[str, Field(min_length=1)]
    criterion: str | None = None


class StudentCreate(InputDTO):
    name: Annotated[str, Field(min_length=1)]
    communication_modes: list[CommunicationMode]
    goals: list[GoalInput]
    observed_abilities: list[str]
    usual_supports: list[str]
    interests: list[str]
    notes: str


class PatchInput(InputDTO):
    @model_validator(mode="after")
    def no_explicit_null(self):
        if any(getattr(self, name) is None for name in self.model_fields_set):
            raise ValueError("本接口可更新字段不接受null；省略表示保留")
        return self


class StudentPatch(PatchInput):
    expected_revision: Positive
    name: Annotated[str, Field(min_length=1)] | None = None
    communication_modes: list[CommunicationMode] | None = None
    goals: list[GoalInput] | None = None
    observed_abilities: list[str] | None = None
    usual_supports: list[str] | None = None
    interests: list[str] | None = None
    notes: str | None = None


class MaterialInput(InputDTO):
    id: Id | None = None
    name: Annotated[str, Field(min_length=1)]
    quantity: NonNegative | None = None
    asset_id: Id | None = None


class LessonCreate(InputDTO):
    title: Annotated[str, Field(min_length=1)]
    student_ids: Annotated[list[Id], Field(min_length=1)]
    planned_duration_min: Positive
    available_materials: list[MaterialInput]
    previous_report_ids: list[Id]


class LessonPatch(PatchInput):
    expected_plan_version: NonNegative
    title: Annotated[str, Field(min_length=1)] | None = None
    student_ids: Annotated[list[Id], Field(min_length=1)] | None = None
    planned_duration_min: Positive | None = None
    available_materials: list[MaterialInput] | None = None
    previous_report_ids: list[Id] | None = None
    plan: LessonPlan | None = None


class PlanInput(InputDTO):
    expected_plan_version: NonNegative
    plan: LessonPlan


class LessonCopy(InputDTO):
    client_request_id: Id
    expected_plan_version: NonNegative
    title: Annotated[str, Field(min_length=1, max_length=200)]


class LessonSummary(DTO):
    id: Id
    title: str
    status: LessonStatus
    updated_at: AwareDatetime


class JobCreate(InputDTO):
    client_request_id: Id
    operation: Literal["prepare"]
    params: PrepareParams


class AdjustJobCreate(InputDTO):
    client_request_id: Id
    operation: Literal["adjust"]
    params: AdjustParams


class ReportJobCreate(InputDTO):
    client_request_id: Id
    operation: Literal["report"]
    params: ReportParams


class ReviseJobCreate(InputDTO):
    client_request_id: Id
    operation: Literal["revise"]
    params: ReviseParams


AgentJobCreate = Annotated[
    JobCreate | AdjustJobCreate | ReportJobCreate | ReviseJobCreate, Field(discriminator="operation")
]


class AppliedResource(DTO):
    type: Literal["lesson", "report"]
    id: Id


class AgentStatus(DTO):
    provider: Literal["mock", "agentarts", "unavailable"]
    configured: bool


class AppliedData(DTO):
    applied_resource: AppliedResource


class AiJob(DTO):
    id: Id
    client_request_id: Id
    revision: Positive
    lesson_id: Id
    operation: Operation
    status: JobStatus
    base_plan_version: NonNegative
    base_record_version: NonNegative
    questions: list[Question]
    answers: list[Answer]
    result: AgentResult | None
    error: Error | None
    applied_resource: AppliedResource | None
    created_at: AwareDatetime
    updated_at: AwareDatetime


class JobSummary(DTO):
    id: Id
    client_request_id: Id
    revision: Positive
    operation: Operation
    status: JobStatus
    created_at: AwareDatetime
    updated_at: AwareDatetime
    applied_resource: AppliedResource | None
