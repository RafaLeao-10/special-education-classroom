<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import catalog from "../../../../contracts/examples/catalog.json";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import { reportsApi, type ClassroomReport } from "../../api/services/reports";
import { classroomApi, type ClassroomRecord } from "../../api/services/classroom";

const showcase = catalog.showcase;
const lesson = ref<Lesson>();
const nextLesson = ref<Lesson>();
const report = ref<ClassroomReport>();
const records = ref<ClassroomRecord[]>([]);
const error = ref("");
const loading = ref(true);
const active = ref("plan");
const stages = [
  { key: "plan", name: "课前规划", detail: "共同任务 · 个别目标" },
  { key: "classroom", name: "课堂实施", detail: "逐步指令 · 观察与支持" },
  { key: "report", name: "课后回顾", detail: "证据记录 · 报告留存" },
  { key: "next", name: "下一课衔接", detail: "保留支架 · 逐步迁移" },
];
const people = computed(() => lesson.value?.student_snapshots ?? []);
const tasks = computed(() => lesson.value?.plan?.activities.flatMap(a => a.tasks) ?? []);
const methodNames: Record<string, string> = {
  naturalistic: "自然情境练习", task_analysis: "任务分析", discrete_trial: "短回合练习",
};
const responseNames: Record<string, string> = {
  speech: "口语", gesture: "手势", aac: "辅助沟通", action: "动作", other: "其他",
};
function subject(record: ClassroomRecord) {
  return record.subject.type === "student"
    ? people.value.find(p => p.id === record.subject.id)?.name || "学生"
    : "合作小组";
}
onMounted(async () => {
  try {
    [lesson.value, nextLesson.value, report.value, records.value] = await Promise.all([
      lessonsApi.get(showcase.lesson_id), lessonsApi.get(showcase.next_lesson_id),
      reportsApi.get(showcase.report_id), classroomApi.records(showcase.lesson_id),
    ]);
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    loading.value = false;
  }
});
</script>

<template>
  <main class="showcase-page">
    <header class="showcase-topbar">
      <router-link to="/" class="showcase-brand"><AppIcon name="leaf" :size="25" />特教课堂</router-link>
      <span class="showcase-badge">展示版</span>
      <Button to="/" variant="ghost" size="sm">返回工作台 <AppIcon name="arrow" :size="16" /></Button>
    </header>
    <section class="showcase-hero">
      <p class="eyebrow">一堂课的教学旅程</p>
      <h1>{{ showcase.title }}</h1>
      <p>{{ showcase.subtitle }}</p>
      <div class="showcase-pills"><span>30 分钟 · 三人小组</span><span v-for="method in showcase.methods" :key="method">{{ method }}</span></div>
    </section>
    <div class="showcase-highlights">
      <article v-for="(item, i) in showcase.highlights" :key="item.title">
        <span class="showcase-number">0{{ i + 1 }}</span><h2>{{ item.title }}</h2><p>{{ item.text }}</p>
      </article>
    </div>
    <nav class="showcase-stages" aria-label="教学流程">
      <button v-for="(stage, i) in stages" :key="stage.key" :class="{ selected: active === stage.key }" :aria-pressed="active === stage.key" @click="active = stage.key">
        <span>0{{ i + 1 }}</span><strong>{{ stage.name }}</strong><small>{{ stage.detail }}</small>
      </button>
    </nav>
    <p v-if="loading" class="subtle" role="status">正在读取教学案例…</p>
    <p v-else-if="error" class="inline-error" role="alert">{{ error }}</p>
    <template v-else-if="lesson?.plan && report && nextLesson">
      <section v-if="active === 'plan'" class="showcase-section">
        <div class="section-heading"><div><p class="eyebrow">为每个孩子备课</p><h2>同一堂课，不同的参与路径</h2></div><Button :to="`/lessons/${showcase.live_lesson_id}/prepare`" variant="ghost"
  size="sm">打开完整教案 <AppIcon name="arrow" :size="16" /></Button></div>
        <div class="showcase-people">
          <article v-for="person in people" :key="person.id">
            <div class="showcase-person-heading"><span>{{ person.name.slice(-1) }}</span><h3>{{ person.name }}</h3></div>
            <p class="subtle">{{ person.communication_modes.map(m => responseNames[m]).join(' · ') }}</p>
            <h4>本课衔接的目标</h4><ul><li v-for="goal in person.goals" :key="goal.id">{{ goal.description }}</li></ul>
            <h4>支持安排</h4><p>{{ lesson.plan.activities[2].tasks[0].student_targets.find(t => t.student_id === person.id)?.adaptation_note }}</p>
          </article>
        </div>
        <h2 class="showcase-subheading">一堂课的五个环节</h2>
        <article v-for="activity in lesson.plan.activities" :key="activity.id" class="showcase-activity">
          <div class="showcase-activity-heading"><span class="showcase-number">0{{ activity.order }}</span><div><h3>{{ activity.title }}</h3><p>{{ activity.tasks[0].objective }}</p></div><span class="showcase-time">{{ activity.duration_min }} 分钟</span></div>
          <details v-for="task in activity.tasks" :key="task.id"><summary>{{ task.title }}<span>{{ methodNames[task.practice_format] }} · {{ task.steps.length }} 个步骤</span></summary><ol><li v-for="step in task.steps" :key="step.id"><strong>{{ step.instruction }}</strong><p>预期回应：{{ step.expected_response }}</p><p class="subtle">观察：{{ step.observation_focus }}</p></li></ol><p class="subtle">反馈：{{ task.feedback_guidance }}</p></details>
        </article>
        <div class="showcase-note"><AppIcon name="book" /><div><strong>教师执行单、儿童步骤条、观察单与沟通文字卡</strong><p>教案已包含四类材料，可在打印页面查看与使用。</p></div><Button :to="`/lessons/${showcase.live_lesson_id}/print`" variant="ghost" size="sm">查看材料 <AppIcon name="arrow" :size="16" /></Button></div>
        <div class="section-heading"><div><p class="eyebrow">关注重要时刻</p><h2>把支持落实到每个小步骤</h2></div><Button :to="`/lessons/${showcase.live_lesson_id}/classroom`" variant="primary">进入课堂操作 <AppIcon name="arrow" :size="18" /></Button></div>
        <div class="showcase-note"><AppIcon name="classroom" /><div><strong>先看全课大纲，再专注当前任务</strong><p>教师端支持逐任务展示、文字速记与观察计数；追加提示和常规视觉支持分别记录。</p></div></div>
        <div class="showcase-timeline">
          <article v-for="(record, i) in records" :key="record.id"><span class="showcase-timeline-dot" /><div><span class="showcase-record-meta">{{ String(i + 1).padStart(2, '0') }} · {{ subject(record) }} · {{ record.kind === 'observation' ? '观察计数' : '课堂速记' }}</span><h3>{{ tasks.find(t => t.id === record.task_id)?.title }}</h3><p>{{ record.note }}</p><div v-if="record.counts" class="showcase-pills"><span>独立 {{ record.counts.independent }}</span><span>追加提示后完成 {{ record.counts.prompted }}</span><span v-if="record.counts.not_completed">未完成 {{ record.counts.not_completed }}</span></div></div></article>
        </div>
      </section>
      <section v-else-if="active === 'report'" class="showcase-section">
        <div class="section-heading"><div><p class="eyebrow">让记录成为依据</p><h2>让记录成为下一次教学的依据</h2></div><Button :to="`/lessons/${lesson.id}/report?report_id=${report.id}`" variant="ghost" size="sm">打开已保存报告 <AppIcon name="arrow" :size="16" /></Button></div>
        <div class="showcase-people"><article v-for="item in report.content.student_summaries" :key="item.student_id"><h3>{{ people.find(p => p.id === item.student_id)?.name }}</h3><p>{{ item.text }}</p><span class="subtle">关联 {{ item.record_ids.length }} 条课堂记录</span></article></div>
        <h2 class="showcase-subheading">下一步教学建议</h2>
        <article v-for="(item, i) in report.content.recommendations" :key="i" class="showcase-recommendation"><span class="showcase-number">0{{ i + 1 }}</span><div><h3>{{ people.find(p => p.id === item.subject.id)?.name || '课堂' }}</h3><p>{{ item.action }}</p><p class="subtle">依据：{{ item.basis }}</p></div></article>
        <div v-for="item in report.content.missing_information" :key="item.field" class="showcase-note"><AppIcon name="edit" /><div><strong>下一课继续观察：{{ item.field }}</strong><p>{{ item.description }}</p></div></div>
      </section>
      <section v-else class="showcase-section">
        <div class="section-heading"><div><p class="eyebrow">有目的地衔接</p><h2>保留有效支持，只增加一项变化</h2></div><Button :to="`/lessons/${nextLesson.id}/prepare`" variant="ghost" size="sm">打开后续课教案 <AppIcon name="arrow" :size="16" /></Button></div>
        <div class="showcase-continuity"><article><span class="eyebrow">上一课留下的依据</span><h3>熟悉位置能参与，检查与迁移仍需观察</h3><p>放入步骤已有逐人记录；检查环节的独立表现尚不完整，新位置下的表现还没有观察。</p></article><span class="showcase-continuity-arrow"><AppIcon name="arrow" :size="28" /></span><article><span class="eyebrow">下一课的安排</span><h3>保留标记与步骤条，改变绘本区位置</h3><p>不同时更换材料和支持方式，先观察学生是否寻找新标记，再按需要追加提示，补充检查步骤记录。</p></article></div>
        <div class="showcase-next-outline"><h3>{{ nextLesson.title }}</h3><ol><li v-for="activity in nextLesson.plan?.activities" :key="activity.id"><strong>{{ activity.title }}</strong><span>{{ activity.duration_min }} 分钟</span><p>{{ activity.tasks[0].objective }}</p></li></ol></div>
        <div class="showcase-note"><AppIcon name="report" /><div><strong>后续课已关联本轮确认报告</strong><p>进入备课页可以查看来源报告，继续调整教学方式、材料和任务安排。</p></div></div>
      </section>
    </template>
    <footer class="showcase-footer"><span>特教课堂辅助平台</span><span>课前有准备 · 课堂有支持 · 课后有依据</span></footer>
  </main>
</template>

<style src="./showcase.css"></style>
