from uuid import uuid4

from classroom_api.errors import BusinessError
from classroom_api.lessons.queries import used_goal_ids
from classroom_contracts.http import StudentCreate, StudentPatch
from classroom_contracts.models import Student
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import StudentRow


def to_dto(row: StudentRow) -> Student:
    return Student(id=row.id, name=row.name, revision=row.revision, **row.details)


def get_many(db: Session, ids: list[str]) -> list[Student]:
    rows = {row.id: row for row in db.scalars(select(StudentRow).where(StudentRow.id.in_(ids)))}
    if len(set(ids)) != len(ids) or set(rows) != set(ids):
        raise BusinessError(422, "INVALID_ARGUMENT", "学生编号不存在或重复", ["student_ids"])
    return [to_dto(rows[id]) for id in ids]


def normalize_goals(goals):
    result = [{**goal.model_dump(), "id": goal.id or str(uuid4())} for goal in goals]
    if len({goal["id"] for goal in result}) != len(result):
        raise BusinessError(422, "INVALID_ARGUMENT", "目标ID不能重复", ["goals"])
    return result


def create(db: Session, body: StudentCreate, owner_id: str) -> Student:
    details = body.model_dump(exclude={"name", "goals"})
    details["goals"] = normalize_goals(body.goals)
    row = StudentRow(id=str(uuid4()), owner_id=owner_id, name=body.name, details=details, revision=1)
    db.add(row)
    db.flush()
    return to_dto(row)


def update(db: Session, id: str, body: StudentPatch) -> Student:
    row = db.scalar(select(StudentRow).where(StudentRow.id == id).with_for_update())
    if not row:
        raise BusinessError(404, "NOT_FOUND", "学生不存在")
    if row.revision != body.expected_revision:
        raise BusinessError(409, "VERSION_CONFLICT", "档案已更新，请刷新后重试")
    data = body.model_dump(exclude_unset=True, exclude={"expected_revision"})
    if "goals" in data:
        data["goals"] = normalize_goals(body.goals)
        if not used_goal_ids(db, id) <= {goal["id"] for goal in data["goals"]}:
            raise BusinessError(409, "INVALID_STATE", "当前方案使用的目标ID须保留；可先修正方案")
    if "name" in data:
        row.name = data.pop("name")
    row.details = {**row.details, **data}
    row.revision += 1
    db.flush()
    return to_dto(row)
