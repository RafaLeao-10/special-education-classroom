"""A: business persistence and workflow."""
