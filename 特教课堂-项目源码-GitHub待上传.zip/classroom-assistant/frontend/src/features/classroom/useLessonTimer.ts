import {
computed,
onUnmounted,
ref,
watch,
type ComputedRef,
} from "vue";
import { readDraft, writeDraft } from "../../app/drafts";
import type { LessonPlan } from "../../api/services/lessons";

type Activity = LessonPlan["activities"][number];

type TimerDraft = {
startedAt: number;
activityId?: string;
activityStartedAt?: number;
finishedAt?: number;
};

function fmt(sec: number) {
const m = Math.floor(sec / 60);
const s = sec % 60;
return `${m}:${String(s).padStart(2, "0")}`;
}

export function useLessonTimer(
lessonId: string,
opts: {
    inProgress: ComputedRef<boolean>;
    plannedMin: ComputedRef<number>;
    currentActivity: ComputedRef<Activity | undefined>;
},
) {
const scope = `timer:${lessonId}`;
const draft = readDraft<TimerDraft>(scope);
// 有未结课的草稿（刷新场景）则续用原起表时刻；否则从此刻起表
const startedAt = ref(draft && !draft.finishedAt ? draft.startedAt : Date.now());
const activityId = ref(draft?.activityId);
const activityStartedAt = ref(draft?.activityStartedAt);
const finishedAt = ref<number | undefined>(draft?.finishedAt);

const elapsedSec = ref(0);
const activityRemainSec = ref(0);

function persist() {
    writeDraft(scope, {
    startedAt: startedAt.value,
    activityId: activityId.value,
    activityStartedAt: activityStartedAt.value,
    finishedAt: finishedAt.value,
    });
}

function tick() {
    const end = finishedAt.value ?? Date.now();
    elapsedSec.value = Math.max(0, Math.floor((end - startedAt.value) / 1000));
    const a = opts.currentActivity.value;
    if (a && activityStartedAt.value) {
    activityRemainSec.value = Math.max(
        0,
        a.duration_min * 60 -
        Math.floor((Date.now() - activityStartedAt.value) / 1000),
    );
    }
}

// 活动切换 → 活动倒计时重置
watch(
    () => opts.currentActivity.value?.id,
    (id) => {
    if (!id || !opts.inProgress.value) return;
    if (id !== activityId.value) {
        activityId.value = id;
        activityStartedAt.value = Date.now();
        persist();
    }
    },
);

// 结课 → 冻结课堂用时
watch(opts.inProgress, (v) => {
    if (!v && finishedAt.value === undefined) {
    finishedAt.value = Date.now();
    persist();
    }
});

tick();
const timer = setInterval(tick, 1000);
onUnmounted(() => clearInterval(timer));

const elapsedText = computed(() => fmt(elapsedSec.value));
const elapsedPct = computed(() => {
    const planned = opts.plannedMin.value;
    if (!planned) return 0;
    return Math.min(1, elapsedSec.value / (planned * 60));
});
const activityRemainText = computed(() => fmt(activityRemainSec.value));
const activityOver = computed(() => {
    const a = opts.currentActivity.value;
    return !!a && !!activityStartedAt.value && activityRemainSec.value <= 0;
});

return {
    elapsedText,
    elapsedPct,
    activityRemainText,
    activityOver,
};
}