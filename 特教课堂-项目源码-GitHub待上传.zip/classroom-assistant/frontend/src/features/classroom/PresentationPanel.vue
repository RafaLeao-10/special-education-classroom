<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { assetsApi, type Asset } from "../../api/services/assets";
import { readDraft, writeDraft } from "../../app/drafts";
import Button from "../../components/Button.vue";
const props = defineProps<{ lessonId: string }>();
const scope = `classroom-presentation:${props.lessonId}`;
const selectedId = ref(readDraft<string>(scope) || "");
const files = ref<Asset[]>([]);
const expanded = ref(true);
const page = ref(0);
const busy = ref(false);
const error = ref("");
const selected = computed(() => files.value.find(a => a.id === selectedId.value));
watch(selectedId, value => { writeDraft(scope, value); expanded.value = true; page.value = 0; });
async function load() {
  try { files.value = (await assetsApi.list()).filter(a => a.kind === "file"); error.value = ""; }
  catch (e) { error.value = (e as Error).message; }
}
async function upload(event: Event) {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  busy.value = true;
  error.value = "";
  try {
    const asset = await assetsApi.upload(file, "课堂课件");
    files.value.push(asset);
    selectedId.value = asset.id;
  } catch (e) { error.value = (e as Error).message; }
  finally { busy.value = false; input.value = ""; }
}
onMounted(load);
</script>
<template>
  <section class="presentation-panel">
    <div class="report-actions"><h2>课堂课件</h2>
      <Button v-if="selected" size="sm" variant="ghost" @click="expanded = !expanded">{{ expanded ? '收起预览' : '打开侧边预览' }}</Button>
    </div>
    <label class="presentation-upload">上传 PPT / PPTX / PDF
      <input type="file" accept=".ppt,.pptx,.pdf" :disabled="busy" aria-label="上传课堂PPT" @change="upload" />
    </label>
    <p v-if="busy" class="subtle" role="status">正在保存并生成预览，请稍候…</p>
    <el-select v-model="selectedId" clearable placeholder="选择已上传课件" aria-label="课堂课件" :disabled="busy">
      <el-option v-for="file in files" :key="file.id" :label="file.name" :value="file.id" />
    </el-select>
    <p v-if="error" class="inline-error" role="alert">{{ error }} <Button size="sm" variant="ghost" @click="load">重新读取课件</Button></p>
    <template v-if="selected && expanded">
      <p class="subtle">{{ selected.name }} · 静态预览，不含动画与音视频。</p>
      <template v-if="selected.preview_pages?.length">
        <img :src="selected.preview_pages[page]" :alt="`${selected.name} 第${page + 1}页`" class="slide-image" />
        <div class="slide-navigation">
          <Button size="sm" variant="secondary" :disabled="page === 0" @click="page--">上一页</Button>
          <span>{{ page + 1 }} / {{ selected.preview_pages.length }}</span>
          <Button size="sm" variant="secondary" :disabled="page === selected.preview_pages.length - 1" @click="page++">下一页</Button>
        </div>
      </template>
      <iframe v-else-if="selected.preview_url" :key="selected.id" :src="selected.preview_url" :title="selected.name" class="presentation-preview" />
      <Button :href="selected.url" variant="ghost" size="sm">打开原课件 ↗</Button>
    </template>
    <p v-else-if="!selected" class="subtle">可随时上传课件，在侧边查看，同时保留课堂教学和速记。</p>
  </section>
</template>
<style scoped>
.presentation-panel { min-width: 0; }
.presentation-upload { display: grid; gap: 10px; margin-bottom: 14px; }
.presentation-preview { width: 100%; height: 65vh; min-height: 420px; border: 1px solid var(--border-color, #e4e7ed); border-radius: 12px; }
.slide-image { display: block; width: 100%; border-radius: 10px; }
.slide-navigation { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 12px 0; }
.presentation-panel :deep(.el-select) { width: 100%; }
</style>
