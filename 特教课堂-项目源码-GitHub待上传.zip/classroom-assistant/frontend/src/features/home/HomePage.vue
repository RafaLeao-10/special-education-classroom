<script setup lang="ts">
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
import { lessonsApi } from "../../api/services/lessons";
import "../showcase/showcase.css";
import { computed, onMounted, ref } from "vue";

const recent = ref<Awaited<ReturnType<typeof lessonsApi.list>>["items"]>([]);
const all = ref<Awaited<ReturnType<typeof lessonsApi.list>>["items"]>([]);
const today = computed(() =>
  all.value
    .filter((l) => l.status === "in_progress" || l.status === "ready")
    .sort(
      (a, b) =>
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
    )
    .slice(0, 6),
);
const error = ref("");
const loading = ref(true);
const hasShowcase = ref(false);
const entries = [
  {
    to: "/lessons",
    icon: "book",
    number: "01",
    title: "开始备课",
    en: "课前 · 备课",
    description: "从孩子的目标出发，选择训练方式，编排适合这一堂课的教案。",
    link: "开启课前规划",
    tone: "sage",
  },
  {
    to: "/classroom",
    icon: "classroom",
    number: "02",
    title: "进入课堂",
    en: "课中 · 课堂",
    description: "选择已保存的教案，先看全课大纲，再专注眼前的任务与指令。",
    link: "选择课堂教案",
    tone: "sand",
  },
  {
    to: "/reports",
    icon: "report",
    number: "03",
    title: "课后报告",
    en: "课后 · 报告",
    description: "让课堂速记与补充观察汇成报告，留存每一次值得回看的成长。",
    link: "查看报告档案",
    tone: "lavender",
  },
  {
    to: "/knowledge-graph",
    icon: "graph",
    number: "04",
    title: "知识图谱",
    en: "教学 · 知识",
    description: "连接教学方法、训练技能与支持策略，为下一次教学寻找灵感。",
    link: "探索教学知识",
    tone: "blue",
  },
];
onMounted(async () => {
  try {
    const owned = (await lessonsApi.list()).items;
    all.value = owned;
    hasShowcase.value = owned.some(
      (item) => item.id === "30000000-0000-4000-8000-000000000003",
    );
    recent.value = owned.slice(0, 3);
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    loading.value = false;
  }
});
</script>
<template>
  <div class="home-page">
    <div class="home-hero">
      <div class="hero-copy">
        <p class="eyebrow">特教课堂 · 教师工作台</p>
        <h1>
          把更多注意力，<br />留给每一个孩子<span class="soft-period">。</span>
        </h1>
        <p class="hero-description">
          从课前的一份用心，到课后的一次回望。<br />在这里，让教学的每一步更清晰、更从容。
        </p>
        <div class="hero-caption">
          <span class="tiny-line" />你的教学节奏，由你掌握
        </div>
      </div>
      <div class="hero-art" aria-hidden="true">
        <div class="art-orbit orbit-one" />
        <div class="art-orbit orbit-two" />
        <div class="paper-card paper-back" />
        <div class="paper-card paper-front">
          <div class="paper-heading">
            <span class="mini-leaf"><AppIcon name="leaf" :size="20" /></span
            ><span>一堂课，一点成长</span><span class="paper-dot" />
          </div>
          <div class="paper-rule" />
          <div class="paper-progress">
            <span>准备</span><i /><span>陪伴</span><i /><span>回望</span>
          </div>
          <div class="paper-note">
            <span class="note-check"><AppIcon name="check" :size="16" /></span>
            <div>
              <strong>让目标落在每一个小步骤</strong>
              <p>观察 · 支持 · 鼓励</p>
            </div>
          </div>
          <div class="paper-skeleton"><i /><i /></div>
        </div>
        <div class="art-footnote">小步前进 · 点滴成长</div>
      </div>
    </div>
    <router-link v-if="hasShowcase" to="/showcase" class="showcase-home-link">
      <span class="showcase-badge">展示版</span>
      <div>
        <strong>一堂课的完整教学旅程</strong>
        <p>从个别化备课，到课堂支持、报告与下一课衔接。</p>
      </div>
      <AppIcon name="arrow" :size="24" />
    </router-link>
    <div class="section-heading">
      <div>
        <p class="eyebrow">你的教学空间</p>
        <h2>从这里，开始今天的教学</h2>
      </div>
      <span class="quiet-label">课前 · 课中 · 课后</span>
    </div>
    <div class="entry-grid">
      <router-link
        v-for="entry in entries"
        :key="entry.to"
        :to="entry.to"
        :class="['entry-card', entry.tone]"
        ><div class="entry-top">
          <span class="entry-icon"
            ><AppIcon :name="entry.icon" :size="25" /></span
          ><span class="entry-number">{{ entry.number }}</span>
        </div>
        <div class="entry-copy">
          <p class="entry-en">{{ entry.en }}</p>
          <h2>{{ entry.title }}</h2>
          <p>{{ entry.description }}</p>
        </div>
        <span class="entry-link"
          >{{ entry.link }}<AppIcon name="arrow" :size="20" /></span
      ></router-link>
    </div>
    <section class="today-panel">
        <div class="section-heading compact">
          <div>
            <p class="eyebrow">今日教学</p>
            <h2>今日课堂</h2>
          </div>
          <Button to="/classroom" variant="ghost" size="sm"
            >全部课堂 <AppIcon name="arrow" :size="16" /></Button
          >
        </div>
        <p v-if="error" role="alert" class="inline-error">{{ error }}</p>
        <p v-else-if="loading" class="subtle">正在读取今天的课堂…</p>
        <p v-else-if="!today.length" class="subtle">
          今天还没有进行中或待上的课堂。去「开始备课」准备一节吧。
        </p>
        <router-link
          v-for="lesson in today"
          :key="lesson.id"
          :to="`/lessons/${lesson.id}/classroom`"
          class="recent-row today-row"
          ><span class="recent-icon"
            ><AppIcon name="classroom" :size="20" /></span>
          <div>
            <strong>{{ lesson.title }}</strong
            ><span>{{
              lesson.status === "in_progress"
                ? "课堂进行中 · 继续上课"
                : "教案已确认 · 待上课"
            }}</span>
          </div>
          <span class="status-pill">{{
            lesson.status === "in_progress" ? "课堂中" : "待上课"
          }}</span
          ><AppIcon name="chevron" :size="18"
        /></router-link>
      </section>
    <section class="recent-panel">
      <div class="section-heading compact">
        <div>
          <p class="eyebrow">继续上次的进度</p>
          <h2>最近的备课</h2>
        </div>
        <Button to="/lessons" variant="ghost" size="sm"
          >查看全部 <AppIcon name="arrow" :size="16" /></Button
        >
      </div>
      <p v-if="error" role="alert" class="inline-error">{{ error }}</p>
      <p v-else-if="loading" class="subtle">正在读取你的课程…</p>
      <p v-else-if="!recent.length" class="subtle">
        还没有课程。点击“开始备课”，准备你的第一堂课。
      </p>
      <router-link
        v-for="lesson in recent"
        :key="lesson.id"
        :to="`/lessons/${lesson.id}/${lesson.status === 'completed' ? 'report' : lesson.status === 'in_progress' ? 'classroom' : 'prepare'}`"
        class="recent-row"
        ><span class="recent-icon"><AppIcon name="book" :size="20" /></span>
        <div>
          <strong>{{ lesson.title }}</strong
          ><span
            >{{
              new Date(lesson.updated_at).toLocaleDateString("zh-CN")
            }}
            更新</span
          >
        </div>
        <span class="status-pill">{{
          {
            draft: "备课中",
            ready: "待上课",
            in_progress: "课堂中",
            completed: "已结束",
          }[lesson.status]
        }}</span
        ><AppIcon name="chevron" :size="18"
      /></router-link>
    </section>
  </div>
</template>
