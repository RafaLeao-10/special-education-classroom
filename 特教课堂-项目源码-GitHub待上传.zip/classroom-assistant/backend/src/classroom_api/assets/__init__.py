"""Local teaching image storage."""
