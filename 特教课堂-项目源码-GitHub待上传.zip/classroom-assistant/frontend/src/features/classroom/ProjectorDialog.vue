<script setup lang="ts">
import { computed, onUnmounted, ref, watch } from "vue";
import { ElMessage } from "element-plus";
import { displayApi } from "../../api/services/display";
import { readDraft, writeDraft } from "../../app/drafts";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";
import {
useDisplayChannel,
type DisplayConfig,
} from "../display/useDisplayChannel";

const props = defineProps<{ lessonId: string; defaultDurationMin: number }>();
const open = defineModel<boolean>({ default: false });

const reward = ref("");
const goal = ref(5);
const duration = ref(props.defaultDurationMin);
const sound = ref(true);
const url = ref("");
const opened = ref(false);
const connected = ref(false);
const busy = ref(false);
const error = ref("");
let helloTimer: ReturnType<typeof setTimeout> | undefined;

const channel = useDisplayChannel(
computed(() => props.lessonId),
{
    onHello: () => {
    const wasConnected = connected.value;
    connected.value = true;
    clearTimeout(helloTimer);
    helloTimer = setTimeout(() => (connected.value = false), 8000);
    if (!wasConnected) pushConfig(); // 断线重连后同步一次配置
    },
},
);

function currentConfig(): DisplayConfig {
return {
    reward: reward.value.trim(),
    goal: goal.value,
    duration: duration.value,
    sound: sound.value,
};
}

function pushConfig() {
channel.post({ kind: "config", payload: currentConfig() });
}

async function buildUrl(): Promise<string> {
const res = await displayApi.link(props.lessonId);
const u = new URL(res.url, window.location.origin);
const params = new URLSearchParams();
const cfg = currentConfig();
if (cfg.reward) params.set("reward", cfg.reward);
params.set("goal", String(cfg.goal));
params.set("duration", String(cfg.duration));
params.set("sound", cfg.sound ? "1" : "0");
u.search = params.toString();
return u.href;
}

async function openDisplay() {
busy.value = true;
error.value = "";
try {
    url.value = await buildUrl();
    window.open(url.value, "_blank", "noopener");
    opened.value = true;
    pushConfig();
} catch (e) {
    error.value = (e as Error).message;
} finally {
    busy.value = false;
}
}

async function copyLink() {
error.value = "";
try {
    if (!url.value) {
    busy.value = true;
    url.value = await buildUrl();
    }
    await navigator.clipboard.writeText(url.value);
    ElMessage.success("投屏链接已复制");
} catch {
    if (url.value) {
    // 剪贴板 API 不可用（如非安全上下文）时的旧式回落
    const ta = document.createElement("textarea");
    ta.value = url.value;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
    ElMessage.success("投屏链接已复制");
    }
} finally {
    busy.value = false;
}
}

function addStar(delta: number) {
channel.post({ kind: "stars", delta });
}

function resetStars() {
channel.post({ kind: "reset" });
}

watch(open, (v) => {
if (!v) return;
error.value = "";
const saved = readDraft<DisplayConfig>(`projector:${props.lessonId}`);
if (saved) {
    reward.value = saved.reward ?? "";
    goal.value = saved.goal ?? 5;
    duration.value = saved.duration ?? props.defaultDurationMin;
    sound.value = saved.sound ?? true;
} else {
    reward.value = "";
    goal.value = 5;
    duration.value = props.defaultDurationMin;
    sound.value = true;
}
});

watch([reward, goal, duration, sound], () => {
writeDraft(`projector:${props.lessonId}`, currentConfig());
if (opened.value) pushConfig();
});

onUnmounted(() => clearTimeout(helloTimer));
</script>

<template>
<el-dialog v-model="open" title="学生端大屏" width="560px">
    <p class="subtle">
    生成链接后在本机新窗口或投影设备打开。同一浏览器内的窗口会实时同步下方设置。
    </p>
    <div class="projector-field">
    <label>完成任务后（First-Then 奖励文案）</label>
    <el-input
        v-model="reward"
        maxlength="40"
        placeholder="如：自由活动 5 分钟"
        clearable
    />
    </div>
    <div class="projector-field">
    <label>代币目标（集满几颗星庆祝）</label>
    <el-input-number v-model="goal" :min="1" :max="30" />
    </div>
    <div class="projector-field">
    <label>倒计时（分钟）</label>
    <el-input-number v-model="duration" :min="1" :max="180" />
    </div>
    <div class="projector-field">
    <label>完成音效</label>
    <el-switch v-model="sound" />
    </div>
    <div class="projector-field">
    <el-input :model-value="url" readonly placeholder="链接未生成" />
    <ButtonGroup :gap="12">
        <Button variant="secondary" :loading="busy" @click="copyLink">复制链接</Button>
        <Button variant="primary" :loading="busy" @click="openDisplay"
        >打开大屏</Button
        >
    </ButtonGroup>
    </div>
    <p v-if="error" role="alert" class="inline-error">{{ error }}</p>
    <div v-if="opened" class="projector-field">
    <span class="status-pill">{{
        connected ? "已连接大屏" : "未检测到大屏"
    }}</span>
    <p class="subtle">
        {{
        connected
            ? "配置与代币操作会实时同步到大屏。"
            : "跨设备打开时仅初始链接生效，可在新设备重新打开更新后的链接。"
        }}
    </p>
      <ButtonGroup>
        <Button size="sm" variant="secondary" :disabled="!connected" @click="addStar(1)">加一星</Button>
        <Button size="sm" variant="secondary" :disabled="!connected" @click="addStar(-1)"
          >减一星</Button
        >
        <Button size="sm" variant="quiet" :disabled="!connected" @click="resetStars"
          >清空代币</Button
        >
      </ButtonGroup>
    </div>
</el-dialog>
</template>