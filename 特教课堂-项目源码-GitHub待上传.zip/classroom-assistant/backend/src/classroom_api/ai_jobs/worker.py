import asyncio
import logging
from datetime import UTC, datetime

import httpx
from classroom_contracts.agent import AgentRequest
from pydantic import TypeAdapter
from sqlalchemy import select
from sqlalchemy.orm import sessionmaker

from . import client as agent_client
from .models import JobRow

log = logging.getLogger(__name__)


def recover_interrupted(sessions: sessionmaker):
    with sessions.begin() as db:
        for row in db.scalars(select(JobRow).where(JobRow.status == "running")):
            row.status = "failed"
            row.error = {
                "code": "EXECUTION_INTERRUPTED",
                "message": "服务重启中断了生成，请重新发起",
                "fields": [],
            }
            row.updated_at = datetime.now(UTC)
            row.revision += 1


def claim(sessions: sessionmaker) -> tuple[str, dict, int] | None:
    with sessions.begin() as db:
        row = db.scalar(
            select(JobRow)
            .where(JobRow.status == "queued")
            .order_by(JobRow.created_at)
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        if row is None:
            return None
        row.status = "running"
        row.updated_at = datetime.now(UTC)
        return row.id, row.input_snapshot, row.revision


async def consume(sessions: sessionmaker, client: httpx.AsyncClient, stop: asyncio.Event):
    """One process, one consumer. No transaction is held across the HTTP request."""
    while not stop.is_set():
        job = claim(sessions)
        if job is None:
            try:
                await asyncio.wait_for(stop.wait(), timeout=0.5)
            except TimeoutError:
                pass
            continue
        id, snapshot, revision = job
        try:
            response = await agent_client.run(client, TypeAdapter(AgentRequest).validate_python(snapshot))
        except Exception:
            log.exception("worker error job_id=%s", id)
            response = agent_client.failure(id, "INTERNAL_ERROR", "生成任务执行异常，请按job_id查看A日志")
        with sessions.begin() as db:
            row = db.scalar(select(JobRow).where(JobRow.id == id).with_for_update())
            if row is None or row.status != "running" or row.revision != revision:
                continue
            row.status = response.status
            row.questions = [question.model_dump(mode="json") for question in response.questions]
            row.result = response.result.model_dump(mode="json") if response.result else None
            row.error = response.error.model_dump() if response.error else None
            row.updated_at = datetime.now(UTC)
            row.revision += 1
        log.info("agent completed job_id=%s status=%s", id, response.status)
