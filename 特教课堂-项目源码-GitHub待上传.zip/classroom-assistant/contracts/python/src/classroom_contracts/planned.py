"""Classroom/report DTOs; report generation and voice transcription remain reserved."""

from typing import Literal

from pydantic import AwareDatetime

from .agent import Answer
from .enums import PromptType, RecordKind, ReportStatus
from .http import LessonSummary
from .http import ReportJobCreate as ReportJobCreate
from .models import (
    DTO,
    Counts,
    ExecutionState,
    Id,
    InputDTO,
    NonNegative,
    Positive,
    Record,
    ReportContent,
    Subject,
    TaskState,
)


class LessonAction(InputDTO):
    action: Literal["confirm_plan", "start", "complete"]
    expected_plan_version: NonNegative


class ExecutionPatch(InputDTO):
    split_task_ids: list[Id] | None = None
    expected_record_version: NonNegative | None = None
    task_changes: list[TaskState]
    display_task_id: Id | None
    display_step_id: Id | None


class ExecutionUpdated(DTO):
    execution: ExecutionState
    record_version: NonNegative


class RecordCreate(InputDTO):
    client_record_id: Id
    kind: RecordKind
    subject: Subject
    activity_id: Id | None
    task_id: Id | None
    step_id: Id | None
    task_plan_version: Positive | None
    counts: Counts | None
    routine_support_ids: list[Id]
    prompt_types: list[PromptType]
    note: str
    observed_at: AwareDatetime


class RecordPatch(InputDTO):
    expected_revision: Positive
    kind: RecordKind | None = None
    subject: Subject | None = None
    activity_id: Id | None = None
    task_id: Id | None = None
    step_id: Id | None = None
    task_plan_version: Positive | None = None
    counts: Counts | None = None
    routine_support_ids: list[Id] | None = None
    prompt_types: list[PromptType] | None = None
    note: str | None = None
    observed_at: AwareDatetime | None = None
    is_void: bool | None = None


class RecordSaved(DTO):
    record: Record
    record_version: NonNegative


class RecordCorrection(DTO):
    revision: Positive
    before: Record
    after: Record
    changed_at: AwareDatetime
    changed_by: Id


class TeacherReportCreate(InputDTO):
    """Teacher-written report; does not invoke or impersonate an Agent."""

    client_request_id: Id
    expected_plan_version: NonNegative
    expected_record_version: NonNegative
    content: ReportContent


class JobResume(InputDTO):
    client_request_id: Id
    expected_revision: Positive
    answers: list[Answer]


class JobRetry(InputDTO):
    expected_revision: Positive


class ReportSummary(DTO):
    id: Id
    lesson_id: Id
    status: ReportStatus
    revision: Positive
    source_plan_version: NonNegative
    source_record_version: NonNegative
    is_stale: bool
    generated_at: AwareDatetime
    confirmed_at: AwareDatetime | None
    authoring_mode: Literal["teacher", "agent"] = "agent"


class ReportChoice(ReportSummary):
    lesson_title: str
    student_ids: list[Id]


class ReportArchiveItem(ReportSummary):
    lesson_title: str
    student_ids: list[Id]
    student_names: list[str]
    overview: str


class ReportArchive(DTO):
    items: list[ReportArchiveItem]
    total: NonNegative
    page: Positive
    page_size: Positive
    unreported_lessons: list[LessonSummary]


class ReportPatch(InputDTO):
    expected_revision: Positive
    content: ReportContent


class ReportAction(InputDTO):
    action: Literal["confirm", "reopen"]
    expected_revision: Positive


class Transcription(DTO):
    """Proposed extension: temporary transcript; a teacher must review before RecordCreate."""

    text: str
    language: str | None
