<script setup lang="ts">
import { computed } from "vue";
import type { Lesson, LessonPlan } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import {
  newActivity,
  newTask,
  reorder,
  normalizeOrder,
  pruneTaskReferences,
  syncTargets,
} from "./planDraft";
import TaskEditor from "./TaskEditor.vue";
import PlanResourcesEditor from "./PlanResourcesEditor.vue";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

const plan = defineModel<LessonPlan>({ required: true });
const props = defineProps<{ lesson: Lesson; students: Student[] }>();
const people = computed(() =>
  props.students.filter((s) => props.lesson.student_ids.includes(s.id)),
);
const duration = computed(() =>
  plan.value.activities.reduce((sum, a) => sum + a.duration_min, 0),
);
function addActivity() {
  plan.value.activities.push(newActivity(props.lesson, people.value));
  normalizeOrder(plan.value.activities);
}
function moveActivity(i: number, delta: number) {
  reorder(plan.value.activities, i, delta);
  normalizeOrder(plan.value.activities);
}
function removeActivity(i: number) {
  plan.value.activities.splice(i, 1);
  normalizeOrder(plan.value.activities);
  pruneTaskReferences(plan.value);
}
function changeParticipants(index: number) {
  const activity = plan.value.activities[index];
  for (const t of activity.tasks) {
    t.participant_ids = t.participant_ids.filter((id) =>
      activity.participant_ids.includes(id),
    );
    syncTargets(t, people.value);
  }
}
function groupMembersChanged(id: string) {
  const group = plan.value.groups.find((g) => g.id === id);
  if (!group) return;
  plan.value.activities.forEach((activity, index) => {
    if (activity.group_id === id) {
      activity.participant_ids = activity.participant_ids.filter((s) =>
        group.student_ids.includes(s),
      );
      changeParticipants(index);
    }
  });
}
function groupChanged(index: number) {
  const activity = plan.value.activities[index];
  const group = plan.value.groups.find((g) => g.id === activity.group_id);
  if (group) {
    activity.participant_ids = [...group.student_ids];
    changeParticipants(index);
  }
}
function removeTask(ai: number, ti: number) {
  plan.value.activities[ai].tasks.splice(ti, 1);
  pruneTaskReferences(plan.value);
}
</script>
<template>
  <div class="plan-editor">
    <p class="subtle">
      编辑并保存教案后，即可用于课堂。
    </p>
    <label
      >教案标题<el-input v-model="plan.title" aria-label="教案标题" /></label
    ><PlanResourcesEditor
      v-model="plan"
      :students="people"
      @group-changed="groupMembersChanged"
    />
    <p
      :class="
        duration > lesson.planned_duration_min ? 'inline-error' : 'subtle'
      "
    >
      活动合计 {{ duration }} 分钟 / 计划 {{ lesson.planned_duration_min }} 分钟
    </p>
    <div
      v-for="(activity, ai) in plan.activities"
      :key="activity.id"
      class="editor-activity"
    >
      <div class="editor-heading">
        <h3>活动 {{ ai + 1 }}</h3>
        <ButtonGroup>
          <Button
            size="sm"
            variant="ghost"
            :disabled="ai === 0"
            @click="moveActivity(ai, -1)"
            >上移活动</Button
          ><Button
            size="sm"
            variant="ghost"
            :disabled="ai === plan.activities.length - 1"
            @click="moveActivity(ai, 1)"
            >下移活动</Button
          ><Button
            size="sm"
            variant="quiet"
            :disabled="plan.activities.length === 1"
            @click="removeActivity(ai)"
            >移除活动</Button
          >
        </ButtonGroup>
      </div>
      <div class="editor-fields">
        <label
          >活动名称<el-input
            v-model="activity.title"
            aria-label="活动名称" /></label
        ><label
          >活动时长<el-input-number
            v-model="activity.duration_min"
            :min="1"
            :precision="0"
            :value-on-clear="1"
            aria-label="活动时长" /></label
        ><label
          >活动类型<el-select v-model="activity.activity_type"
            ><el-option value="individual" label="个别教学" /><el-option
              value="group"
              label="小组教学" /><el-option
              value="routine"
              label="常规活动" /></el-select></label
        ><label
          >关联小组<el-select
            v-model="activity.group_id"
            clearable
            @change="
              activity.group_id = activity.group_id || null;
              groupChanged(ai);
            "
            ><el-option
              v-for="g in plan.groups"
              :key="g.id"
              :value="g.id"
              :label="g.label" /></el-select
        ></label>
      </div>
      <label
        >活动参与学生<el-select
          v-model="activity.participant_ids"
          multiple
          aria-label="活动参与学生"
          @change="changeParticipants(ai)"
          ><el-option
            v-for="s in people.filter(
              (s) =>
                !activity.group_id ||
                plan.groups
                  .find((g) => g.id === activity.group_id)
                  ?.student_ids.includes(s.id),
            )"
            :key="s.id"
            :value="s.id"
            :label="s.name" /></el-select
      ></label>
      <details
        v-for="(task, ti) in activity.tasks"
        :key="task.id"
        class="editor-details task-details"
        :open="activity.tasks.length === 1"
      >
        <summary>任务 {{ ti + 1 }} · {{ task.title || "未命名任务" }}</summary>
        <div class="editor-heading">
          <strong>任务内容</strong>
          <ButtonGroup>
            <Button
              size="sm"
              variant="ghost"
              :disabled="ti === 0"
              @click="reorder(activity.tasks, ti, -1)"
              >上移任务</Button
            ><Button
              size="sm"
              variant="ghost"
              :disabled="ti === activity.tasks.length - 1"
              @click="reorder(activity.tasks, ti, 1)"
              >下移任务</Button
            ><Button
              size="sm"
              variant="quiet"
              :disabled="activity.tasks.length === 1"
              @click="removeTask(ai, ti)"
              >移除任务</Button
            >
          </ButtonGroup>
        </div>
        <TaskEditor
          v-model="activity.tasks[ti]"
          :participants="activity.participant_ids"
          :students="people"
          :lesson="lesson"
          :plan="plan"
        />
      </details>
      <Button
        size="sm"
        variant="secondary"
        @click="activity.tasks.push(newTask(activity.participant_ids, people))"
        >添加任务</Button
      >
    </div>
    <Button size="sm" variant="secondary" @click="addActivity">添加活动</Button>
  </div>
</template>
