<script setup lang="ts">
import type { AiJob, Answer } from "../../api/services/jobs";
import JobQuestions from "./JobQuestions.vue";
import Button from "../../components/Button.vue";
import AppIcon from "../../components/AppIcon.vue";

defineProps<{
  job: AiJob | null;
  running: boolean;
  error: string;
  pending?: boolean;
  hideClassroomLink?: boolean;
}>();
defineEmits<{ resume: [answers: Answer[]]; poll: []; retry: [] }>();
const labels = {
  queued: "等待生成",
  running: "正在生成",
  needs_input: "等待教师补充",
  succeeded: "已生成",
  failed: "本次生成未完成",
};
</script>
<template>
  <Button v-if="!running" size="sm" variant="ghost" @click="$emit('poll')"
    >刷新智能服务与任务状态</Button
  >
  <p v-if="error" class="inline-error" role="alert">
    {{ error }}
    <Button size="sm" variant="ghost" :disabled="running" @click="$emit('poll')"
      >重新查询</Button
    >
  </p>
  <p v-if="pending" class="preview-notice">
    上次提交尚未确认结果。<Button
      size="sm"
      variant="ghost"
      :disabled="running"
      @click="$emit('retry')"
      >重试上次提交</Button
    >
  </p>
  <div v-if="job" class="job-state" aria-live="polite">
    <p>{{ labels[job.status] }}</p>
    <p v-if="running" class="subtle">生成期间可以刷新页面找回本次任务。</p>
    <p v-if="job.error" class="inline-error" role="alert">
      {{ job.error.message }}
    </p>
    <Button
      v-if="job.status === 'failed' && !pending"
      size="sm"
      variant="secondary"
      :disabled="running"
      @click="$emit('retry')"
      >按最新课堂资料重试本次生成</Button
    >
    <p v-if="job.applied_resource" class="subtle">
      本次结果已采用保存。
      <Button v-if="job.applied_resource.type === 'report'" to="/reports" variant="ghost" size="sm" class="btn-arrow">前往报告档案室查看
  <AppIcon name="arrow" :size="16" /></Button>
        <Button v-else-if="!hideClassroomLink" :to="`/lessons/${job.lesson_id}/classroom`" variant="ghost" size="sm" class="btn-arrow">打开课堂查看 <AppIcon
  name="arrow" :size="16" /></Button>
    </p>
    <JobQuestions
      v-if="job.status === 'needs_input'"
      :job="job"
      :busy="running || !!pending"
      @submit="$emit('resume', $event)"
    />
  </div>
</template>
