import { client, unwrap } from "../client";
import type { components } from "../generated/schema";
type Schema = components["schemas"];
export type ClassroomRecord = Schema["Record"];
export type RecordInput = Schema["RecordCreate"];
export type RecordCorrection = Schema["RecordCorrection"];
export const classroomApi = {
  action: async (id: string, body: Schema["LessonAction"]) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/actions", {
        params: { path: { id } },
        body,
      }),
    ),
  execution: async (id: string, body: Schema["ExecutionPatch"]) =>
    unwrap(
      await client.PATCH("/api/v1/lessons/{id}/execution", {
        params: { path: { id } },
        body,
      }),
    ),
  records: async (id: string, include_void = false) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/records", {
        params: { path: { id }, query: { include_void } },
      }),
    ).items,
  createRecord: async (id: string, body: RecordInput) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/records", {
        params: { path: { id } },
        body,
      }),
    ),
  updateRecord: async (
    id: string,
    record_id: string,
    body: Schema["RecordPatch"],
  ) =>
    unwrap(
      await client.PATCH("/api/v1/lessons/{id}/records/{record_id}", {
        params: { path: { id, record_id } },
        body,
      }),
    ),
  history: async (id: string, record_id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/records/{record_id}/history", {
        params: { path: { id, record_id } },
      }),
    ).items,
  plans: async (id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/plan-snapshots", {
        params: { path: { id } },
      }),
    ).items,
};
