import { client, unwrap } from "../client";
import type { paths, components } from "../generated/schema";
type Schema = components["schemas"];
export type ClassroomReport = Schema["Report"];
export type ReportSummary = Schema["ReportSummary"];
export type ReportContent = Schema["ReportContent"];
export type TeacherReportInput = Schema["TeacherReportCreate"];
export type ReportArchive = Schema["ReportArchive"];
export type ReportArchiveQuery = NonNullable<
  paths["/api/v1/report-archive"]["get"]["parameters"]["query"]
>;
export const reportsApi = {
  archive: async (query: ReportArchiveQuery) =>
    unwrap(await client.GET("/api/v1/report-archive", { params: { query } })),
  choices: async (student_ids: string[]) =>
    unwrap(
      await client.GET("/api/v1/reports", {
        params: { query: { student_ids } },
      }),
    ).items,
  list: async (id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/reports", {
        params: { path: { id } },
      }),
    ).items,
  create: async (id: string, body: TeacherReportInput) =>
    unwrap(
      await client.POST("/api/v1/lessons/{id}/reports", {
        params: { path: { id } },
        body,
      }),
    ),
  get: async (report_id: string) =>
    unwrap(
      await client.GET("/api/v1/reports/{report_id}", {
        params: { path: { report_id } },
      }),
    ),
  update: async (report_id: string, body: Schema["ReportPatch"]) =>
    unwrap(
      await client.PATCH("/api/v1/reports/{report_id}", {
        params: { path: { report_id } },
        body,
      }),
    ),
  action: async (report_id: string, body: Schema["ReportAction"]) =>
    unwrap(
      await client.POST("/api/v1/reports/{report_id}/actions", {
        params: { path: { report_id } },
        body,
      }),
    ),
};
