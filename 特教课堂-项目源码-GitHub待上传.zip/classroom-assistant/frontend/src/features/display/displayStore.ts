export function displayGet<T>(key: string): T | null {
try {
    return JSON.parse(
    localStorage.getItem(`display:${key}`) || "null",
    ) as T | null;
} catch {
    return null;
}
}

export function displaySet(key: string, value: unknown) {
try {
    localStorage.setItem(`display:${key}`, JSON.stringify(value));
} catch {
    /* 存储不可用时静默，不影响大屏主流程 */
}
}