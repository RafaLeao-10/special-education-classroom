<script setup lang="ts">
withDefaults(defineProps<{ gap?: number }>(), { gap: 8 });
</script>

<template>
  <div class="btn-group" :style="{ gap: `${gap}px` }">
    <slot />
  </div>
</template>
