import createClient from "openapi-fetch";
import type { paths } from "./generated/schema";

const apiBase = import.meta.env.VITE_API_BASE_URL || "/api/v1";
export const client = createClient<paths>({
  // OpenAPI paths already contain /api/v1; retain any preceding proxy prefix.
  baseUrl: apiBase.replace(/\/api\/v1\/?$/, ""),
  credentials: "same-origin",
});
client.use({
  onResponse({ response, schemaPath }) {
    if (response.status === 401 && schemaPath !== "/api/v1/auth/login") {
      window.dispatchEvent(new Event("auth-required"));
    }
  },
});

export class ApiError extends Error {
  constructor(
    message: string,
    public code: string,
    public status: number,
  ) {
    super(message);
  }
}

export function unwrap<T>(result: {
  data?: { data?: T | null };
  error?: unknown;
  response?: Response;
}): T {
  if (result.error) {
    const body = result.error as {
      error?: { message?: string; code?: string };
    };
    throw new ApiError(
      body.error?.message || "请求失败，请稍后重试",
      body.error?.code || "REQUEST_FAILED",
      result.response?.status || 0,
    );
  }
  if (result.data?.data == null) throw new Error("服务未返回有效数据");
  return result.data.data;
}
