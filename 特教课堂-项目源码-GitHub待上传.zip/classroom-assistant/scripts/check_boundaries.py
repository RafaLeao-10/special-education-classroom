"""Keep the three-team import boundaries explicit without adding a framework."""

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RULES = {
    "backend/src": {"classroom_agent"},
    "agent-service/src": {"classroom_api"},
    "contracts/python/src": {
        "classroom_api",
        "classroom_agent",
        "sqlalchemy",
        "psycopg",
        "httpx",
        "fastapi",
        "pydantic_settings",
    },
}


def main():
    for directory, forbidden in RULES.items():
        for path in (ROOT / directory).rglob("*.py"):
            for node in ast.walk(ast.parse(path.read_text("utf-8"), filename=str(path))):
                modules = []
                if isinstance(node, ast.Import):
                    modules = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                    modules = [node.module]
                for module in modules:
                    if module.split(".")[0] in forbidden:
                        raise SystemExit(
                            f"模块边界不符合约定：{path.relative_to(ROOT)}:{node.lineno} → {module}"
                        )
    print("A/B包依赖方向与纯契约导入边界检查通过。")


if __name__ == "__main__":
    main()
