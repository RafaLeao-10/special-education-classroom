"""A validates structural references, not teaching statistics or generation quality."""

from classroom_api.errors import BusinessError
from classroom_contracts.models import Lesson, LessonPlan, Student


def check_plan(plan: LessonPlan, lesson: Lesson, students: list[Student], *, allow_draft: bool = False):
    def require(condition, field, message="方案字段或关联无效"):
        if not condition:
            raise BusinessError(422, "INVALID_ARGUMENT", message, [field])

    def unique(values, field):
        require(len(values) == len(set(values)), field)

    require(allow_draft or bool(plan.title.strip()), "plan.title", "开课前请填写教案标题")
    participants = set(lesson.student_ids)
    student_map = {student.id: student for student in students}
    materials = {material.id for material in lesson.available_materials}
    groups = {group.id: group for group in plan.groups}
    supports = {support.id for support in plan.supports}
    knowledge = {ref.knowledge_id for ref in plan.references}
    ids = [group.id for group in plan.groups] + [support.id for support in plan.supports]
    require(
        sum(activity.duration_min for activity in plan.activities) <= lesson.planned_duration_min,
        "activities.duration_min",
    )
    require(
        [activity.order for activity in plan.activities] == list(range(1, len(plan.activities) + 1)),
        "activities.order",
    )
    for group in plan.groups:
        require(bool(group.student_ids) and set(group.student_ids) <= participants, "groups.student_ids")
        unique(group.student_ids, "groups.student_ids")
    task_ids = set()
    for activity in plan.activities:
        ids.append(activity.id)
        require(allow_draft or bool(activity.title.strip()), "activities.title", "开课前请填写活动名称")
        require(
            bool(activity.participant_ids) and set(activity.participant_ids) <= participants,
            "activities.participant_ids",
        )
        unique(activity.participant_ids, "activities.participant_ids")
        require(activity.group_id is None or activity.group_id in groups, "activities.group_id")
        if activity.group_id:
            require(
                set(activity.participant_ids) <= set(groups[activity.group_id].student_ids),
                "activities.group_id",
            )
        for task in activity.tasks:
            ids.append(task.id)
            require(allow_draft or bool(task.title.strip()), "tasks.title", "开课前请填写任务名称")
            task_ids.add(task.id)
            require(
                bool(task.participant_ids) and set(task.participant_ids) <= set(activity.participant_ids),
                "tasks.participant_ids",
            )
            unique(task.participant_ids, "tasks.participant_ids")
            require(set(task.material_ids) <= materials, "tasks.material_ids")
            require(set(task.knowledge_refs) <= knowledge, "tasks.knowledge_refs")
            require(
                sorted(target.student_id for target in task.student_targets) == sorted(task.participant_ids),
                "tasks.student_targets",
            )
            for target in task.student_targets:
                require(
                    (allow_draft or bool(target.goal_ids))
                    and set(target.goal_ids) <= {goal.id for goal in student_map[target.student_id].goals},
                    "student_targets.goal_ids",
                    "请为每名参与学生选择有效教学目标后开课",
                )
                require(
                    allow_draft or bool(target.accepted_response_modes),
                    "student_targets.accepted_response_modes",
                    "请为学生选择可接受的回应方式后开课",
                )
                require(set(target.routine_support_ids) <= supports, "student_targets.routine_support_ids")
            require([step.order for step in task.steps] == list(range(1, len(task.steps) + 1)), "steps.order")
            for step in task.steps:
                require(
                    allow_draft or bool(step.instruction.strip()),
                    "steps.instruction",
                    "开课前请填写每个步骤的指令",
                )
            ids.extend(step.id for step in task.steps)
    for resource in plan.resources:
        ids.append(resource.id)
        require(set(resource.task_ids) <= task_ids, "resources.task_ids")
    unique(ids, "plan.id")
