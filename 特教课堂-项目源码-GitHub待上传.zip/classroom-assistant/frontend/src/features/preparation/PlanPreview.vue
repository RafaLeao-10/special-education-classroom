<script setup lang="ts">
import BlocksRenderer from "../../components/BlocksRenderer.vue";
import type { components } from "../../api/generated/schema";
import type { LessonPlan } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
defineProps<{ plan: LessonPlan; students: Student[]; editable?: boolean }>();
const emit = defineEmits<{
  blocks: [
    ai: number,
    ti: number,
    si: number,
    value: components["schemas"]["Step"]["display_blocks"],
  ];
  instruction: [
    activityIndex: number,
    taskIndex: number,
    stepIndex: number,
    value: string,
  ];
}>();
</script>
<template>
  <div class="plan-preview">
    <h2>{{ plan.title }}</h2>
    <article v-for="(activity, ai) in plan.activities" :key="activity.id">
      <h3>
        {{ activity.order }}. {{ activity.title }}
        <small>{{ activity.duration_min }} 分钟</small>
      </h3>
      <div v-for="(task, ti) in activity.tasks" :key="task.id" class="task">
        <h4>{{ task.title }}</h4>
        <p>{{ task.objective }}</p>
        <ul>
          <li v-for="target in task.student_targets" :key="target.student_id">
            <strong>
              {{
                students.find((s) => s.id === target.student_id)?.name ||
                target.student_id
              }}
            </strong>
            ：{{ target.completion_criterion }}
            <p class="subtle">
              目标：{{
                target.goal_ids
                  .map(
                    (id) =>
                      students
                        .find((s) => s.id === target.student_id)
                        ?.goals.find((g) => g.id === id)?.description || id,
                  )
                  .join("；")
              }}
            </p>
          </li>
        </ul>
        <p>准备：{{ task.teacher_preparation }}</p>
        <ol>
          <li v-for="(step, si) in task.steps" :key="step.id">
            <el-input
              v-if="editable"
              :model-value="step.instruction"
              @update:model-value="emit('instruction', ai, ti, si, $event)"
              :aria-label="`步骤${step.order}指令`"
            />
            <strong v-else>{{ step.instruction }}</strong>
            <p class="subtle">
              预期反应：{{ step.expected_response }}；观察：{{
                step.observation_focus
              }}
            </p>
            <p v-if="step.demonstration">示范：{{ step.demonstration }}</p>
          </li>
        </ol>
        <p>反馈：{{ task.feedback_guidance }}</p>
      </div>
    </article>
    <h3>文字资料</h3>
    <article v-for="resource in plan.resources" :key="resource.id">
      <h4>{{ resource.title }}</h4>
      <BlocksRenderer :blocks="resource.blocks" />
    </article>
  </div>
</template>
