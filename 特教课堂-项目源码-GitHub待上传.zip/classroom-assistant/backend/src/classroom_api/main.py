import asyncio
import logging
from contextlib import asynccontextmanager

import httpx
from fastapi import APIRouter, FastAPI
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

from classroom_api.ai_jobs import worker
from classroom_api.ai_jobs.router import router as jobs_router
from classroom_api.assets.router import router as assets_router
from classroom_api.auth.router import router as auth_router
from classroom_api.display.router import router as display_router
from classroom_api.errors import install_handlers
from classroom_api.lessons.router import router as lessons_router
from classroom_api.records.router import router as records_router
from classroom_api.reports.router import router as reports_router
from classroom_api.settings import Settings
from classroom_api.statistics.router import router as statistics_router
from classroom_api.students.router import router as students_router

log = logging.getLogger(__name__)


def report_worker_exit(task: asyncio.Task):
    if not task.cancelled() and (error := task.exception()) is not None:
        log.error("生成消费者已停止；/ready将返回503，请修正错误后重启A", exc_info=error)


def create_app(settings: Settings | None = None, *, start_worker: bool = True) -> FastAPI:
    config = settings or Settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s %(message)s")
        engine = create_engine(config.database_url, pool_pre_ping=True, connect_args={"connect_timeout": 5})
        app.state.sessions = sessionmaker(engine, expire_on_commit=False)
        app.state.engine = engine
        stop = asyncio.Event()
        task = None
        timeout = httpx.Timeout(config.agent_read_timeout_sec, connect=config.agent_connect_timeout_sec)
        try:
            async with httpx.AsyncClient(
                base_url=config.agent_gateway_url, timeout=timeout, trust_env=False
            ) as client:
                app.state.teaching_client = client
                if start_worker:
                    worker.recover_interrupted(app.state.sessions)
                    task = asyncio.create_task(worker.consume(app.state.sessions, client, stop))
                    task.add_done_callback(report_worker_exit)
                app.state.worker_task = task
                try:
                    yield
                finally:
                    stop.set()
                    if task:
                        task.cancel()
                        # Failure is logged by the callback and exposed through /ready.
                        await asyncio.gather(task, return_exceptions=True)
        finally:
            engine.dispose()

    app = FastAPI(title="Classroom Assistant API", version="1.0", lifespan=lifespan)
    app.state.settings = config
    install_handlers(app)
    api = APIRouter(prefix="/api/v1")
    for router in (
        auth_router,
        students_router,
        lessons_router,
        jobs_router,
        records_router,
        reports_router,
        statistics_router,
        assets_router,
        display_router,
    ):
        api.include_router(router)
    app.include_router(api)

    @app.get("/health", include_in_schema=False)
    def health():
        return {"status": "ok", "service": "classroom-api"}

    @app.get("/ready", include_in_schema=False)
    def ready():
        try:
            with app.state.engine.connect() as connection:
                connection.execute(text("SELECT 1"))
            task = app.state.worker_task
            if start_worker and task is not None and task.done():
                return JSONResponse(
                    status_code=503,
                    content={"status": "not_ready", "database": "ok", "worker": "stopped"},
                )
            return {"status": "ready", "database": "ok"}
        except SQLAlchemyError:
            return JSONResponse(status_code=503, content={"status": "not_ready", "database": "unavailable"})

    return app
