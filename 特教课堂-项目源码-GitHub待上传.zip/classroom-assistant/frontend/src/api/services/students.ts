import { client, unwrap } from "../client";
import type { components } from "../generated/schema";

export type Student = components["schemas"]["Student"];
export type StudentInput = components["schemas"]["StudentCreate"];
export const studentsApi = {
  list: async () => unwrap(await client.GET("/api/v1/students")),
  create: async (body: StudentInput) =>
    unwrap(await client.POST("/api/v1/students", { body })),
  update: async (id: string, body: components["schemas"]["StudentPatch"]) =>
    unwrap(
      await client.PATCH("/api/v1/students/{id}", {
        params: { path: { id } },
        body,
      }),
    ),
};
