"""Per-lesson teacher report drafts and confirmation; no generated teaching statistics."""
