<script setup lang="ts">
defineProps<{ task: string; reward: string }>();
</script>

<template>
<div class="first-then">
    <div class="ft-card">
    <small>先完成</small>
    <strong>{{ task || "当前任务" }}</strong>
    </div>
    <span class="ft-arrow" aria-hidden="true">→</span>
    <div class="ft-card ft-then">
    <small>然后</small>
    <strong>{{ reward || "好玩的奖励" }}</strong>
    </div>
</div>
</template>