"""Read-only checks with actionable messages; never print connection strings."""

import httpx
from alembic.config import Config
from alembic.script import ScriptDirectory
from classroom_api.settings import ROOT, Settings
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

config = Settings()
failed = False
engine = create_engine(config.database_url, connect_args={"connect_timeout": 3})
try:
    with engine.connect() as db:
        db.execute(text("SELECT 1"))
        revision = db.execute(text("SELECT version_num FROM alembic_version")).scalar()
    if revision != ScriptDirectory.from_config(Config(str(ROOT / "backend/alembic.ini"))).get_current_head():
        failed = True
        print("[待处理] 数据库迁移未到当前版本：运行 pnpm db:migrate")
    else:
        print("[通过] 数据库连接与迁移版本")
except SQLAlchemyError:
    failed = True
    print("[待处理] 数据库不可用或尚未迁移：检查.env两条数据库地址，启动数据库并运行 pnpm db:migrate")
finally:
    engine.dispose()
print("[通过] 会话配置" if config.session_secret else "[待处理] 缺少会话密钥：先运行 pnpm bootstrap")
failed |= not bool(config.session_secret)
for name, url in (
    ("A业务接口", "http://127.0.0.1:8000/ready"),
    ("B计算服务", config.agent_gateway_url + "/health"),
    ("F网页", "http://127.0.0.1:5173"),
):
    try:
        result = httpx.get(url, timeout=3, trust_env=False)
        print(f"[{'通过' if result.status_code == 200 else '待处理'}] {name}：HTTP {result.status_code}")
    except httpx.HTTPError:
        print(f"[提示] {name}未启动，开发时运行 pnpm dev")
print("本地素材目录：已存在" if config.asset_dir.exists() else "本地素材目录：首次上传时创建")
raise SystemExit(1 if failed else 0)
