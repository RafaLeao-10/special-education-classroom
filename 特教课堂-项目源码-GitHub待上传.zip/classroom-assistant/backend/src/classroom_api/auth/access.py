"""Ownership checks at HTTP entry points; child resources inherit their lesson owner."""

from classroom_api.db import get_db
from classroom_api.errors import BusinessError
from classroom_api.lessons.models import LessonRow
from classroom_api.students.models import StudentRow
from fastapi import Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from .service import require_user


def owned_lesson(db, lesson_id, owner_id):
    row = db.scalar(select(LessonRow).where(LessonRow.id == lesson_id, LessonRow.owner_id == owner_id))
    if row is None:
        raise BusinessError(404, "NOT_FOUND", "课程不存在")
    return row


def require_lesson(id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    return owned_lesson(db, id, user.id)


def require_student(id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    require_students(db, [id], user.id)


def require_students(db, ids, owner_id):
    found = set(
        db.scalars(select(StudentRow.id).where(StudentRow.id.in_(ids), StudentRow.owner_id == owner_id))
    )
    if found != set(ids):
        raise BusinessError(404, "NOT_FOUND", "学生档案不存在")


def require_reports(db, ids, owner_id):
    from classroom_api.reports.models import ReportRow

    found = set(
        db.scalars(
            select(ReportRow.id).join(LessonRow).where(ReportRow.id.in_(ids), LessonRow.owner_id == owner_id)
        )
    )
    if found != set(ids):
        raise BusinessError(404, "NOT_FOUND", "来源报告不存在")


def require_report(report_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    require_reports(db, [report_id], user.id)


def require_job(job_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    from classroom_api.ai_jobs.models import JobRow

    row = db.scalar(select(JobRow).join(LessonRow).where(JobRow.id == job_id, LessonRow.owner_id == user.id))
    if row is None:
        raise BusinessError(404, "NOT_FOUND", "生成任务不存在")
    return row
