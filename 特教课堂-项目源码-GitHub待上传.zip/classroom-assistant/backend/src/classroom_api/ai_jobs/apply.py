from datetime import UTC, datetime

from classroom_api.errors import BusinessError
from classroom_api.lessons import service as lessons
from classroom_api.lessons.adjustments import apply as apply_adjustment
from classroom_api.lessons.revisions import apply as apply_revision
from classroom_api.reports.service import save_agent_draft
from classroom_contracts.agent import AdjustmentProposal, AdjustParams, PlanRevision, RevisionScope
from classroom_contracts.http import AppliedResource
from classroom_contracts.models import LessonPlan, ReportDraft
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import JobRow
from .service import get


def apply_result(db: Session, id: str) -> AppliedResource:
    initial = get(db, id)
    lesson = lessons.get(db, initial.lesson_id, lock=True)
    row = db.scalar(
        select(JobRow).where(JobRow.id == id).with_for_update().execution_options(populate_existing=True)
    )
    if row.applied_resource:
        return AppliedResource.model_validate(row.applied_resource)
    if row.status != "succeeded" or not row.result:
        raise BusinessError(409, "INVALID_STATE", "仅可采用已成功生成的结果")
    if (lesson.plan_version, lesson.record_version) != (row.base_plan_version, row.base_record_version):
        raise BusinessError(409, "VERSION_CONFLICT", "生成后课堂资料已变化，请重新生成再采用")
    if row.operation in ("prepare", "revise"):
        from classroom_api.reports.queries import get_previous, validate_previous
        from classroom_api.students.service import get_many

        versions = {s["id"]: s["revision"] for s in row.input_snapshot["students"]}
        if any(versions.get(s.id) != s.revision for s in get_many(db, lesson.student_ids)):
            raise BusinessError(409, "VERSION_CONFLICT", "学生档案已更新，请按最新档案重新生成")
        validate_previous(db, lesson.previous_report_ids, lesson.student_ids)
        previous_versions = {r["id"]: r["revision"] for r in row.input_snapshot["previous_reports"]}
        if any(
            previous_versions.get(r.id) != r.revision for r in get_previous(db, lesson.previous_report_ids)
        ):
            raise BusinessError(409, "VERSION_CONFLICT", "来源报告已更新，请重新生成")
    kind, data = row.result["kind"], row.result["data"]
    if row.operation == "prepare" and kind == "plan":
        lessons.save_plan(db, lesson, row.base_plan_version, LessonPlan.model_validate(data))
        resource = {"type": "lesson", "id": lesson.id}
    elif row.operation == "revise" and kind == "plan_revision":
        apply_revision(
            db,
            lesson,
            RevisionScope.model_validate(row.input_snapshot["scope"]),
            PlanRevision.model_validate(data),
        )
        resource = {"type": "lesson", "id": lesson.id}
    elif row.operation == "adjust" and kind == "adjustment":
        apply_adjustment(
            db,
            lesson,
            row.id,
            AdjustParams.model_validate(row.params),
            AdjustmentProposal.model_validate(data),
        )
        resource = {"type": "lesson", "id": lesson.id}
    elif row.operation == "report" and kind == "report":
        report = save_agent_draft(db, lesson, row.id, ReportDraft.model_validate(data))
        resource = {"type": "report", "id": report.id}
    else:
        raise BusinessError(422, "INVALID_ARGUMENT", "生成结果与操作类型不一致")
    row.applied_resource = resource
    row.revision += 1
    row.updated_at = datetime.now(UTC)
    db.flush()
    return AppliedResource.model_validate(row.applied_resource)
