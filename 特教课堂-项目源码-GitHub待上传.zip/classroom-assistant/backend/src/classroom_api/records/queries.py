"""Read-only record references used by report validation."""

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import RecordRow


def ids_for_lesson(db: Session, lesson_id: str) -> set[str]:
    return set(
        db.scalars(select(RecordRow.id).where(RecordRow.lesson_id == lesson_id, RecordRow.is_void.is_(False)))
    )
