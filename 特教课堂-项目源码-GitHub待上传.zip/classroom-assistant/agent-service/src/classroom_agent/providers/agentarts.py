"""The AgentArts HTTP boundary; no business storage or provider details escape this module."""

import json
from copy import deepcopy
from uuid import uuid4

import httpx
from classroom_contracts.agent import AgentRequest, AgentResponse
from classroom_contracts.models import Error
from pydantic import ValidationError

from ..settings import Settings

FALLBACK_WORKFLOW_ID = "6a359afa-6326-4b10-85ac-dfb4aa3badf5"


class AgentArtsRunError(ValueError):
    """The platform returned a workflow error event."""


def _restore_task_citation_lists(payload: dict) -> dict:
    """Restore omitted empty citation lists only; never infer an adopted source."""
    payload = deepcopy(payload)
    result = payload.get("result")
    if not isinstance(result, dict) or not isinstance(result.get("data"), dict):
        return payload
    data = result["data"]
    activities = []
    tasks = []
    if result.get("kind") == "plan":
        activities = data.get("activities", [])
    elif result.get("kind") in ("adjustment", "plan_revision"):
        updates = data.get("task_updates", [])
        if isinstance(updates, list):
            tasks = [update.get("replacement") for update in updates if isinstance(update, dict)]
        future = data.get("future_activity_replacement")
        if result.get("kind") == "adjustment" and isinstance(future, dict):
            activities = future.get("activities", [])
    if isinstance(activities, list):
        for activity in activities:
            if isinstance(activity, dict) and isinstance(activity.get("tasks"), list):
                tasks.extend(activity["tasks"])
    for task in tasks:
        if isinstance(task, dict):
            task.setdefault("knowledge_refs", [])
    return payload


def decode_response(payload: object) -> AgentResponse:
    """Read a DTO or the platform's named workflow output containing its JSON text."""
    if isinstance(payload, str):
        payload = json.loads(payload)
    if not isinstance(payload, dict):
        raise ValueError("AgentArts没有返回对象")
    if "contract_version" in payload and "request_id" in payload:
        # Both model output and platform serialization can omit empty citation lists.
        payload = _restore_task_citation_lists(payload)
        return AgentResponse.model_validate({"questions": [], "result": None, "error": None, **payload})
    for key in ("outputs", "output", "data", "result", "response_content", "answer", "content"):
        if key in payload:
            try:
                return decode_response(payload[key])
            except (ValueError, TypeError):
                continue
    raise ValueError("AgentArts返回体缺少AgentResponse结果")


def decode_event_stream(text: str, expected_workflow_id: str | None = None) -> AgentResponse:
    """Use the completed workflow answer, not intermediate message fragments."""
    answer = None
    finished = False
    workflows = set()
    for block in text.replace("\r\n", "\n").split("\n\n"):
        data = "\n".join(line[5:].lstrip() for line in block.splitlines() if line.startswith("data:"))
        if not data:
            continue
        event = json.loads(data)
        kind = event.get("event")
        if kind == "error":
            raise AgentArtsRunError("AgentArts运行失败")
        if kind == "workflow_start":
            workflows.add(event.get("data", {}).get("workflow_id"))
        if kind == "workflow_end":
            answer = event["data"]["answer"]
        if kind == "end":
            finished = True
    if not finished or answer is None:
        raise ValueError("AgentArts没有返回完整的工作流结果")
    if expected_workflow_id and expected_workflow_id not in workflows:
        raise ValueError("AgentArts未执行指定的备用备课工作流")
    return decode_response(answer)


class AgentArtsProvider:
    def __init__(self, settings: Settings):
        self.settings = settings

    async def generate(self, request: AgentRequest) -> AgentResponse:
        def failed(code: str, message: str):
            return AgentResponse(
                contract_version="1.0",
                request_id=request.request_id,
                status="failed",
                questions=[],
                result=None,
                error=Error(code=code, message=message, fields=[]),
            )

        if not self.settings.configured:
            return failed(
                "AGENT_NOT_CONFIGURED", "真实Agent尚未部署或未配置调用地址与凭证，请先完成AgentArts部署"
            )
        if request.operation == "prepare":
            request = request.model_copy(deep=True)
            request.params.teacher_request += (
                "\n课堂业务规则：落实教师选择的知识板块和教学方式，不统一生成动作训练。"
                "可用材料为空时仍可生成，优先安排无需专门器材的活动，不强制补问材料。"
                "默认recording_unit=task，提供完整任务详细说明，不对每个动作自动拆分。"
                "培智教材只能依据已提供或可核验的内容，不编造课文、页码和引用。"
            )
        try:
            async with httpx.AsyncClient(timeout=self.settings.agentarts_timeout_sec) as client:
                async def invoke(fallback: bool = False) -> AgentResponse:
                    payload = request.model_dump(mode="json")
                    if fallback:
                        payload["knowledge_fallback"] = True
                    response = await client.post(
                        self.settings.agentarts_invoke_url,
                        headers={
                            "Authorization": f"Bearer {self.settings.agentarts_api_key}",
                            "x-hw-agentarts-session-id": str(uuid4()),
                            "X-Request-Id": request.request_id,
                            "X-Invoke-Mode": "published",
                        },
                        json={"query": json.dumps(payload, ensure_ascii=False)},
                    )
                    response.raise_for_status()
                    if "text/event-stream" in response.headers.get("content-type", ""):
                        return decode_event_stream(response.text, FALLBACK_WORKFLOW_ID if fallback else None)
                    if fallback:
                        raise ValueError("备用工作流缺少执行标识")
                    return decode_response(response.json())

                try:
                    result = await invoke()
                except (AgentArtsRunError, httpx.HTTPStatusError):
                    if request.operation != "prepare":
                        raise
                    result = await invoke(fallback=True)
                    fallback_used = True
                else:
                    fallback_used = False
                    if request.operation == "prepare" and result.status == "failed" and result.error:
                        result = await invoke(fallback=True)
                        fallback_used = True
                if result.request_id != request.request_id:
                    raise ValueError("request_id不匹配")
                expected = {
                    "prepare": "plan",
                    "adjust": "adjustment",
                    "report": "report",
                    "revise": "plan_revision",
                }
                if result.status == "succeeded" and result.result.kind != expected[request.operation]:
                    raise ValueError("响应结果类型与请求不匹配")
                if fallback_used and result.status == "succeeded":
                    plan = result.result.data
                    plan.references = []
                    for activity in plan.activities:
                        for task in activity.tasks:
                            task.knowledge_refs = []
                return result
        except httpx.TimeoutException:
            return failed("AGENT_TIMEOUT", "AgentArts响应超时，请稍后重新生成")
        except httpx.HTTPStatusError as exc:
            return failed(
                "AGENT_HTTP_ERROR",
                f"AgentArts调用失败（HTTP {exc.response.status_code}），请检查实例、模型余额和调用凭证",
            )
        except httpx.HTTPError:
            return failed("AGENT_UNAVAILABLE", "无法连接AgentArts，请检查调用地址及网络")
        except (ValidationError, ValueError, TypeError):
            return failed(
                "AGENT_OUTPUT_INVALID", "AgentArts未返回约定的完整JSON结果，请检查已部署版本与输出配置"
            )
