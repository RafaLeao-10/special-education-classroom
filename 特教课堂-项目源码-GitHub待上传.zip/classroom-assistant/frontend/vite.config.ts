import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import { VitePWA } from "vite-plugin-pwa";
import { fileURLToPath } from "node:url";

export default defineConfig({
  plugins: [
    vue(),
    VitePWA({
      // 新版本发布后自动更新；开发模式不启用（避免干扰热更新调试）
      registerType: "autoUpdate",
      devOptions: { enabled: false },
      manifest: {
        name: "特教课堂辅助平台",
        short_name: "特教课堂",
        description: "特教课堂辅助平台教师工作台",
        start_url: "/",
        display: "standalone",
        background_color: "#fcfcf9",
        theme_color: "#466454",
        icons: [
          { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
          {
            src: "/icons/icon-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "maskable",
          },
        ],
      },
      workbox: {
        // 预缓存构建产物：壳（页面骨架与样式脚本）
        globPatterns: ["**/*.{js,css,html,svg,png,woff2}"],
        navigateFallback: "/index.html",
        // 数据一律只走网络，绝不缓存
        runtimeCaching: [
          { urlPattern: /^\/api\//, handler: "NetworkOnly" },
        ],
      },
    }),
  ],
  envDir: fileURLToPath(new URL("..", import.meta.url)),
  server: {
    port: 5173,
    strictPort: true,
    proxy: { "/api": "http://127.0.0.1:8000" },
  },
});