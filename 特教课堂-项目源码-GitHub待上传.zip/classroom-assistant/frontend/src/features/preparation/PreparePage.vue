<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { classroomApi } from "../../api/services/classroom";
import { ElMessage } from "element-plus";
import {
  lessonsApi,
  type Lesson,
  type LessonInput,
  type LessonPlan,
} from "../../api/services/lessons";
import { studentsApi, type Student } from "../../api/services/students";
import LessonConditions from "../lessons/LessonConditions.vue";
import SourceReports from "../reports/SourceReports.vue";
import { newPlan } from "./planDraft";
import PlanEditor from "./PlanEditor.vue";
import PlanRevisionPanel from "./PlanRevisionPanel.vue";
import CloneLessonDialog from "../lessons/CloneLessonDialog.vue";
import PlanPreview from "./PlanPreview.vue";
import { useAiJob } from "../ai/useAiJob";
import JobStatus from "../ai/JobStatus.vue";
import TrainingPreferences from "./TrainingPreferences.vue";
import { knowledgeAreas, preparationRequest } from "./trainingMethods";
import { nodePrepareInfo } from "../knowledge-graph/nodeMethodMap";
import AppIcon from "../../components/AppIcon.vue";
import { clearDraft, readDraft, writeDraft } from "../../app/drafts";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

const route = useRoute();
const router = useRouter();
const id = String(route.params.id);
type PreparationStage = "choose" | "existing" | "agent" | "manual" | "preview";
const stage = ref<PreparationStage>(route.query.mode === "existing" ? "existing" : "choose");
const candidatePlan = ref<LessonPlan>();
const candidateEditing = ref(false);
const candidateBaseline = ref("");
const previewSource = ref<"saved" | "candidate">("saved");
const previewReturn = ref<"manual" | "agent" | "choose">("choose");
const lesson = ref<Lesson>();
const students = ref<Student[]>([]);
const conditions = ref<LessonInput>();
const editPlan = ref<LessonPlan>();
const teacherRequest = ref("");
const areas = ref<string[]>([]);
const textbook = ref("");
const methods = ref<string[]>([]);
const supports = ref<string[]>([]);
const busy = ref(false);
const planBaseline = ref("null");
const editorMode = ref<"preview" | "edit">("preview");
const scope = `preparation:${id}`;
type PlanDraft = {
  version: number;
  conditions: LessonInput;
  plan?: LessonPlan;
  mode: "preview" | "edit";
};
const recovery = ref<PlanDraft | null>(null);
const pageError = ref("");
let loadingDraft = false;
const preferences = readDraft<{
  request: string;
  areas?: string[];
  textbook?: string;
  methods: string[];
  supports: string[];
}>(`preferences:${id}`);
teacherRequest.value = preferences?.request || "";
areas.value = preferences?.areas || [];
textbook.value = preferences?.textbook || "";
methods.value = preferences?.methods || [];
supports.value = preferences?.supports || [];
// 图谱"用于备课"跳转：合并 method/node query 参数（去重，防止刷新重复拼接）
const routeQuery = useRoute().query;
const qMethod = routeQuery.method;
if (typeof qMethod === "string") {
  for (const m of qMethod.split(",")) {
    if (m && !methods.value.includes(m)) methods.value.push(m);
  }
}
const qNode = routeQuery.node;
if (typeof qNode === "string") {
  const info = nodePrepareInfo(qNode);
  if (info.note && !teacherRequest.value.includes(info.note)) {
    teacherRequest.value = teacherRequest.value
      ? `${teacherRequest.value}\n${info.note}`
      : info.note;
  }
}
watch(
  [teacherRequest, methods, supports, areas, textbook],
  () =>
    writeDraft(`preferences:${id}`, {
      request: teacherRequest.value,
      areas: areas.value,
      textbook: textbook.value,
      methods: methods.value,
      supports: supports.value,
    }),
  { deep: true },
);
const dirty = computed(
  () => JSON.stringify(editPlan.value || null) !== planBaseline.value,
);
function startManual() {
  if (!editPlan.value) editPlan.value = newPlan(lesson.value!, students.value);
  editorMode.value = "edit";
  stage.value = "manual";
}
function showSavedPreview() { previewSource.value = "saved"; previewReturn.value = stage.value === "manual" ? "manual" : "choose"; editorMode.value = "preview"; stage.value = "preview"; }
function showCandidate() {
  if (job.value?.result?.kind !== "plan") return;
  candidatePlan.value = JSON.parse(JSON.stringify(job.value.result.data));
  candidateBaseline.value = JSON.stringify(candidatePlan.value);
  candidateEditing.value = false;
  previewSource.value = "candidate";
  previewReturn.value = "agent";
  stage.value = "preview";
}
const editable = computed(
  () => !!lesson.value && ["draft", "ready"].includes(lesson.value.status),
);
const conditionBaseline = ref("");
const conditionsDirty = computed(
  () =>
    !!conditions.value &&
    JSON.stringify(conditions.value) !== conditionBaseline.value,
);
import { useUnsavedChanges } from "../../app/useUnsavedChanges";
useUnsavedChanges(computed(() => dirty.value || conditionsDirty.value));
watch(
  [conditions, editPlan, editorMode],
  () => {
    if (loadingDraft || !lesson.value || !conditions.value || recovery.value)
      return;
    if (dirty.value || conditionsDirty.value)
      writeDraft(scope, {
        version: lesson.value.plan_version,
        conditions: conditions.value,
        plan: editPlan.value,
        mode: editorMode.value,
      });
    else clearDraft(scope);
  },
  { deep: true, flush: "sync" },
);
function recoverDraft() {
  const value = recovery.value;
  if (!value) return;
  loadingDraft = true;
  conditions.value = value.conditions;
  editPlan.value = value.plan;
  editorMode.value = value.mode;
  recovery.value = null;
  loadingDraft = false;
  writeDraft(scope, { ...value, version: lesson.value!.plan_version });
}
async function reload() {
  clearDraft(scope);
  recovery.value = null;
  await action(load);
}
const {
  job,
  error,
  running,
  available,
  serviceMessage,
  hasPending,
  retry,
  generate,
  resume,
  restore,
  apply,
  poll,
} = useAiJob(id);
async function load() {
  const data = await lessonsApi.get(id);
  loadingDraft = true;
  pageError.value = "";
  lesson.value = data;
  if (route.query.mode !== "choose" && data.plan && stage.value === "choose") stage.value = "existing";
  conditions.value = {
    title: data.title,
    student_ids: [...data.student_ids],
    planned_duration_min: data.planned_duration_min,
    available_materials: data.available_materials.map((m) => ({ ...m })),
    previous_report_ids: [...data.previous_report_ids],
  };
  editPlan.value = data.plan
    ? JSON.parse(JSON.stringify(data.plan))
    : undefined;
  planBaseline.value = JSON.stringify(editPlan.value || null);
  conditionBaseline.value = JSON.stringify(conditions.value);
  recovery.value = editable.value ? readDraft<PlanDraft>(scope) : null;
  loadingDraft = false;
  if (recovery.value?.version === data.plan_version) recoverDraft();
}
async function action(work: () => Promise<void>) {
  if (busy.value) return;
  busy.value = true;
  pageError.value = "";
  try {
    await work();
  } catch (e) {
    pageError.value = (e as Error).message;
    ElMessage.error((e as Error).message);
  } finally {
    busy.value = false;
  }
}
async function saveConditions() {
  if (!lesson.value || !conditions.value) return;
  await action(async () => {
    const saveBoth = dirty.value && !!editPlan.value;
    await lessonsApi.update(id, {
      ...conditions.value,
      expected_plan_version: lesson.value!.plan_version,
      ...(saveBoth ? { plan: editPlan.value } : {}),
    });
    clearDraft(scope);
    await load();
    ElMessage.success(saveBoth ? "备课条件和教案已保存" : "备课条件已保存");
  });
}
async function adopt() {
  await action(async () => {
    if (!candidatePlan.value) throw new Error("没有可采用的候选教案");
    const candidate = JSON.parse(JSON.stringify(candidatePlan.value)) as LessonPlan;
    const changed = JSON.stringify(candidate) !== candidateBaseline.value;
    const applied = await apply();
    if (!applied) throw new Error("候选教案尚未采用，请重试");
    clearDraft(scope);
    await load();
    if (changed) {
      editPlan.value = candidate;
      await lessonsApi.savePlan(id, lesson.value!.plan_version, candidate);
      clearDraft(scope);
      recovery.value = null;
      await load();
    }
    previewSource.value = "saved";
    stage.value = "preview";
    ElMessage.success("教案已采用并保存");
  });
}
async function enterClassroom() {
  if (!lesson.value || !editPlan.value) return;
  if (dirty.value || conditionsDirty.value) {
    await savePlan();
    if (dirty.value || conditionsDirty.value || pageError.value) return;
  }
  await action(async () => {
    if (lesson.value!.status === "draft")
      lesson.value = await classroomApi.action(id, { action: "confirm_plan", expected_plan_version: lesson.value!.plan_version });
    if (lesson.value!.status === "ready")
      lesson.value = await classroomApi.action(id, { action: "start", expected_plan_version: lesson.value!.plan_version });
    if (lesson.value!.status !== "in_progress") throw new Error("当前课程不能进入课堂");
    await router.push(`/lessons/${id}/classroom`);
  });
}
async function savePlan() {
  if (!lesson.value || !editPlan.value) return;
  if (conditionsDirty.value) {
    await saveConditions();
    return;
  }
  await action(async () => {
    await lessonsApi.savePlan(id, lesson.value!.plan_version, editPlan.value!);
    clearDraft(scope);
    await load();
    ElMessage.success("教案草稿已保存");
  });
}
async function initialize() {
  await action(async () => {
    students.value = (await studentsApi.list()).items;
    await load();
    await restore();
  });
}
onMounted(initialize);
</script>
<template>
  <template v-if="lesson">
    <p v-if="pageError" class="inline-error" role="alert">{{ pageError }}</p>
    <div v-if="recovery" class="preview-notice">本机有未保存的教案修改，请先选择。
      <ButtonGroup><Button size="sm" variant="ghost" :disabled="busy" @click="recoverDraft">恢复草稿</Button><Button size="sm" variant="quiet" :disabled="busy" @click="reload">放弃本机草稿</Button></ButtonGroup>
    </div>
    <div class="page-title"><div><router-link to="/lessons" class="back-link">← 返回课前规划</router-link><span class="stage-tag stage-sage">课前 · 备课</span><h1>{{ lesson.title }}</h1><p class="subtle">方案版本 {{ lesson.plan_version }}</p></div>
      <ButtonGroup><CloneLessonDialog :lesson="lesson" :disabled="busy || dirty || conditionsDirty" /><Button variant="ghost" :disabled="busy" @click="reload">重新读取</Button></ButtonGroup>
    </div>
    <div class="preparation-flow">
      <section v-if="stage === 'choose'">
        <p class="eyebrow">生成教案</p><h2>选择编写方式</h2><p class="subtle">选择一种方式开始，完成后都可以预览并修改。</p>
        <div class="preparation-choice-grid">
          <button type="button" class="preparation-choice" @click="stage = 'agent'"><strong>Agent 生成</strong><span>选择教学内容和方式，生成候选教案</span><b>开始生成 →</b></button>
          <button type="button" class="preparation-choice" @click="startManual"><strong>手动编写</strong><span>自己添加教学活动，可选择让 Agent 扩展</span><b>开始编写 →</b></button>
        </div>
        <Button v-if="editPlan" variant="ghost" @click="stage = 'existing'">查看已保存教案</Button>
      </section>
      <template v-else-if="stage === 'agent'">
        <Button variant="ghost" size="sm" @click="stage = 'choose'">← 返回编写方式</Button>
        <section><p class="eyebrow">Agent 生成</p><h2>这堂课，想教什么？</h2><p class="subtle">选择知识板块和教学方式，再补充需要的支持。</p>
          <div class="method-grid"><label v-for="area in knowledgeAreas" :key="area.id" :class="['method-card', { 'is-selected': areas.includes(area.id) }]"><input v-model="areas" type="checkbox" :value="area.id" /><span><strong>{{ area.title }}</strong><small>{{ area.description }}</small></span></label></div>
          <h3>教学方式（可多选）</h3><TrainingPreferences v-model="methods" />
          <h3>希望提供的支持</h3><el-checkbox-group v-model="supports"><el-checkbox value="视觉步骤提示">视觉步骤提示</el-checkbox><el-checkbox value="短句指令">短句指令</el-checkbox><el-checkbox value="示范支持">示范支持</el-checkbox><el-checkbox value="沟通板">沟通板</el-checkbox></el-checkbox-group>
          <h3>培智教材参考（可选）</h3><el-input v-model="textbook" placeholder="教材名称、年级、单元或课题" />
          <h3>课堂具体描述（可选）</h3><el-input v-model="teacherRequest" type="textarea" :rows="4" placeholder="描述课程主题、教学目标或课堂安排" />
          <Button variant="primary" :loading="running" :disabled="busy || !!recovery || dirty || conditionsDirty || !areas.length || !available || lesson.status !== 'draft'" @click="generate(preparationRequest(methods, supports, teacherRequest, areas, textbook))">生成候选教案</Button>
          <p class="subtle">{{ serviceMessage }}</p><JobStatus :job="job" :running="running" :error="error" :pending="hasPending" hide-classroom-link @retry="retry" @resume="resume" @poll="poll" />
          <Button v-if="job?.result?.kind === 'plan' && !job.applied_resource" variant="primary" @click="showCandidate">查看并编辑候选教案 →</Button>
        </section>
      </template>
      <template v-else-if="stage === 'manual'">
        <Button variant="ghost" size="sm" @click="stage = 'choose'">← 返回编写方式</Button>
        <section><p class="eyebrow">手动编写</p><h2>编写教学活动</h2><p class="subtle">添加活动和任务，保存后可选择让 Agent 在已有教案基础上扩展。</p>
          <PlanEditor v-if="editPlan" v-model="editPlan" :lesson="lesson" :students="students" />
          <p v-if="dirty" class="subtle">有尚未保存的修改。</p>
          <Button variant="secondary" :loading="busy" :disabled="!!recovery || !dirty || !editable" @click="savePlan">保存手写教案</Button>
          <Button v-if="editPlan" variant="primary" :disabled="!!recovery" @click="showSavedPreview">预览教案 →</Button>
        </section>
        <PlanRevisionPanel v-if="lesson.plan && editable" :lesson="lesson" :disabled="busy || running || dirty || conditionsDirty || !!recovery" @adopted="action(load)" />
      </template>
      <template v-else-if="stage === 'existing' || stage === 'preview'">
        <Button variant="ghost" size="sm" @click="stage = stage === 'existing' ? 'choose' : previewReturn">← 返回</Button>
        <section v-if="previewSource === 'candidate' && stage === 'preview' && candidatePlan">
          <p class="eyebrow">候选教案</p><h2>预览并修改教案</h2><p class="subtle">这是一份候选，确认采用后才会替换当前已保存教案。</p>
          <ButtonGroup><Button variant="secondary" @click="candidateEditing = false">预览</Button><Button variant="secondary" @click="candidateEditing = true">鼠标键盘编辑</Button></ButtonGroup>
          <PlanEditor v-if="candidateEditing" v-model="candidatePlan" :lesson="lesson" :students="students" /><PlanPreview v-else :plan="candidatePlan" :students="students" />
          <Button variant="primary" :loading="busy" :disabled="!!recovery || dirty || conditionsDirty || lesson.status !== 'draft'" @click="adopt">采用并保存教案</Button>
        </section>
        <section v-else>
          <p class="eyebrow">{{ stage === 'existing' ? '已有教案' : '教案预览' }}</p><h2>{{ stage === 'existing' ? '已保存的教案' : '预览并修改教案' }}</h2>
          <p class="subtle">确认教案后进入课堂，课堂任务以保存的教案为准。</p>
          <template v-if="editPlan">
            <ButtonGroup><Button variant="secondary" @click="editorMode = 'preview'">预览教案</Button><Button v-if="editable" variant="secondary" @click="editorMode = 'edit'">鼠标键盘编辑</Button><Button :to="`/lessons/${id}/print`" variant="ghost" size="sm">打印教案</Button></ButtonGroup>
            <PlanEditor v-if="editorMode === 'edit' && editable" v-model="editPlan" :lesson="lesson" :students="students" /><PlanPreview v-else :plan="editPlan" :students="lesson.student_snapshots?.length && !dirty ? lesson.student_snapshots : students" />
            <p v-if="dirty" class="subtle">有尚未保存的教案修改。</p>
            <Button v-if="editable" variant="secondary" :loading="busy" :disabled="!!recovery || !dirty" @click="savePlan">保存教案修改</Button>
            <Button variant="primary" :loading="busy" :disabled="!!recovery || running || !editable" @click="enterClassroom">确认教案并进入课堂 →</Button>
            <Button v-if="lesson.status === 'in_progress'" :to="`/lessons/${id}/classroom`" variant="primary">返回课堂 →</Button>
          </template>
          <div v-else><el-empty description="这门课还没有保存教案" /><Button variant="secondary" @click="stage = 'choose'">选择生成方式</Button></div>
        </section>
      </template>
    </div>
  </template>
  <el-empty v-else :description="pageError || '正在读取课程…'"><Button v-if="pageError" variant="secondary" :loading="busy" @click="initialize">重新读取课程</Button></el-empty>
</template>

<style scoped>
.preparation-flow { max-width: 1020px; margin: 0 auto; }
.preparation-flow > .button-link { margin-bottom: 16px; }
.preparation-flow section { margin-top: 18px; }
.preparation-flow h3 { margin-top: 28px; }
.preparation-choice-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
.preparation-choice { display:flex; flex-direction:column; align-items:flex-start; gap:12px; padding:28px; text-align:left; border:1px solid var(--line); border-radius:14px; background:#f9fbf7; color:var(--ink); }
.preparation-choice strong { font-size:19px; } .preparation-choice span { color:var(--muted); } .preparation-choice b { color:var(--green); }
@media (max-width:760px) { .preparation-choice-grid { grid-template-columns:1fr; } }
</style>
