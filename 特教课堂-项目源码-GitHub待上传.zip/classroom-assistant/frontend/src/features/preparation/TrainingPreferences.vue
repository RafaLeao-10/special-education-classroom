<script setup lang="ts">
import { trainingMethods } from "./trainingMethods";
const selected = defineModel<string[]>({ required: true });
</script>
<template>
  <div class="method-grid">
    <label
      v-for="method in trainingMethods"
      :key="method.id"
      :class="['method-card', { 'is-selected': selected.includes(method.id) }]"
      ><input v-model="selected" type="checkbox" :value="method.id" /><span
        ><strong>{{ method.title }}</strong
        ><small>{{ method.description }}</small></span
      ></label
    >
  </div>
</template>
