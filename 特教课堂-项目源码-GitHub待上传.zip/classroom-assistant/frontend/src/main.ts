import { createApp } from "vue";
import ElementPlus from "element-plus";
import "element-plus/dist/index.css";
import App from "./app/App.vue";
import { router } from "./app/router";
import { clickBlur } from "./app/clickBlur";
import "./styles/base.css";

createApp(App)
.use(router)
.use(ElementPlus)
.directive("click-blur", clickBlur)
.mount("#app");