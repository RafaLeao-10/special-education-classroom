"""Plan versions used by classroom records, independent of later plan edits."""

from classroom_api.errors import BusinessError
from classroom_api.students.service import get_many
from classroom_contracts.models import LessonPlan
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import LessonRow, PlanSnapshotRow


def save_snapshot(db: Session, lesson: LessonRow):
    if lesson.plan is not None and db.get(PlanSnapshotRow, (lesson.id, lesson.plan_version)) is None:
        people = (
            lesson.student_snapshots
            if lesson.status in ("in_progress", "completed") and lesson.student_snapshots
            else [s.model_dump(mode="json") for s in get_many(db, lesson.student_ids)]
        )
        lesson.student_snapshots = people
        lesson.snapshot_origin = "captured"
        db.add(
            PlanSnapshotRow(
                lesson_id=lesson.id,
                plan_version=lesson.plan_version,
                plan=lesson.plan,
                student_snapshots=people,
                snapshot_origin="captured",
            )
        )
        db.flush()


def get_plan(db: Session, lesson_id: str, version: int) -> LessonPlan:
    row = db.get(PlanSnapshotRow, (lesson_id, version))
    if row is None:
        raise BusinessError(422, "INVALID_ARGUMENT", "记录引用的方案版本不存在", ["task_plan_version"])
    return LessonPlan.model_validate(row.plan)


def snapshots(db: Session, lesson_id: str):
    return list(
        db.scalars(
            select(PlanSnapshotRow)
            .where(PlanSnapshotRow.lesson_id == lesson_id)
            .order_by(PlanSnapshotRow.plan_version)
        )
    )
