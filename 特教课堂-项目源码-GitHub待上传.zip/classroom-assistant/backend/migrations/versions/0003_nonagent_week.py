"""Historical participants and local teaching assets."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "0003_nonagent_week"
down_revision = "0002_classroom"
branch_labels = depends_on = None


def upgrade():
    for table in ("lessons", "plan_snapshots"):
        op.add_column(table, sa.Column("student_snapshots", JSONB, nullable=False, server_default="[]"))
        op.add_column(
            table, sa.Column("snapshot_origin", sa.String(20), nullable=False, server_default="none")
        )
    op.add_column("lessons", sa.Column("display_token", sa.String(80), nullable=True))
    op.create_unique_constraint("uq_lesson_display_token", "lessons", ["display_token"])
    # Old descriptions cannot be recovered. Mark this migration-time baseline honestly.
    op.execute("""UPDATE lessons l SET student_snapshots=(
        SELECT coalesce(jsonb_agg(jsonb_build_object('id',s.id,'name',s.name,'revision',s.revision)||s.details ORDER BY s.id),'[]'::jsonb)
        FROM students s WHERE l.student_ids ? s.id), snapshot_origin='migration' WHERE plan IS NOT NULL""")
    op.execute("""UPDATE plan_snapshots p SET student_snapshots=l.student_snapshots, snapshot_origin='migration'
        FROM lessons l WHERE l.id=p.lesson_id""")
    op.create_table(
        "assets",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("mime_type", sa.String(100), nullable=False),
        sa.Column("alt", sa.Text(), nullable=False),
        sa.Column("storage_name", sa.String(80), nullable=False),
    )


def downgrade():
    op.drop_table("assets")
    op.drop_constraint("uq_lesson_display_token", "lessons", type_="unique")
    op.drop_column("lessons", "display_token")
    for table in ("plan_snapshots", "lessons"):
        op.drop_column(table, "snapshot_origin")
        op.drop_column(table, "student_snapshots")
