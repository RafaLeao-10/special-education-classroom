import re
from pathlib import Path
from uuid import uuid4

from classroom_contracts.models import Asset

from classroom_api.errors import BusinessError

from .models import AssetRow
from .presentation import convert

IMAGE_TYPES = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif"}

PRESENTATION_TYPES = {
    ".ppt": "application/vnd.ms-powerpoint",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".pdf": "application/pdf",
}


def get(db, id, *, owner_id=None):
    row = db.get(AssetRow, id)
    if row is None or (owner_id is not None and row.owner_id != owner_id):
        raise BusinessError(404, "NOT_FOUND", "素材不存在")
    return row


def slide_files(folder, storage_name):
    directory = folder / (Path(storage_name).stem + "-slides")
    return sorted(
        (p for p in directory.glob("*") if p.suffix.lower() == ".png"),
        key=lambda p: int(re.search(r"(\d+)$", p.stem).group(1)),
    )


def to_dto(row, token=None, folder=None):
    suffix = f"?display_token={token}" if token else ""
    return Asset(
        id=row.id,
        preview_pages=[
            f"/api/v1/assets/{row.id}/content?page={index}"
            for index, _ in enumerate(slide_files(folder, row.storage_name), 1)
        ] if folder is not None and row.mime_type not in IMAGE_TYPES else [],
        kind="image" if row.mime_type in IMAGE_TYPES else "file",
        preview_url=f"/api/v1/assets/{row.id}/content?preview=true" if row.mime_type not in IMAGE_TYPES else None,
        name=row.name,
        alt=row.alt,
        mime_type=row.mime_type,
        url=f"/api/v1/assets/{row.id}/content{suffix}",
        expires_at=None,
    )


def store(db, folder, name, mime_type, alt, data, owner_id):
    extension = Path(name).suffix.lower()
    is_presentation = extension in PRESENTATION_TYPES
    if (mime_type not in IMAGE_TYPES and not is_presentation) or not data:
        raise BusinessError(422, "INVALID_ARGUMENT", "请选择教学图片、PPT、PPTX或PDF课件")
    if is_presentation:
        mime_type = PRESENTATION_TYPES[extension]
    id = str(uuid4())
    folder.mkdir(parents=True, exist_ok=True)
    storage_name = id + (extension if is_presentation else IMAGE_TYPES[mime_type])
    path = folder / storage_name
    path.write_bytes(data)
    if is_presentation and extension != ".pdf":
        try:
            convert(path)
        except BusinessError:
            path.unlink(missing_ok=True)
            raise
    row = AssetRow(
        id=id, owner_id=owner_id, name=name[:255], mime_type=mime_type, alt=alt, storage_name=storage_name
    )
    db.add(row)
    db.flush()
    return to_dto(row, folder=folder)
