from classroom_api.errors import BusinessError
from classroom_api.lessons.adjustments import listing as list_adjustments
from classroom_api.lessons.history import snapshots
from classroom_api.lessons.revisions import scope_for
from classroom_api.records.service import listing as list_records
from classroom_api.reports.queries import get_previous, validate_previous
from classroom_api.reports.service import to_dto as report_dto
from classroom_api.students.service import get_many
from classroom_contracts.agent import AdjustRequest, PrepareRequest, ReportRequest, ReviseRequest
from classroom_contracts.http import AgentJobCreate, JobCreate
from classroom_contracts.models import Lesson, PlanSnapshot, Student
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import JobRow


def build_context(db: Session, job_id: str, lesson: Lesson, body: AgentJobCreate, answers=()):
    if body.operation == "prepare":
        validate_previous(db, lesson.previous_report_ids, lesson.student_ids)
    people = (
        [Student.model_validate(s) for s in lesson.student_snapshots]
        if lesson.status in ("in_progress", "completed") and lesson.student_snapshots
        else get_many(db, lesson.student_ids)
    )
    request_type = {
        "prepare": PrepareRequest,
        "adjust": AdjustRequest,
        "report": ReportRequest,
        "revise": ReviseRequest,
    }[body.operation]
    extra = {}
    if body.operation == "revise":
        if lesson.plan is None:
            raise BusinessError(409, "INVALID_STATE", "请先保存需要同步的教案")
        previous = db.scalar(
            select(JobRow)
            .where(
                JobRow.lesson_id == lesson.id,
                JobRow.operation.in_(("prepare", "revise")),
                JobRow.applied_resource["type"].astext == "lesson",
            )
            .order_by(JobRow.updated_at.desc())
            .limit(1)
        )
        baseline = next(
            (
                r
                for r in snapshots(db, lesson.id)
                if previous and r.plan_version == previous.base_plan_version + 1
            ),
            None,
        )
        typed_baseline = (
            PlanSnapshot.model_validate(
                {
                    "plan_version": baseline.plan_version,
                    "plan": baseline.plan,
                    "student_snapshots": baseline.student_snapshots,
                    "snapshot_origin": baseline.snapshot_origin,
                }
            )
            if baseline
            else None
        )
        scope = scope_for(
            lesson,
            people,
            typed_baseline,
            previous.input_snapshot if previous else {},
            previous.input_snapshot.get("scope", {}).get("protected_step_ids", []) if previous else (),
        )
        if not scope.affected_task_ids and not scope.affected_resource_ids:
            raise BusinessError(409, "NO_REVISION_NEEDED", "当前教案没有待同步的修改")
        extra["scope"] = scope
    return request_type(
        **extra,
        contract_version="1.0",
        request_id=job_id,
        operation=body.operation,
        lesson=lesson,
        students=people,
        records=list_records(db, lesson.id),
        plan_snapshots=[
            PlanSnapshot.model_validate(
                {
                    "plan_version": row.plan_version,
                    "plan": row.plan,
                    "student_snapshots": row.student_snapshots,
                    "snapshot_origin": row.snapshot_origin,
                }
            )
            for row in snapshots(db, lesson.id)
        ],
        adjustments=list_adjustments(db, lesson.id),
        previous_reports=[report_dto(db, row) for row in get_previous(db, lesson.previous_report_ids)],
        params=body.params,
        answers=list(answers),
    )


def prepare_context(db: Session, job_id: str, lesson: Lesson, body: JobCreate) -> PrepareRequest:
    return build_context(db, job_id, lesson, body)
