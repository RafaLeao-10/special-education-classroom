"""The single implementation of the seven-count convention."""

from classroom_contracts.models import Counts, StatisticsRow


def summarize(records):
    buckets = {}
    for record in records:
        if record.is_void or record.kind != "observation":
            continue
        key = (
            record.subject.type,
            record.subject.id,
            record.task_id,
            record.step_id or "",
            record.task_plan_version,
        )
        if key not in buckets:
            buckets[key] = StatisticsRow(
                subject=record.subject,
                task_id=record.task_id,
                step_id=record.step_id,
                task_plan_version=record.task_plan_version,
                counts=Counts(**dict.fromkeys(Counts.model_fields, 0)),
                known_outcome_count=0,
                completed_count=0,
                record_ids=[],
            )
        row = buckets[key]
        row.counts = Counts(
            **{name: getattr(row.counts, name) + getattr(record.counts, name) for name in Counts.model_fields}
        )
        row.record_ids.append(record.id)
    for row in buckets.values():
        c = row.counts
        row.completed_count = c.independent + c.prompted + c.completed_unknown_prompt
        row.known_outcome_count = row.completed_count + c.not_completed
        row.record_ids.sort()
    return [buckets[key] for key in sorted(buckets)]
