import httpx
from classroom_api.auth.access import require_job, require_lesson
from classroom_api.auth.service import require_user
from classroom_api.db import get_db
from classroom_api.lessons.service import get as get_lesson
from classroom_contracts.http import (
    AgentJobCreate,
    AgentStatus,
    AiJob,
    AppliedData,
    Empty,
    Envelope,
    Items,
    JobSummary,
)
from classroom_contracts.models import AdjustmentLog
from classroom_contracts.planned import JobResume, JobRetry
from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import service
from .apply import apply_result
from .models import JobRow

router = APIRouter(tags=["ai-jobs"], dependencies=[Depends(require_user)])


@router.post(
    "/lessons/{id}/ai-jobs",
    status_code=202,
    response_model=Envelope[AiJob],
    dependencies=[Depends(require_lesson)],
)
def create(id: str, body: AgentJobCreate, db: Session = Depends(get_db)):
    return Envelope(data=service.create(db, id, body))


@router.post(
    "/ai-jobs/{job_id}/resume",
    status_code=202,
    response_model=Envelope[AiJob],
    dependencies=[Depends(require_job)],
)
def resume(job_id: str, body: JobResume, db: Session = Depends(get_db), user=Depends(require_user)):
    return Envelope(data=service.resume(db, job_id, body, user.id))


@router.post(
    "/ai-jobs/{job_id}/retry",
    status_code=202,
    response_model=Envelope[AiJob],
    dependencies=[Depends(require_job)],
)
def retry(job_id: str, body: JobRetry, db: Session = Depends(get_db)):
    return Envelope(data=service.retry(db, job_id, body))


@router.get(
    "/lessons/{id}/adjustments",
    response_model=Envelope[Items[AdjustmentLog]],
    dependencies=[Depends(require_lesson)],
)
def adjustments(id: str, db: Session = Depends(get_db)):
    from classroom_api.lessons.adjustments import listing

    get_lesson(db, id)
    return Envelope(data=Items(items=listing(db, id)))


@router.get("/agent-status", response_model=Envelope[AgentStatus])
async def agent_status(request: Request):
    try:
        response = await request.app.state.teaching_client.get("/health", timeout=5)
        response.raise_for_status()
        data = response.json()
        return Envelope(data=AgentStatus(provider=data["provider"], configured=data["configured"]))
    except (httpx.HTTPError, ValueError, KeyError):
        return Envelope(data=AgentStatus(provider="unavailable", configured=False))


@router.get("/ai-jobs/{job_id}", response_model=Envelope[AiJob], dependencies=[Depends(require_job)])
def read(job_id: str, db: Session = Depends(get_db)):
    return Envelope(data=service.to_dto(service.get(db, job_id)))


@router.get(
    "/lessons/{id}/ai-jobs",
    response_model=Envelope[Items[JobSummary]],
    dependencies=[Depends(require_lesson)],
)
def listing(id: str, db: Session = Depends(get_db)):
    get_lesson(db, id)
    rows = db.scalars(
        select(JobRow).where(JobRow.lesson_id == id).order_by(JobRow.updated_at.desc(), JobRow.id)
    )
    return Envelope(
        data=Items(items=[JobSummary.model_validate(service.to_dto(row).model_dump()) for row in rows])
    )


@router.post(
    "/ai-jobs/{job_id}/apply", response_model=Envelope[AppliedData], dependencies=[Depends(require_job)]
)
def apply(job_id: str, body: Empty, db: Session = Depends(get_db)):
    return Envelope(data=AppliedData(applied_resource=apply_result(db, job_id)))
