<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref } from "vue";
import sample from "./graph.sample.json";
import type { KnowledgeGraph, GraphNode } from "./graph.types";
import PrepareFromNodeDialog from "./PrepareFromNodeDialog.vue";
import Button from "../../components/Button.vue";

const graph = sample as KnowledgeGraph;
const query = ref("");
const focusId = ref(graph.nodes[0]?.id || "");
const selected = ref(focusId.value);
const expanded = ref(graph.nodes[0]?.type || "");
const zoom = ref(1);
const viewport = ref<HTMLElement>();
const fit = ref(1);
const graphScale = computed(() => fit.value * zoom.value);
let resizeObserver: ResizeObserver | undefined;
onMounted(() => {
  if (!viewport.value) return;
  resizeObserver = new ResizeObserver(([entry]) => {
    fit.value = Math.min(1, Math.max(.3, (entry.contentRect.width - 4) / 1000));
  });
  resizeObserver.observe(viewport.value);
});
onUnmounted(() => resizeObserver?.disconnect());
const prepareOpen = ref(false);
const categories = computed(() => [...new Set(graph.nodes.map(n => n.type))].map(type => ({
  type,
  nodes: graph.nodes.filter(n => n.type === type && (!query.value.trim() ||
    `${n.label} ${n.summary} ${n.type}`.toLowerCase().includes(query.value.trim().toLowerCase()))),
})).filter(group => group.nodes.length));
const focus = computed(() => graph.nodes.find(n => n.id === focusId.value));
const current = computed(() => graph.nodes.find(n => n.id === selected.value));
const focusEdges = computed(() => graph.edges.filter(e => e.source === focusId.value || e.target === focusId.value));
const neighbors = computed(() => {
  const ids = new Set(focusEdges.value.map(e => e.source === focusId.value ? e.target : e.source));
  return graph.nodes.filter(n => ids.has(n.id));
});
const displayed = computed(() => focus.value ? [focus.value, ...neighbors.value] : []);
const positions = computed(() => {
  const result = new Map<string, { x: number; y: number }>();
  if (!focus.value) return result;
  result.set(focus.value.id, { x: 500, y: 310 });
  neighbors.value.forEach((node, i) => {
    const angle = -Math.PI / 2 + 2 * Math.PI * i / neighbors.value.length;
    result.set(node.id, { x: 500 + 355 * Math.cos(angle), y: 310 + 225 * Math.sin(angle) });
  });
  return result;
});
const related = computed(() => graph.edges.filter(e => e.source === selected.value || e.target === selected.value));
function showGraph(node: GraphNode) {
  focusId.value = node.id;
  selected.value = node.id;
  expanded.value = node.type;
  zoom.value = 1;
}
function showRelated(id: string) {
  const node = graph.nodes.find(n => n.id === id);
  if (node) { query.value = ""; showGraph(node); }
}
function changeZoom(delta: number) {
  zoom.value = Math.round(Math.min(2, Math.max(.6, zoom.value + delta)) * 10) / 10;
}
</script>

<template>
  <div class="page-title">
    <div>
      <router-link to="/" class="back-link">← 返回工作台</router-link>
      <span class="stage-tag stage-blue">教学 · 知识</span>
      <h1>让教学方法，彼此连接</h1>
      <p class="page-description">选择左侧分类与方法，浏览相关知识，点击节点后在下方查看详情。</p>
    </div>
  </div>
  <div class="knowledge-workspace">
    <aside class="knowledge-navigation" aria-label="知识图谱分类">
      <div class="nav-title"><p class="eyebrow">知识目录</p><h2>选择教学方法</h2></div>
      <el-input v-model="query" clearable placeholder="搜索方法或关键词" aria-label="搜索知识图谱" />
      <p v-if="!categories.length" class="subtle">没有找到相关方法。</p>
      <div v-for="group in categories" :key="group.type" class="knowledge-group">
        <button class="group-toggle" type="button" :aria-expanded="expanded === group.type || !!query.trim()" @click="expanded = expanded === group.type ? '' : group.type">
          <span>{{ group.type }} <small>{{ group.nodes.length }}</small></span><span aria-hidden="true">{{ expanded === group.type || query.trim() ? '−' : '+' }}</span>
        </button>
        <div v-show="expanded === group.type || !!query.trim()" class="knowledge-sublist">
          <button v-for="node in group.nodes" :key="node.id" type="button" class="knowledge-subitem" :class="{ active: focusId === node.id }" :aria-pressed="focusId === node.id" @click="showGraph(node)">{{ node.label }}</button>
        </div>
      </div>
    </aside>
    <section class="knowledge-graph-panel" aria-label="知识关系图">
      <div class="graph-header">
        <div><p class="eyebrow">知识关系图</p><h2>{{ focus?.label || '请选择方法' }}</h2><p>以所选方法为中心，展示直接相连的知识。</p></div>
        <div class="zoom-tools" aria-label="图谱缩放">
          <button type="button" aria-label="缩小图谱" :disabled="zoom <= .6" @click="changeZoom(-.1)">−</button>
          <span aria-live="polite">{{ Math.round(zoom * 100) }}%</span>
          <button type="button" aria-label="放大图谱" :disabled="zoom >= 2" @click="changeZoom(.1)">＋</button>
          <button type="button" class="zoom-reset" @click="zoom = 1">重置</button>
        </div>
      </div>
      <p class="graph-help">点击节点查看下方详情；放大后可滚动查看完整图谱。</p>
      <div ref="viewport" class="graph-viewport" tabindex="0" aria-label="可滚动的知识关系图">
        <div class="graph-scaled" :style="{ width: 1000 * graphScale + 'px', height: 620 * graphScale + 'px' }">
          <div class="graph-stage" :style="{ transform: `scale(${graphScale})` }">
            <svg class="graph-links" viewBox="0 0 1000 620" aria-hidden="true">
              <g v-for="(edge, i) in focusEdges" :key="i">
                <line :x1="positions.get(edge.source)?.x" :y1="positions.get(edge.source)?.y" :x2="positions.get(edge.target)?.x" :y2="positions.get(edge.target)?.y" />
                <text :x="((positions.get(edge.source)?.x || 0) + (positions.get(edge.target)?.x || 0)) / 2" :y="((positions.get(edge.source)?.y || 0) + (positions.get(edge.target)?.y || 0)) / 2 - 7">{{ edge.relation }}</text>
              </g>
            </svg>
            <button v-for="node in displayed" :key="node.id" type="button" class="knowledge-node" :class="{ 'is-focus': node.id === focusId, 'is-selected': node.id === selected }" :style="{ left: positions.get(node.id)!.x + 'px', top: positions.get(node.id)!.y + 'px' }" :aria-pressed="selected === node.id" @click="selected = node.id">
              <span>{{ node.type }}</span><strong>{{ node.label }}</strong>
            </button>
          </div>
        </div>
      </div>
      <p v-if="!neighbors.length" class="graph-help">暂无已整理的关联，仍可查看该方法的详细说明。</p>
    </section>
  </div>
  <section v-if="current" class="knowledge-details">
    <div class="details-heading"><div><p class="eyebrow">知识详情 · {{ current.type }}</p><h2>{{ current.label }}</h2></div></div>
    <p class="details-summary">{{ current.summary }}</p>
    <div class="details-grid">
      <section><h3>详细介绍</h3><p>{{ current.detail }}</p><p class="subtle">适用对象：{{ current.audience }}</p></section>
      <section><h3>实施要点</h3><ul><li v-for="(point, i) in current.points" :key="i">{{ point }}</li></ul></section>
      <section v-if="related.length"><h3>相连的知识</h3><button v-for="(edge, i) in related" :key="i" type="button" class="related-link" @click="showRelated(edge.source === current.id ? edge.target : edge.source)">{{ graph.nodes.find(n => n.id === edge.source)?.label }} · {{ edge.relation }} · {{ graph.nodes.find(n => n.id === edge.target)?.label }} →</button></section>
      <section><h3>内容来源</h3><p>{{ current.source_title }}</p><p class="subtle">{{ current.source_locator }}</p><Button v-if="current.source_url" :href="current.source_url" variant="ghost" size="sm">查看来源 ↗</Button></section>
    </div>
    <div class="details-actions"><Button variant="primary" @click="prepareOpen = true">用这个方法备课</Button></div>
    <p class="subtle">图谱独立维护，不读取课堂数据。</p>
  </section>
  <PrepareFromNodeDialog v-if="current" v-model="prepareOpen" :node="current" />
</template>

<style scoped>
.knowledge-workspace { display:grid; grid-template-columns: 250px minmax(0, 1fr); gap:22px; align-items:start; }
.knowledge-navigation { border:1px solid #dce5d9; border-radius:18px; padding:20px 14px; background:#f9fbf7; max-height:780px; overflow:auto; }
.nav-title { padding:0 6px 12px; } .nav-title h2 { font-size:19px; margin:4px 0; }
.knowledge-group { border-bottom:1px solid #e5ebe3; padding:6px 0; }
.group-toggle { width:100%; display:flex; justify-content:space-between; gap:8px; align-items:center; border:0; background:transparent; padding:12px 7px; text-align:left; font:inherit; font-weight:650; color:#345448; cursor:pointer; }
.group-toggle small { font-weight:400; color:#819287; margin-left:5px; }
.knowledge-sublist { display:grid; gap:4px; padding-bottom:8px; }
.knowledge-subitem { border:0; border-radius:9px; background:transparent; color:#5e7164; padding:9px 10px 9px 18px; text-align:left; line-height:1.45; font:inherit; cursor:pointer; }
.knowledge-subitem:hover, .knowledge-subitem.active { background:#e9edf1; color:#40586c; }
.knowledge-graph-panel { min-width:0; border-radius:20px; padding:24px; background:#eef0f3; border:1px solid #dfe3e8; }
.graph-header { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; } .graph-header h2 { margin:4px 0 6px; font-size:23px; } .graph-header p { color:#65717b; }
.zoom-tools { display:flex; align-items:center; gap:5px; background:#fafbfc; border:1px solid #d9dfe5; border-radius:12px; padding:4px; }
.zoom-tools button { border:0; border-radius:8px; width:38px; height:36px; background:transparent; color:#536879; font:inherit; font-size:20px; cursor:pointer; }
.zoom-tools button:hover:not(:disabled) { background:#e9edf2; } .zoom-tools button:disabled { opacity:.4; cursor:default; }
.zoom-tools span { min-width:52px; text-align:center; font-size:13px; } .zoom-tools .zoom-reset { width:auto; padding:0 9px; font-size:13px; }
.graph-help { margin:8px 0 12px; font-size:13px; color:#74808a; }
.graph-viewport { overflow:auto; max-height: min(70vh, 700px); min-height:400px; border:1px solid #d1d8df; border-radius:15px; background-color:#e2e6eb; background-image:radial-gradient(#c1cad3 1px, transparent 1px); background-size:22px 22px; }
.graph-scaled { margin:auto; position:relative; } .graph-stage { width:1000px; height:620px; transform-origin:top left; position:absolute; left:0; top:0; }
.graph-links { position:absolute; inset:0; width:100%; height:100%; pointer-events:none; } .graph-links line { stroke:#9aaab8; stroke-width:2; } .graph-links text { fill:#667987; font-size:13px; text-anchor:middle; paint-order:stroke; stroke:#e2e6eb; stroke-width:5px; stroke-linejoin:round; }
.knowledge-node { position:absolute; transform:translate(-50%, -50%); display:flex; flex-direction:column; justify-content:center; gap:6px; align-items:center; width:162px; min-height:76px; padding:10px; border:1px solid #d4dce3; border-radius:16px; background:#fbfcfd; color:#405665; text-align:center; font:inherit; line-height:1.3; cursor:pointer; box-shadow:0 5px 14px #5365751c; }
.knowledge-node span { color:#8595a1; font-size:11px; } .knowledge-node strong { font-size:14px; } .knowledge-node.is-focus { width:180px; min-height:100px; background:#748a9c; border-color:#748a9c; color:white; } .knowledge-node.is-focus span { color:#edf2f5; } .knowledge-node.is-selected { outline:3px solid #d3bda0; outline-offset:3px; }
.knowledge-details { margin:24px 0 0 272px; padding:clamp(22px, 3vw, 34px); border:1px solid #dce7dc; border-radius:20px; background:#f8fbf7; }
.details-heading { display:flex; justify-content:space-between; align-items:start; gap:16px; } .details-heading h2 { margin:8px 0; } .details-summary { color:#506b59; font-size:16px; }
.details-actions { display:flex; justify-content:flex-end; }
.details-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:18px; margin:22px 0; } .details-grid section { padding:20px; background:white; border:1px solid #e3ebe2; border-radius:14px; } .details-grid h3 { margin:0 0 10px; font-size:16px; } .details-grid li { margin:7px 0; } .related-link { display:block; width:100%; margin:6px 0; text-align:left; background:#f1f7f0; border:0; border-radius:8px; color:#345c47; padding:10px; cursor:pointer; }
@media (max-width:800px) { .knowledge-workspace { grid-template-columns:1fr; } .knowledge-navigation { max-height:300px; } .knowledge-graph-panel { padding:16px; } .knowledge-details { margin-left:0; } .details-grid { grid-template-columns:1fr; } }
</style>
