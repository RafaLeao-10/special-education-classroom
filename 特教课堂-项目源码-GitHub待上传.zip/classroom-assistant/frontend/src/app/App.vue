<script setup lang="ts">
import { onMounted, onUnmounted, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import AppIcon from "../components/AppIcon.vue";
import { auth } from "../api/services/auth";
import { currentUser } from "./session";
import { readDraft, writeDraft } from "./drafts";
import { applyLowStimulus } from "./lowStimulus";

const route = useRoute();
const router = useRouter();
// 低刺激偏好：App 壳先于 loadUser 挂载，须等 currentUser 就绪再读草稿
const calmOn = ref(false);
watch(
  currentUser,
  (user) => {
    if (!user) {
      // 退出登录时清掉低刺激，避免登录页还带着上一个用户的灰化
      applyLowStimulus(false);
      return;
    }
    calmOn.value = readDraft<boolean>("low-stimulus") ?? false;
  },
  { immediate: true },
);
watch(
  calmOn,
  (v) => {
    writeDraft("low-stimulus", v);
    applyLowStimulus(v);
  },
  { immediate: true },
);
const login = () => {
  currentUser.value = null;
  void router.replace("/login");
};
async function logout() {
  try {
    await auth.logout();
    login();
  } catch (e) {
    ElMessage.error((e as Error).message);
  }
}
onMounted(() => window.addEventListener("auth-required", login));
onUnmounted(() => window.removeEventListener("auth-required", login));
</script>
<template>
  <router-view v-if="route.meta.standalone" />
  <div v-else-if="route.path === '/login'" class="login-shell">
    <router-view />
  </div>
  <div v-else class="app-shell">
    <header class="app-header">
      <router-link to="/" class="brand"
        ><span class="brand-symbol"><AppIcon name="leaf" :size="24" /></span
        ><span
          >特教课堂<span class="brand-caption">教师工作台</span></span
        ></router-link
      >
      <nav class="header-nav" aria-label="主导航">
        <router-link to="/" :class="{ selected: route.path === '/' }"
          >工作台</router-link
        >
        <router-link
          to="/students"
          :class="{ selected: route.path === '/students' }"
          >学生档案</router-link
        >
      </nav>
      <div class="header-account">
        <button
          type="button"
          class="calm-toggle"
          :aria-pressed="calmOn"
          @click="calmOn = !calmOn"
        >
          <AppIcon name="moon" :size="15" />{{
            calmOn ? "低刺激开" : "低刺激"
          }}
        </button>
        <span class="environment-label"><i />本地预览</span
        ><span class="avatar">师</span
        ><span class="account-name">{{ currentUser?.name || "教师" }}</span
        ><button
          v-if="currentUser"
          class="icon-button"
          aria-label="退出登录"
          @click="logout"
        >
          <AppIcon name="logout" :size="18" />
        </button>
      </div>
    </header>
    <main class="workspace"><router-view :key="route.path" /></main>
    <footer class="app-footer">
      <span>让教学更从容，让成长被看见。</span
      ><span>特教课堂辅助平台 · 开发预览</span>
    </footer>
  </div>
</template>
