import { onUnmounted, ref } from "vue";

interface WakeLockLike {
request: (type: string) => Promise<{ release: () => Promise<void> }>;
}

export function useKiosk() {
const isFullscreen = ref(false);
const idle = ref(false);
let idleTimer: ReturnType<typeof setTimeout> | undefined;
let wakeLock: { release: () => Promise<void> } | null = null;

async function enter() {
    try {
    // 必须在用户点击手势里调用
    await document.documentElement.requestFullscreen();
    } catch {
    // iPad Safari 等不支持全屏 API：降级为铺满样式
    }
    isFullscreen.value = true;
    requestWakeLock();
    resetIdle();
}

async function exit() {
    try {
    if (document.fullscreenElement) await document.exitFullscreen();
    } catch {
    /* 忽略 */
    }
    isFullscreen.value = false;
}

async function requestWakeLock() {
    try {
    const nav = navigator as Navigator & { wakeLock?: WakeLockLike };
    wakeLock = (await nav.wakeLock?.request("screen")) ?? null;
    } catch {
    wakeLock = null;
    }
}

function resetIdle() {
    idle.value = false;
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => (idle.value = true), 3000);
}

function onActivity() {
    if (!isFullscreen.value) return;
    resetIdle();
}

function onFullscreenChange() {
    if (!document.fullscreenElement) {
    // 用户按 ESC 退出全屏
    isFullscreen.value = false;
    idle.value = false;
    } else {
    isFullscreen.value = true;
    resetIdle();
    }
}

function onVisibility() {
    if (!document.hidden && isFullscreen.value) requestWakeLock();
}

document.addEventListener("fullscreenchange", onFullscreenChange);
document.addEventListener("pointermove", onActivity);
document.addEventListener("pointerdown", onActivity);
document.addEventListener("keydown", onActivity);
document.addEventListener("visibilitychange", onVisibility);
onUnmounted(() => {
    clearTimeout(idleTimer);
    document.removeEventListener("fullscreenchange", onFullscreenChange);
    document.removeEventListener("pointermove", onActivity);
    document.removeEventListener("pointerdown", onActivity);
    document.removeEventListener("keydown", onActivity);
    document.removeEventListener("visibilitychange", onVisibility);
});

return { isFullscreen, idle, enter, exit };
}