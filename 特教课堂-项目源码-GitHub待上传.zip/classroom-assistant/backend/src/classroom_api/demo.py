"""Install the teaching examples without model calls or overwriting edits."""

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from classroom_api.seed import seed
from classroom_api.settings import Settings


def create_demo(db, settings):
    seed(db, settings)
    return "30000000-0000-4000-8000-000000000001"


def main():
    settings = Settings()
    engine = create_engine(settings.database_url)
    with Session(engine) as db, db.begin():
        create_demo(db, settings)
    engine.dispose()
    print("教学示例已准备：http://127.0.0.1:5173/showcase")


if __name__ == "__main__":
    main()
