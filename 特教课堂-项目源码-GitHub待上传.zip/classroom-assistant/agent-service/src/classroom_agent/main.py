from classroom_contracts.agent import AgentRequest, AgentResponse
from classroom_contracts.models import StatisticsRow
from classroom_contracts.teaching import StatisticsInput
from fastapi import FastAPI

from .service import AgentService
from .settings import Settings
from .tools.statistics import summarize


def create_app(settings: Settings | None = None) -> FastAPI:
    config = settings or Settings()
    service = AgentService(config)
    app = FastAPI(title="Classroom Agent Gateway", version="1.0")

    @app.get("/health")
    def health():
        return {
            "status": "ok",
            "provider": config.agent_provider,
            "configured": config.configured,
        }

    @app.post("/internal/v1/agent-runs", response_model=AgentResponse)
    async def agent_runs(request: AgentRequest):
        return await service.run(request)

    @app.post("/internal/v1/statistics", response_model=list[StatisticsRow])
    def statistics(body: StatisticsInput):
        return summarize(body.records)

    return app
