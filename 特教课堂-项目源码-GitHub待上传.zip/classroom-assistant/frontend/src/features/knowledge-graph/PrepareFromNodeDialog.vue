<script setup lang="ts">
import { ref, watch } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import type { GraphNode } from "./graph.types";
import { nodePrepareInfo } from "./nodeMethodMap";
import { lessonsApi } from "../../api/services/lessons";
import { studentsApi, type Student } from "../../api/services/students";
import { loadUser } from "../../app/session";
import { trainingMethods } from "../preparation/trainingMethods";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";

const props = defineProps<{ modelValue: boolean; node: GraphNode }>();
const emit = defineEmits<{ (e: "update:modelValue", v: boolean): void }>();

const router = useRouter();
const lessons = ref<Awaited<ReturnType<typeof lessonsApi.list>>["items"]>([]);
const students = ref<Student[]>([]);
const newStudentIds = ref<string[]>([]);
const loading = ref(false);
const notLoggedIn = ref(false);
const chosen = ref("new");
const busy = ref(false);

const mapping = nodePrepareInfo(props.node.id);
// 把方法 id 翻译成中文名，供预览展示
const methodTitles = mapping.methods
.map((m) => trainingMethods.find((t) => t.id === m)?.title)
.filter(Boolean)
.join("、");

watch(
() => props.modelValue,
async (open) => {
    if (!open) return;
    // 图谱页免登录可访问：点备课前必须先确认登录状态
    notLoggedIn.value = !(await loadUser());
    if (notLoggedIn.value) return;
      chosen.value = "new";
      newStudentIds.value = [];
      loading.value = true;
      try {
        const [owned, people] = await Promise.all([
          lessonsApi.list(),
          studentsApi.list(),
        ]);
        lessons.value = owned.items
          .filter((l) => l.status === "draft" || l.status === "ready")
          .sort(
            (a, b) =>
              new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
          )
          .slice(0, 10);
        students.value = people.items;
      } catch (e) {
        ElMessage.error((e as Error).message);
      } finally {
        loading.value = false;
    }
},
);

async function confirm() {
if (busy.value) return;
busy.value = true;
try {
    let lessonId = chosen.value;
    if (chosen.value === "new") {
        if (!newStudentIds.value.length) {
          ElMessage.warning(
            "请选择至少一位学生；还没有学生的话，先到「学生档案」建立",
          );
          return;
        }
    // 只填最少必填字段，细节进备课页再补
    const created = await lessonsApi.create({
        title: `围绕“${props.node.label}”的教学`,
        student_ids: newStudentIds.value,
        planned_duration_min: 40,
        available_materials: [],
        previous_report_ids: [],
    });
    lessonId = created.id;
    }
    const query: Record<string, string> = { node: props.node.id };
    if (mapping.methods.length) query.method = mapping.methods.join(",");
    emit("update:modelValue", false);
    await router.push({ path: `/lessons/${lessonId}/prepare`, query });
} catch (e) {
    ElMessage.error((e as Error).message);
} finally {
    busy.value = false;
}
}
</script>

<template>
<el-dialog
    :model-value="modelValue"
    title="用这个方法备课"
    width="520px"
    @update:model-value="emit('update:modelValue', $event)"
>
    <p v-if="notLoggedIn" class="subtle">
    请先登录教师账号，再进行备课。
    </p>
    <template v-else>
    <p class="subtle">为「{{ node.label }}」准备一堂课：选一节已有教案，或新建一节课。</p>
    <p v-if="loading" class="subtle">正在读取课程…</p>
    <div v-else class="prepare-from-node-list">
        <label class="prepare-from-node-option" :class="{ selected: chosen === 'new' }">
        <input v-model="chosen" type="radio" value="new" />
        <span class="recent-icon"><AppIcon name="plus" :size="18" /></span>
        <div>
            <strong>新建教案</strong>
            <span>围绕“{{ node.label }}”的教学</span>
        </div>
        </label>
        <div v-if="chosen === 'new'" class="prepare-from-node-students">
            <el-select
              v-model="newStudentIds"
              multiple
              placeholder="选择学生（至少一位）"
              style="width: 100%"
            >
              <el-option
                v-for="s in students"
                :key="s.id"
                :label="s.name"
                :value="s.id"
              />
            </el-select>
        </div>
        <label
        v-for="l in lessons"
        :key="l.id"
        class="prepare-from-node-option"
        :class="{ selected: chosen === l.id }"
        >
        <input v-model="chosen" type="radio" :value="l.id" />
        <span class="recent-icon"><AppIcon name="book" :size="18" /></span>
        <div>
            <strong>{{ l.title }}</strong>
            <span>{{ l.status === "ready" ? "待上课" : "备课中" }} · 最近更新</span>
        </div>
        </label>
        <p v-if="!lessons.length" class="subtle">
        还没有草稿或待上的教案，选择“新建教案”开始吧。
        </p>
    </div>
    <div class="prepare-from-node-preview">
        <p class="eyebrow">将带进备课页</p>
        <p v-if="methodTitles">教学方式：{{ methodTitles }}</p>
        <p v-if="mapping.note">{{ mapping.note }}</p>
    </div>
    </template>
    <template #footer>
      <ButtonGroup :gap="12">
        <Button variant="secondary" :disabled="busy" @click="emit('update:modelValue', false)"
          >取消</Button
        >
        <Button
          variant="primary"
          :loading="busy"
          :disabled="notLoggedIn"
          @click="confirm"
        >
          确认去备课
        </Button>
      </ButtonGroup>
    </template>
</el-dialog>
</template>