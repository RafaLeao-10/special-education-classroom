<script setup lang="ts">
import type { ReportContent } from "../../api/services/reports";
import type { Lesson } from "../../api/services/lessons";
import type { Student } from "../../api/services/students";
import Button from "../../components/Button.vue";
const content = defineModel<ReportContent>({ required: true });
const props = defineProps<{
  lesson: Lesson;
  students: Student[];
  disabled: boolean;
}>();
function addRecommendation() {
  content.value.recommendations.push({
    subject: { type: "class", id: props.lesson.id },
    task_id: null,
    action: "",
    basis: "",
    record_ids: [],
    knowledge_refs: [],
  });
}
</script>
<template>
  <div class="teacher-report-form">
    <label for="report-overview"
      >课堂概览 <span class="subtle">必填</span></label
    >
    <el-input
      id="report-overview"
      v-model="content.overview"
      type="textarea"
      :rows="4"
      :disabled="disabled"
      placeholder="填写实际开展的活动、现场支持及整体情况。"
    />
    <details class="report-fields" v-if="content.activity_summaries.length">
      <summary>活动回顾</summary>
    <template v-for="item in content.activity_summaries" :key="item.activity_id"
      ><label>{{
        lesson.plan?.activities.find((a) => a.id === item.activity_id)?.title ||
        "课堂活动"
      }}</label>
      <el-input
        v-model="item.text"
        type="textarea"
        :rows="2"
        :disabled="disabled"
        :aria-label="`活动回顾 ${item.activity_id}`"
        placeholder="活动中实际发生的情况；未观察到的可保留未知。"
    /></template>
    </details>
    <details class="report-fields" v-if="content.student_summaries.length || content.group_summaries.length">
      <summary>学生与小组观察</summary>
    <template v-for="item in content.student_summaries" :key="item.student_id"
      ><label
        >{{ students.find((s) => s.id === item.student_id)?.name || "学生" }} ·
        课堂观察</label
      >
      <el-input
        v-model="item.text"
        type="textarea"
        :rows="2"
        :disabled="disabled"
        :aria-label="`学生观察 ${item.student_id}`"
        placeholder="记录实际反应及支持，不把计划当成已完成表现。"
    /></template>
    <template v-for="item in content.group_summaries" :key="item.group_id"
      ><label>小组观察</label
      ><el-input v-model="item.text" type="textarea" :disabled="disabled"
    /></template>
    </details>
    <details v-if="content.adjustment_summaries.length" class="report-fields">
      <summary>课堂调整回顾</summary>
      <el-input v-for="item in content.adjustment_summaries" :key="item.adjustment_id" v-model="item.text" type="textarea" :rows="2" :disabled="disabled" aria-label="课堂调整回顾" />
    </details>
    <details class="report-fields">
      <summary>下一次教学建议</summary>
    <div class="section-heading compact">
      <h3>下一次教学建议</h3>
      <Button v-if="!disabled" size="sm" variant="ghost" @click="addRecommendation"
        >添加建议</Button
      >
    </div>
    <div
      v-for="(item, i) in content.recommendations"
      :key="i"
      class="report-recommendation"
    >
      <el-input
        v-model="item.action"
        type="textarea"
        :rows="2"
        :disabled="disabled"
        aria-label="教学建议"
        placeholder="建议下一次怎样安排？"
      />
      <el-input
        v-model="item.basis"
        :disabled="disabled"
        aria-label="建议依据"
        placeholder="这条建议基于什么观察？"
      />
      <Button
        v-if="!disabled"
        size="sm"
        variant="quiet"
        @click="content.recommendations.splice(i, 1)"
        >移除建议</Button
      >
    </div>
    <p v-if="!content.recommendations.length" class="subtle">
      可添加下一次教学建议。
    </p>
    </details>
    <details v-if="content.missing_information.length" class="report-fields">
      <summary>尚不确定的信息</summary>
    <template v-for="(item, i) in content.missing_information" :key="i"
      ><label>尚不确定的信息</label
      ><el-input
        v-model="item.description"
        type="textarea"
        :disabled="disabled"
    /></template>
    </details>
  </div>
</template>

<style scoped>
.report-fields { margin-top: 12px; border: 1px solid #dfe7dd; border-radius: 12px; background: rgba(255, 255, 255, .62); padding: 0 16px; }
.report-fields summary { cursor: pointer; padding: 14px 0; font-weight: 600; color: #425b4b; list-style: none; display: flex; justify-content: space-between; align-items: center; }
.report-fields summary::-webkit-details-marker { display: none; }
.report-fields summary::after { content: '⌄'; font-size: 19px; }
.report-fields[open] summary::after { content: '⌃'; }
.report-fields[open] { padding-bottom: 16px; }
.report-fields label { display: block; margin: 12px 0 6px; }
.report-fields :deep(.el-textarea) { margin-bottom: 8px; }
</style>
