import type { Directive } from "vue";

// 点击后移除焦点：防止 Enter/空格重复触发刚点过的按钮，
// 把键盘操作让给课堂快捷键系统
export const clickBlur: Directive<HTMLElement> = {
mounted(el: HTMLElement) {
    el.addEventListener("click", blur);
},
unmounted(el: HTMLElement) {
    el.removeEventListener("click", blur);
},
};

function blur(this: HTMLElement) {
this.blur();
}