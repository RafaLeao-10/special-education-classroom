import type { GraphNode } from "./graph.types";
export function graphLayout(nodes: GraphNode[]) {
  const types = [...new Set(nodes.map((n) => n.type))];
  return new Map(
    nodes.map((node) => {
      const column = types.indexOf(node.type);
      const group = nodes.filter((n) => n.type === node.type);
      return [
        node.id,
        {
          x: types.length === 1 ? 50 : 18 + (column * 64) / (types.length - 1),
          y: 18 + (group.indexOf(node) * 64) / Math.max(1, group.length - 1),
        },
      ];
    }),
  );
}
