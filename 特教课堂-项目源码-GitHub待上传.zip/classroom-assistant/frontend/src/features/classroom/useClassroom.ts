import { computed, ref } from "vue";
import { classroomApi } from "../../api/services/classroom";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import { studentsApi, type Student } from "../../api/services/students";

export function useClassroom(id: string) {
  const lesson = ref<Lesson>();
  const students = ref<Student[]>([]);
  const mode = ref<"outline" | "focus">("outline");
  const loading = ref(true);
  const busy = ref(false);
  const error = ref("");
  const sequence = computed(
    () =>
      lesson.value?.plan?.activities.flatMap((activity) =>
        activity.tasks.flatMap((task) =>
          (lesson.value?.execution.split_task_ids?.includes(task.id)
            ? task.steps : task.steps.slice(0, 1)).map((step) => ({ activity, task, step })),
        ),
      ) || [],
  );
  const index = computed(() =>
    Math.max(
      0,
      sequence.value.findIndex(
        (item) =>
          item.task.id === lesson.value?.execution.display_task_id &&
          (item.step.id === lesson.value?.execution.display_step_id ||
            !lesson.value?.execution.split_task_ids?.includes(item.task.id)),
      ),
    ),
  );
  const current = computed(() => sequence.value[index.value]);
  const currentState = computed(
    () =>
      lesson.value?.execution.task_states.find(
        (s) => s.task_id === current.value?.task.id,
      )?.status || "pending",
  );
  async function run(work: () => Promise<void>) {
    if (busy.value) return;
    busy.value = true;
    error.value = "";
    try {
      await work();
      return true;
    } catch (e) {
      error.value = (e as Error).message;
      return false;
    } finally {
      busy.value = false;
    }
  }
  async function load() {
    const result = await run(async () => {
      const [data, people] = await Promise.all([
        lessonsApi.get(id),
        studentsApi.list(),
      ]);
      lesson.value = data;
      students.value = data.student_snapshots?.length
        ? data.student_snapshots
        : people.items;
      if (data.status === "in_progress") mode.value = "focus";
    });
    loading.value = false;
    return result;
  }
  async function begin() {
    await run(async () => {
      if (lesson.value!.status === "draft")
        lesson.value = await classroomApi.action(id, {
          action: "confirm_plan",
          expected_plan_version: lesson.value!.plan_version,
        });
      lesson.value = await classroomApi.action(id, {
        action: "start",
        expected_plan_version: lesson.value!.plan_version,
      });
      mode.value = "focus";
    });
  }
  async function progress(
    targetIndex: number,
    task_changes: {
      task_id: string;
      status: "pending" | "active" | "done"|"skipped";
    }[] = [],
  ) {
    const target = sequence.value[targetIndex];
    if (!target) return;
    await run(async () => {
      const result = await classroomApi.execution(id, {
        expected_record_version: task_changes.length
          ? lesson.value!.record_version
          : null,
        task_changes,
        display_task_id: target.task.id,
        display_step_id: lesson.value!.execution.split_task_ids?.includes(target.task.id) ? target.step.id : null,
      });
      lesson.value!.execution = result.execution;
      lesson.value!.record_version = Math.max(
        lesson.value!.record_version,
        result.record_version,
      );
    });
  }
  async function toggleSplit(taskId: string, enabled: boolean) {
    if (!lesson.value) return;
    const splitIds = new Set(lesson.value.execution.split_task_ids || []);
    if (enabled) splitIds.add(taskId); else splitIds.delete(taskId);
    const target = current.value;
    if (!target) return;
    await run(async () => {
      const result = await classroomApi.execution(id, {
        task_changes: [], split_task_ids: [...splitIds],
        display_task_id: target.task.id,
        display_step_id: splitIds.has(target.task.id) ? target.step.id : null,
      });
      lesson.value!.execution = result.execution;
    });
  }
  async function activate() {
    const changes: { task_id: string; status: "pending" | "active" }[] = lesson
      .value!.execution.task_states.filter((s) => s.status === "active")
      .map((s) => ({ task_id: s.task_id, status: "pending" }));
    changes.push({ task_id: current.value.task.id, status: "active" });
    await progress(index.value, changes);
  }
  async function completeTask() {
    const next = sequence.value.findIndex((item) =>
      lesson.value!.execution.task_states.some(
        (s) => s.task_id === item.task.id && s.status === "pending" && s.task_id !== current.value.task.id,
      ),
    );
    const changes: { task_id: string; status: "done" | "active" }[] = [
      { task_id: current.value.task.id, status: "done" },
    ];
    if (next >= 0)
      changes.push({ task_id: sequence.value[next].task.id, status: "active" });
    await progress(next >= 0 ? next : index.value, changes);
  }
  async function skipTask() {
    const next = sequence.value.findIndex((item) =>
      lesson.value!.execution.task_states.some(
        (s) =>
          s.task_id === item.task.id &&
          s.status === "pending" &&
          s.task_id !== current.value.task.id,
      ),
    );
    const changes: { task_id: string; status: "skipped" | "active" }[] = [
      { task_id: current.value.task.id, status: "skipped" },
    ];
    if (next >= 0)
      changes.push({ task_id: sequence.value[next].task.id, status: "active" });
    await progress(next >= 0 ? next : index.value, changes);
  }
  async function finish() {
    return run(async () => {
      lesson.value = await classroomApi.action(id, {
        action: "complete",
        expected_plan_version: lesson.value!.plan_version,
      });
    });
  }
  return {
    lesson,
    students,
    mode,
    loading,
    busy,
    error,
    sequence,
    index,
    current,
    currentState,
    load,
    begin,
    move: (delta: number) => progress(index.value + delta),
    activate,
    completeTask,
    skipTask,
    toggleSplit,
    finish,
  };
}
