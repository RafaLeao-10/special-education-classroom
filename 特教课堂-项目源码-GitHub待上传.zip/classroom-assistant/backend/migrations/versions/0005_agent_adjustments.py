"""Store teacher-adopted classroom adjustments alongside plan history."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0005_agent_adjustments"
down_revision = "0004_manual_editing"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "adjustments",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("lesson_id", sa.String(36), sa.ForeignKey("lessons.id"), nullable=False),
        sa.Column("job_id", sa.String(36), sa.ForeignKey("ai_jobs.id"), nullable=False, unique=True),
        sa.Column("details", postgresql.JSONB(), nullable=False),
        sa.Column("applied_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_adjustments_lesson_id", "adjustments", ["lesson_id"])


def downgrade():
    op.drop_table("adjustments")
