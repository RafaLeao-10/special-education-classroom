<script setup lang="ts">
import { ref } from "vue";
import { useRouter } from "vue-router";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";
const props = defineProps<{ lesson: Lesson; disabled?: boolean }>();
const router = useRouter();
const open = ref(false);
const title = ref("");
const requestId = ref("");
const busy = ref(false);
const error = ref("");
function begin() {
  title.value = `${props.lesson.title} · 副本`.slice(0, 200);
  requestId.value = crypto.randomUUID();
  error.value = "";
  open.value = true;
}
async function copy() {
  busy.value = true;
  error.value = "";
  try {
    const result = await lessonsApi.copy(props.lesson.id, {
      client_request_id: requestId.value,
      expected_plan_version: props.lesson.plan_version,
      title: title.value.trim(),
    });
    open.value = false;
    await router.push(`/lessons/${result.id}/prepare`);
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    busy.value = false;
  }
}
</script>
<template>
  <Button v-if="lesson.plan" variant="secondary" :disabled="disabled" @click="begin"
    >复制教案到新课</Button
  ><el-dialog
    v-model="open"
    title="复制教案到新课"
    width="min(540px,92vw)"
    :close-on-click-modal="!busy"
    :show-close="!busy"
    ><p>
      复制活动、任务、步骤、材料和资料，创建独立的备课草稿。课堂进度、观察记录和报告保留在原课。
    </p>
    <p class="subtle">
      新课沿用参与学生并使用当前档案；已移除的目标会留待重新选择。
    </p>
    <label
      >新课程标题<el-input
        v-model="title"
        maxlength="200"
        aria-label="新课程标题"
    /></label>
    <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
    <template #footer
      ><ButtonGroup :gap="12">
        <Button variant="secondary" :disabled="busy" @click="open = false"
          >取消</Button
        >
        <Button
          variant="primary"
          :loading="busy"
          :disabled="!title.trim()"
          @click="copy"
          >创建副本并编辑</Button
        ></ButtonGroup
      ></template
    ></el-dialog
  >
</template>
