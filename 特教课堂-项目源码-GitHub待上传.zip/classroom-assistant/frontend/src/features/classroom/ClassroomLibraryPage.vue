<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import AppIcon from "../../components/AppIcon.vue";
import Button from "../../components/Button.vue";
const lessons = ref<Lesson[]>([]);
const search = ref("");
const error = ref("");
const loading = ref(true);
const prepared = computed(() => lessons.value.filter((lesson) => lesson.plan));
const filtered = computed(() =>
  prepared.value.filter((lesson) => lesson.title.includes(search.value)),
);
onMounted(async () => {
  try {
    const summaries = (await lessonsApi.list()).items;
    lessons.value = await Promise.all(
      summaries.map((lesson) => lessonsApi.get(lesson.id)),
    );
  } catch (e) {
    error.value = (e as Error).message;
  } finally {
    loading.value = false;
  }
});
</script>
<template>
  <div class="page-title">
    <div>
      <router-link to="/" class="back-link">← 返回工作台</router-link>
      <span class="stage-tag stage-sand">课中 · 课堂</span>
      <h1>选好教案，从容进入课堂</h1>
      <p class="page-description">
        先回顾整堂课，再把注意力放在当下的一项任务。
      </p>
    </div>
    <span class="feature-emblem sand"
      ><AppIcon name="classroom" :size="30"
    /></span>
  </div>
  <div class="workflow-strip">
    <span class="current">01 选择已保存教案</span><i /><span
      >02 回顾大纲与任务</span
    ><i /><span>03 单任务课堂视图</span>
  </div>
  <div class="toolbar">
    <h2>你的课堂教案</h2>
    <el-input
      v-model="search"
      placeholder="按课程名称查找"
      aria-label="查找课堂教案"
      clearable
      class="search-field"
    />
  </div>
  <p class="preview-notice">
    正式开课后，课堂进度、文字速记和观察记录均可保存。也可以先从首页“展示版”了解完整教学流程。
  </p>
  <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
  <p v-else-if="loading" class="subtle">正在读取课程…</p>
  <div v-else class="lesson-grid">
    <router-link
      v-for="lesson in filtered"
      :key="lesson.id"
      :to="`/lessons/${lesson.id}/classroom`"
      class="lesson-card"
      ><div class="entry-top">
        <span class="entry-icon sand"><AppIcon name="book" /></span
        ><span class="status-pill">{{
          {
            draft: "教案已保存",
            ready: "待上课",
            in_progress: "课堂中 · 可继续",
            completed: "已结课 · 可回顾",
          }[lesson.status]
        }}</span>
      </div>
      <h3>{{ lesson.title }}</h3>
      <p>
        {{ lesson.planned_duration_min }} 分钟 ·
        {{ lesson.plan?.activities.length }} 个教学活动
      </p>
      <span class="entry-link"
        >查看课堂大纲 <AppIcon name="arrow" :size="18" /></span
    ></router-link>
  </div>
  <p
    v-if="!loading && !error && lessons.length > prepared.length"
    class="subtle"
  >
    另有
    {{ lessons.length - prepared.length }}
    份备课尚未采用教案，完成后会出现在这里。<Button
      to="/lessons"
      variant="ghost"
      size="sm"
      class="btn-arrow"
      >继续备课 <AppIcon name="arrow" :size="16" /></Button
    >
  </p>
  <section v-if="!loading && !error && !filtered.length" class="empty-state">
    <AppIcon name="book" :size="34" />
    <h2>{{ search ? "没有找到这堂课" : "先准备一堂属于你的课" }}</h2>
    <p>教案采用保存后，就可以在这里回顾课堂任务。</p>
    <Button to="/lessons" variant="primary">开始备课</Button>
  </section>
</template>
