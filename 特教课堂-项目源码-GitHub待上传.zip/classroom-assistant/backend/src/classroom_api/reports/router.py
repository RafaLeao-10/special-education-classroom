from classroom_contracts.enums import ReportStatus
from classroom_contracts.http import Envelope, Items
from classroom_contracts.models import Report
from classroom_contracts.planned import (
    ReportAction,
    ReportArchive,
    ReportChoice,
    ReportPatch,
    ReportSummary,
    TeacherReportCreate,
)
from fastapi import APIRouter, Depends, Query, Request
from pydantic import AwareDatetime
from sqlalchemy import select
from sqlalchemy.orm import Session

from classroom_api.auth.access import require_lesson, require_report
from classroom_api.auth.service import require_user
from classroom_api.db import get_db
from classroom_api.statistics.service import calculate

from . import archive, service
from .models import ReportRow

router = APIRouter(tags=["reports"], dependencies=[Depends(require_user)])


@router.get(
    "/lessons/{id}/reports",
    response_model=Envelope[Items[ReportSummary]],
    dependencies=[Depends(require_lesson)],
)
def listing(id: str, db: Session = Depends(get_db)):
    return Envelope(data=Items(items=service.listing(db, id)))


@router.post(
    "/lessons/{id}/reports",
    status_code=201,
    response_model=Envelope[Report],
    dependencies=[Depends(require_lesson)],
)
async def create(id: str, body: TeacherReportCreate, request: Request, db: Session = Depends(get_db)):
    existing = db.scalar(
        select(ReportRow).where(
            ReportRow.lesson_id == id, ReportRow.client_request_id == body.client_request_id
        )
    )
    if existing:
        return Envelope(data=service.create(db, id, body, None))
    statistics = await calculate(request.app, id)
    return Envelope(data=service.create(db, id, body, statistics))


@router.get("/reports", response_model=Envelope[Items[ReportChoice]])
def choices(
    student_ids: list[str] = Query(default=[]), db: Session = Depends(get_db), user=Depends(require_user)
):
    return Envelope(data=Items(items=service.choices(db, student_ids, user.id)))


@router.get("/reports/{report_id}", response_model=Envelope[Report], dependencies=[Depends(require_report)])
def read(report_id: str, db: Session = Depends(get_db)):
    return Envelope(data=service.to_dto(db, service.get(db, report_id)))


@router.patch("/reports/{report_id}", response_model=Envelope[Report], dependencies=[Depends(require_report)])
def update(report_id: str, body: ReportPatch, db: Session = Depends(get_db)):
    return Envelope(data=service.update(db, report_id, body))


@router.post(
    "/reports/{report_id}/actions", response_model=Envelope[Report], dependencies=[Depends(require_report)]
)
def action(report_id: str, body: ReportAction, db: Session = Depends(get_db)):
    return Envelope(data=service.act(db, report_id, body))


@router.get("/report-archive", response_model=Envelope[ReportArchive])
def search(
    query: str = "",
    student_id: str | None = None,
    status: ReportStatus | None = None,
    is_stale: bool | None = None,
    generated_from: AwareDatetime | None = None,
    generated_before: AwareDatetime | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(12, ge=1, le=100),
    db: Session = Depends(get_db),
    user=Depends(require_user),
):
    return Envelope(
        data=archive.search(
            db,
            query,
            student_id,
            status,
            is_stale,
            generated_from,
            generated_before,
            page,
            page_size,
            user.id,
        )
    )
