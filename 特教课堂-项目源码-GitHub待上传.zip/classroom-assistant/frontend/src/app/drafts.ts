import { currentUser } from "./session";

function key(scope: string) {
  const userId = currentUser.value?.id;
  return userId ? `classroom:${userId}:${scope}` : null;
}

export function readDraft<T>(scope: string): T | null {
  const name = key(scope);
  if (!name) return null;
  try {
    return JSON.parse(localStorage.getItem(name) || "null") as T | null;
  } catch {
    return null;
  }
}

export function writeDraft(scope: string, value: unknown) {
  const name = key(scope);
  if (!name) return;
  try {
    localStorage.setItem(name, JSON.stringify(value));
  } catch {
    /* Keep the current in-memory form usable if browser storage is full. */
  }
}

export function clearDraft(scope: string) {
  const name = key(scope);
  try {
    if (name) localStorage.removeItem(name);
  } catch {
    /* Browser storage may be unavailable. */
  }
}
