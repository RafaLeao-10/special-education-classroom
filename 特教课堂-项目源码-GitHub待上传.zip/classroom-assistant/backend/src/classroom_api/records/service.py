from datetime import UTC, datetime
from uuid import uuid4

from classroom_contracts.models import Record
from classroom_contracts.planned import RecordCreate, RecordPatch, RecordSaved
from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from classroom_api.errors import BusinessError
from classroom_api.lessons import service as lessons
from classroom_api.lessons.history import get_plan
from classroom_api.lessons.models import LessonRow

from .models import RecordCorrectionRow, RecordRow


def to_dto(row: RecordRow) -> Record:
    return Record(
        id=row.id,
        lesson_id=row.lesson_id,
        client_record_id=row.client_record_id,
        revision=row.revision,
        is_void=row.is_void,
        observed_at=row.observed_at,
        **row.details,
    )


def get(db: Session, lesson_id: str, record_id: str) -> RecordRow:
    row = db.get(RecordRow, record_id)
    if row is None or row.lesson_id != lesson_id:
        raise BusinessError(404, "NOT_FOUND", "课堂记录不存在")
    return row


def listing(db: Session, lesson_id: str, include_void: bool = False):
    lessons.get(db, lesson_id)
    query = select(RecordRow).where(RecordRow.lesson_id == lesson_id)
    if not include_void:
        query = query.where(RecordRow.is_void.is_(False))
    return [to_dto(row) for row in db.scalars(query.order_by(RecordRow.observed_at, RecordRow.id))]


def validate(db: Session, lesson: LessonRow, record: Record):
    if lesson.status not in ("in_progress", "completed"):
        raise BusinessError(409, "INVALID_STATE", "开课后才可以保存或更正课堂记录")
    if record.kind == "note" and not record.note.strip():
        raise BusinessError(422, "INVALID_ARGUMENT", "请填写速记内容", ["note"])
    plan = (
        get_plan(db, lesson.id, record.task_plan_version)
        if record.task_plan_version is not None
        else lessons.to_dto(lesson).plan
    )
    if record.subject.type == "class":
        valid_subject = record.subject.id == lesson.id
    elif record.subject.type == "student":
        valid_subject = record.subject.id in lesson.student_ids
    else:
        valid_subject = plan is not None and record.subject.id in {g.id for g in plan.groups}
    if not valid_subject:
        raise BusinessError(422, "INVALID_ARGUMENT", "记录对象不属于本课", ["subject"])
    if record.activity_id or record.task_id or record.step_id:
        if record.task_plan_version is None or record.activity_id is None:
            raise BusinessError(422, "INVALID_ARGUMENT", "关联任务时请提供活动与方案版本")
        activity = next((a for a in plan.activities if a.id == record.activity_id), None)
        task = next((t for t in activity.tasks if t.id == record.task_id), None) if activity else None
        valid = activity is not None and (record.task_id is None or task is not None)
        valid &= record.step_id is None or (task is not None and record.step_id in {s.id for s in task.steps})
        if record.subject.type == "student":
            valid &= record.subject.id in (
                task.participant_ids if task else activity.participant_ids if activity else []
            )
        if record.subject.type == "group" and activity:
            valid &= activity.group_id == record.subject.id
        # recording_unit is the plan's preferred level. Teachers may observe the
        # whole task or a valid step; the explicit step_id preserves that choice.
        if not valid:
            raise BusinessError(422, "INVALID_ARGUMENT", "记录引用的活动、任务或步骤无效")
    if plan and not set(record.routine_support_ids) <= {support.id for support in plan.supports}:
        raise BusinessError(422, "INVALID_ARGUMENT", "记录引用的支持方式不存在")


def write(row: RecordRow, value: Record):
    row.details = value.model_dump(
        mode="json", exclude={"id", "lesson_id", "client_record_id", "revision", "is_void", "observed_at"}
    )
    row.observed_at = value.observed_at
    row.revision, row.is_void = value.revision, value.is_void


def touch(lesson: LessonRow):
    lesson.record_version += 1
    lesson.updated_at = datetime.now(UTC)


def create(db: Session, lesson_id: str, body: RecordCreate) -> RecordSaved:
    lesson = lessons.get(db, lesson_id, lock=True)
    existing = db.scalar(
        select(RecordRow).where(
            RecordRow.lesson_id == lesson_id, RecordRow.client_record_id == body.client_record_id
        )
    )
    if existing:
        original = RecordCreate.model_validate(
            to_dto(existing).model_dump(include=set(RecordCreate.model_fields))
        )
        if existing.revision == 1 and original != body:
            raise BusinessError(409, "REQUEST_CONFLICT", "同一记录提交标识不能用于不同内容")
        return RecordSaved(record=to_dto(existing), record_version=lesson.record_version)
    try:
        value = Record(id=str(uuid4()), lesson_id=lesson_id, revision=1, is_void=False, **body.model_dump())
    except ValidationError as exc:
        raise BusinessError(422, "INVALID_ARGUMENT", "记录字段不完整或与记录类型不匹配") from exc
    validate(db, lesson, value)
    row = RecordRow(id=value.id, lesson_id=lesson_id, client_record_id=body.client_record_id)
    write(row, value)
    db.add(row)
    touch(lesson)
    db.flush()
    return RecordSaved(record=value, record_version=lesson.record_version)


def update(db: Session, lesson_id: str, record_id: str, body: RecordPatch, actor: str) -> RecordSaved:
    lesson = lessons.get(db, lesson_id, lock=True)
    row = get(db, lesson_id, record_id)
    before = to_dto(row)
    values = body.model_dump(exclude_unset=True, exclude={"expected_revision"})
    try:
        after = Record.model_validate({**before.model_dump(), **values})
    except ValidationError as exc:
        raise BusinessError(422, "INVALID_ARGUMENT", "更正后的记录字段不完整或不匹配") from exc
    if before.revision != body.expected_revision:
        if before.revision == body.expected_revision + 1 and after == before:
            return RecordSaved(record=before, record_version=lesson.record_version)
        raise BusinessError(409, "VERSION_CONFLICT", "记录已更正，请重新读取后再修改")
    validate(db, lesson, after)
    if before == after:
        return RecordSaved(record=before, record_version=lesson.record_version)
    after.revision += 1
    write(row, after)
    db.add(
        RecordCorrectionRow(
            record_id=record_id,
            revision=after.revision,
            before=before.model_dump(mode="json"),
            after=after.model_dump(mode="json"),
            changed_at=datetime.now(UTC),
            changed_by=actor,
        )
    )
    touch(lesson)
    db.flush()
    return RecordSaved(record=after, record_version=lesson.record_version)
