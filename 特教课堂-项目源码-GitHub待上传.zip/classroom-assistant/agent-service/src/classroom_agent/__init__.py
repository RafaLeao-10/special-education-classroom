"""B: teaching generation and deterministic teaching tools."""
