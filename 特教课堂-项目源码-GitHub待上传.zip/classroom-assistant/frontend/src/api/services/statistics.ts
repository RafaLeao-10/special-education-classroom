import { client, unwrap } from "../client";
import type { components } from "../generated/schema";
export type StatisticsRow = components["schemas"]["StatisticsRow"];
export const statisticsApi = {
  get: async (id: string) =>
    unwrap(
      await client.GET("/api/v1/lessons/{id}/statistics", {
        params: { path: { id } },
      }),
    ),
};
