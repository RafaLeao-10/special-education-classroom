import { onUnmounted, type Ref } from "vue";

export interface ClassroomShortcutHandlers {
prev(): void;
next(): void;
toggleTask(): void;
quickCount(key: "independent" | "prompted" | "not_completed" | "unknown"): void;
toggleSplit(): void;
help(): void;
}

// 焦点落在这些元素里时，快捷键不抢按键
const INPUT_TARGETS =
"input, textarea, select, [contenteditable], .el-input, .el-textarea";

export function useClassroomShortcuts(
enabled: Ref<boolean>,
handlers: ClassroomShortcutHandlers,
) {
function onKeydown(event: KeyboardEvent) {
    if (!enabled.value) return;
    if (event.isComposing) return; // 中文输入法组词中
    const target = event.target as HTMLElement | null;
    if (target && target.closest(INPUT_TARGETS)) return;
    if (event.altKey || event.ctrlKey || event.metaKey) return;

    const keyMap: Record<string, () => void> = {
    ArrowLeft: () => {
        event.preventDefault();
        handlers.prev();
    },
    ArrowRight: () => {
        event.preventDefault();
        handlers.next();
    },
    Enter: () => {
        event.preventDefault();
        handlers.toggleTask();
    },
    "1": () => handlers.quickCount("independent"),
    "2": () => handlers.quickCount("prompted"),
    "3": () => handlers.quickCount("not_completed"),
    "4": () => handlers.quickCount("unknown"),
    s: () => handlers.toggleSplit(),
    S: () => handlers.toggleSplit(),
    "?": () => {
        event.preventDefault();
        handlers.help();
    },
    };
    keyMap[event.key]?.();
}

document.addEventListener("keydown", onKeydown);
onUnmounted(() => document.removeEventListener("keydown", onKeydown));
}