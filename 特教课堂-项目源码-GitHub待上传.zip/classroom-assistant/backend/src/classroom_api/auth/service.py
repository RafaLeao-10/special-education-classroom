import hashlib
import hmac
import secrets
from datetime import UTC, datetime, timedelta

from classroom_api.db import get_db
from classroom_api.errors import BusinessError
from classroom_api.settings import Settings
from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import SessionRow, UserRow

COOKIE = "classroom_session"


def hash_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 310_000).hex()
    return f"{salt}${digest}"


def token_hash(token: str, settings: Settings) -> str:
    if not settings.session_secret:
        raise BusinessError(503, "CONFIG_REQUIRED", "请先运行pnpm bootstrap生成会话密钥")
    return hmac.new(settings.session_secret.encode(), token.encode(), "sha256").hexdigest()


def login(db: Session, username: str, password: str, settings: Settings):
    user = db.scalar(select(UserRow).where(UserRow.username == username))
    if not user or not hmac.compare_digest(
        hash_password(password, user.password_hash.split("$")[0]), user.password_hash
    ):
        raise BusinessError(401, "UNAUTHORIZED", "教师账号或密码不正确")
    token = secrets.token_urlsafe(32)
    db.add(
        SessionRow(
            token_hash=token_hash(token, settings),
            user_id=user.id,
            expires_at=datetime.now(UTC) + timedelta(hours=12),
        )
    )
    return user, token


def require_user(request: Request, db: Session = Depends(get_db)) -> UserRow:
    token = request.cookies.get(COOKIE)
    session = db.get(SessionRow, token_hash(token, request.app.state.settings)) if token else None
    if not session or session.expires_at <= datetime.now(UTC):
        raise BusinessError(401, "UNAUTHORIZED", "请先登录教师账号")
    return db.get(UserRow, session.user_id)
