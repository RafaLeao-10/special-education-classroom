import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { readFileSync, existsSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { join } from "node:path";

export const root = fileURLToPath(new URL("..", import.meta.url));
export function ensureConfig() {
  const path = join(root, ".env");
  if (!existsSync(path)) {
    const source = readFileSync(join(root, ".env.example"), "utf8");
    writeFileSync(
      path,
      source.replace(
        "SESSION_SECRET=",
        `SESSION_SECRET=${randomBytes(32).toString("hex")}`,
      ),
      { flag: "wx" },
    );
  }
}
export function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: root,
      stdio: "inherit",
      windowsHide: true,
      ...options,
    });
    child.on("error", reject);
    child.on("exit", (code) =>
      code === 0
        ? resolve()
        : reject(new Error(`${command} ${args.join(" ")} 退出码 ${code}`)),
    );
  });
}
export function pnpm(args) {
  if (!process.env.npm_execpath)
    throw new Error("请从根目录通过pnpm命令运行脚本");
  return run(process.execPath, [process.env.npm_execpath, ...args]);
}
export const python = (args) => run("uv", ["run", "--no-sync", ...args]);
export function available(command, args) {
  return (
    spawnSync(command, args, { cwd: root, stdio: "ignore", windowsHide: true })
      .status === 0
  );
}
