<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import { lessonsApi, type Lesson } from "../../api/services/lessons";
import Button from "../../components/Button.vue";
import ButtonGroup from "../../components/ButtonGroup.vue";
import AppIcon from "../../components/AppIcon.vue";
import { studentsApi, type Student } from "../../api/services/students";
import {
  reportsApi,
  type ClassroomReport,
  type ReportContent,
  type ReportSummary,
  type TeacherReportInput,
} from "../../api/services/reports";
import { classroomApi } from "../../api/services/classroom";
import RecordNotebook from "../records/RecordNotebook.vue";
import {
  statisticsApi,
  type StatisticsRow,
} from "../../api/services/statistics";
import StatisticsTable from "./StatisticsTable.vue";
import BehaviorTrendChart from "./BehaviorTrendChart.vue";
import { useUnsavedChanges } from "../../app/useUnsavedChanges";
import ReportEditor from "./ReportEditor.vue";
import AgentReportPanel from "./AgentReportPanel.vue";
import { clearDraft, readDraft, writeDraft } from "../../app/drafts";
import { ApiError } from "../../api/client";
const route = useRoute();
const router = useRouter();
const id = String(route.params.id);
function reportQuery(reportId?: string) {
  return router.replace({ query: { ...route.query, report_id: reportId } });
}
const lesson = ref<Lesson>();
const students = ref<Student[]>([]);
const reports = ref<ReportSummary[]>([]);
const saved = ref<ClassroomReport>();
const content = ref<ReportContent>();
const baseline = ref("");
const error = ref("");
const busy = ref(false);
const historyPlan = ref("");
const currentStatistics = ref<StatisticsRow[]>([]);
const statisticsError = ref("");
const noteDirty = ref(false);
useUnsavedChanges(computed(() => dirty.value || noteDirty.value));
async function loadStatistics() {
  try {
    const result = await statisticsApi.get(id);
    currentStatistics.value = result.rows;
    statisticsError.value = "";
  } catch (e) {
    statisticsError.value = (e as Error).message;
  }
}
type PendingReport = { signature: string; body: TeacherReportInput };
const pending = ref<PendingReport>();
const scope = `report-editor:${id}`;
type ReportDraft = {
  reportId?: string;
  revision?: number;
  planVersion: number;
  recordVersion: number;
  content: ReportContent;
  pending?: PendingReport;
};
const recovery = ref<ReportDraft | null>(null);
let loadingDraft = true;
function persist() {
  if (loadingDraft || !content.value || !lesson.value || recovery.value) return;
  if (dirty.value || pending.value)
    writeDraft(scope, {
      reportId: saved.value?.id,
      revision: saved.value?.revision,
      planVersion: lesson.value.plan_version,
      recordVersion: lesson.value.record_version,
      content: content.value,
      pending: pending.value,
    });
  else clearDraft(scope);
}
watch([content, pending], persist, { deep: true });
function recoverDraft() {
  if (!recovery.value) return;
  content.value = recovery.value.content;
  if (
    saved.value?.revision !== recovery.value.revision ||
    saved.value?.status === "confirmed" ||
    recovery.value.planVersion !== lesson.value?.plan_version ||
    recovery.value.recordVersion !== lesson.value?.record_version
  ) {
    saved.value = undefined;
    pending.value = undefined;
    baseline.value = "";
    void reportQuery();
  } else pending.value = recovery.value.pending;
  recovery.value = null;
  persist();
}
const dirty = computed(
  () => !!content.value && JSON.stringify(content.value) !== baseline.value,
);
const stale = computed(
  () =>
    !!saved.value &&
    !!lesson.value &&
    (saved.value.source_plan_version !== lesson.value.plan_version ||
      saved.value.source_record_version !== lesson.value.record_version),
);
const readonly = computed(
  () =>
    lesson.value?.status !== "completed" || saved.value?.status === "confirmed",
);
function setContent(value: ReportContent) {
  content.value = JSON.parse(JSON.stringify(value));
  baseline.value = JSON.stringify(content.value);
}
function newReport() {
  clearDraft(scope);
  recovery.value = null;
  void reportQuery();
  saved.value = undefined;
  pending.value = undefined;
  setContent({
    overview: "",
    activity_summaries:
      lesson.value?.plan?.activities.map((a) => ({
        activity_id: a.id,
        text: "",
        record_ids: [],
        adjustment_ids: [],
      })) || [],
    student_summaries: lesson.value!.student_ids.map((student_id) => ({
      student_id,
      text: "",
      record_ids: [],
    })),
    group_summaries: [],
    adjustment_summaries: [],
    recommendations: [],
    missing_information: [],
  });
}
async function run(work: () => Promise<void>) {
  if (busy.value) return;
  busy.value = true;
  error.value = "";
  try {
    await work();
  } catch (e) {
    error.value = (e as Error).message;
    if (
      e instanceof ApiError &&
      e.status >= 400 &&
      e.status < 500 &&
      ![408, 429].includes(e.status)
    ) {
      pending.value = undefined;
      persist();
    }
  } finally {
    busy.value = false;
  }
}
async function selectReport(reportId: string) {
  await run(async () => {
    saved.value = await reportsApi.get(reportId);
    setContent(saved.value.content);
    pending.value = undefined;
    clearDraft(scope);
    recovery.value = null;
    await reportQuery(saved.value.id);
  });
}
async function agentReportSaved(reportId: string) {
  reports.value = await reportsApi.list(id);
  await selectReport(reportId);
}
async function refreshAgentContext() {
  lesson.value = await lessonsApi.get(id);
  reports.value = await reportsApi.list(id);
  await loadStatistics();
}
async function load() {
  await run(async () => {
    loadingDraft = true;
    pending.value = undefined;
    const draft = readDraft<ReportDraft>(scope);
    const [data, people, summaries] = await Promise.all([
      lessonsApi.get(id),
      studentsApi.list(),
      reportsApi.list(id),
    ]);
    lesson.value = data;
    students.value = data.student_snapshots?.length
      ? data.student_snapshots
      : people.items;
    reports.value = summaries;
    if (draft && !draft.reportId) newReport();
    else if (summaries.length) {
      const selected =
        summaries.find((r) => r.id === draft?.reportId) ||
        summaries.find((r) => r.id === route.query.report_id) ||
        summaries[0];
      saved.value = await reportsApi.get(selected.id);
      setContent(saved.value.content);
    } else newReport();
    loadingDraft = false;
    if (draft) {
      recovery.value = draft;
      if (
        draft.planVersion === data.plan_version &&
        draft.recordVersion === data.record_version &&
        draft.reportId === saved.value?.id &&
        draft.revision === saved.value?.revision &&
        saved.value?.status !== "confirmed"
      )
        recoverDraft();
      else writeDraft(scope, draft);
    }
    await loadStatistics();
    const plans = await classroomApi.plans(id);
    historyPlan.value = plans.length
      ? `已保留 ${plans.length} 个教案版本，当前为 v${data.plan_version}`
      : "";
  });
}
async function reload() {
  clearDraft(scope);
  recovery.value = null;
  await load();
}
async function save() {
  await run(async () => {
    if (saved.value && !stale.value)
      saved.value = await reportsApi.update(saved.value.id, {
        expected_revision: saved.value.revision,
        content: content.value!,
      });
    else {
      const fields = {
        expected_plan_version: lesson.value!.plan_version,
        expected_record_version: lesson.value!.record_version,
        content: content.value!,
      };
      const signature = JSON.stringify(fields);
      if (!pending.value)
        pending.value = {
          signature,
          body: {
            ...JSON.parse(signature),
            client_request_id: crypto.randomUUID(),
          },
        };
      persist();
      saved.value = await reportsApi.create(id, pending.value.body);
      pending.value = undefined;
    }
    setContent(saved.value.content);
    clearDraft(scope);
    reports.value = await reportsApi.list(id);
    await reportQuery(saved.value.id);
    ElMessage.success("课堂报告已保存");
  });
}
async function reportAction(action: "confirm" | "reopen") {
  await run(async () => {
    saved.value = await reportsApi.action(saved.value!.id, {
      action,
      expected_revision: saved.value!.revision,
    });
    setContent(saved.value.content);
    reports.value = await reportsApi.list(id);
    ElMessage.success(
      action === "confirm" ? "报告已确认归档" : "报告已重新打开为草稿",
    );
  });
}
async function recordsChanged(version: number) {
  lesson.value!.record_version = Math.max(
    lesson.value!.record_version,
    version,
  );
  try {
    reports.value = await reportsApi.list(id);
    await loadStatistics();
  } catch (e) {
    error.value = (e as Error).message;
  }
}
onMounted(load);
</script>
<template>
  <div class="page-title">
    <div>
      <router-link to="/reports" class="back-link"
        >← 返回报告档案室</router-link
      >
      <span class="stage-tag stage-lavender">课后 · 报告</span>
      <h1>{{ lesson?.title || "课后回顾" }}</h1>
      <p class="page-description">真实的观察，是每一份报告的起点。</p>
    </div>
    <ButtonGroup>
      <Button variant="ghost" :disabled="busy" @click="reload">{{
        dirty ? "放弃未保存修改并重新读取" : "重新读取"
      }}</Button>
      <router-link
        :to="`/lessons/${id}/classroom`"
        custom
        v-slot="{ navigate }"
      >
        <Button variant="secondary" @click="navigate">回到课堂</Button>
      </router-link>
    </ButtonGroup>
  </div>
  <p v-if="error" class="inline-error" role="alert">{{ error }}</p>
  <div v-if="recovery" class="preview-notice">
    本机留有未保存的报告，课堂资料或报告版本已变化。恢复后将作为新草稿。
    <ButtonGroup>
      <Button size="sm" variant="ghost" :disabled="busy" @click="recoverDraft"
        >恢复为新草稿</Button
      >
      <Button size="sm" variant="quiet" :disabled="busy" @click="reload"
        >放弃本机草稿</Button
      >
    </ButtonGroup>
  </div>
  <template v-if="lesson && content">
    <p class="preview-notice">
      课堂报告可由你编写，也可根据已保存记录生成。每轮报告独立保存，可随时查阅。
    </p>
    <p v-if="lesson.status !== 'completed'" class="subtle">
      本课尚未结束，可先查看和补充速记，结课后再保存报告。
    </p>
    <div class="report-stack">
      <div class="report-records">
        <RecordNotebook
          :lesson="lesson"
          :students="students"
          report-mode
          @saved="recordsChanged"
          @dirty="noteDirty = $event"
        />
        <div class="report-tools">
        <details class="report-tool">
          <summary>当前记录统计</summary>
          <div class="report-tool-body"><h3>当前记录统计</h3>
          <Button size="sm" variant="ghost" @click="loadStatistics">重新统计</Button>
          <p v-if="statisticsError" role="alert" class="inline-error">
            {{ statisticsError }}
          </p>
          <StatisticsTable
            v-else
            :rows="currentStatistics"
            :lesson="lesson"
            :students="students"
          />
          </div>
        </details>
        <details class="report-tool">
            <summary>行为计数趋势</summary>
            <div class="report-tool-body"><h3>行为计数趋势</h3>
            <BehaviorTrendChart :lesson-id="id" />
            </div>
        </details>
        <details class="report-tool">
          <summary>本课的报告记录</summary>
          <div class="report-tool-body"><h3>本课的报告记录</h3>
          <p class="subtle">{{ historyPlan }}</p>
          <p v-if="!reports.length" class="subtle">尚无已保存报告。</p>
          <button
            v-for="report in reports"
            :key="report.id"
            class="saved-report-row"
            :class="{ selected: saved?.id === report.id }"
            :disabled="busy || dirty || !!pending || !!recovery"
            @click="selectReport(report.id)"
          >
            <span>{{
              new Date(report.generated_at).toLocaleString("zh-CN")
            }}</span
            ><strong
              >{{ report.status === "confirmed" ? "已确认" : "草稿"
              }}{{ report.is_stale ? " · 记录已更新" : "" }}</strong
            >
          </button>
          <Button
            v-if="lesson.status === 'completed'"
            variant="secondary"
            :disabled="busy || dirty || !!pending || !!recovery"
            @click="newReport"
            >另写一份报告</Button
          >
          </div>
        </details>
        </div>
      </div>
      <hr class="report-divider" aria-hidden="true" />
      <section class="report-blueprint">
        <p class="eyebrow">课堂报告</p>
        <h2>{{ saved ? "已保存课堂报告" : "填写本课报告" }}</h2>
        <div class="report-meta">
          <span class="status-pill">{{
            saved?.status === "confirmed"
              ? "已确认归档"
              : saved?.authoring_mode === "agent"
                ? "智能生成草稿"
                : "教师填写草稿"
          }}</span
          ><span v-if="saved">修订 {{ saved.revision }}</span>
        </div>
        <p v-if="stale" class="inline-error" role="status">
          课堂记录已有更正。这份报告保留原内容，可按最新记录另存报告。
        </p>
        <p v-if="saved" class="draft-label">
          依据教案 v{{ saved.source_plan_version }} / 课堂记录 v{{
            saved.source_record_version
          }}
        </p>
        <ReportEditor
          v-model="content"
          :lesson="lesson"
          :students="students"
          :disabled="readonly || busy || !!recovery || !!pending"
        />
        <p
          v-if="!saved || saved.authoring_mode === 'teacher'"
          class="draft-label"
        >
          报告正文由教师填写；统计仅来自保存时的有效观察计数，不从文字速记推断。
        </p>
        <template v-if="saved">
          <details class="report-saved-statistics"><summary>本报告保存时的统计</summary>
          <StatisticsTable
            :rows="saved.statistics"
            :lesson="lesson"
            :students="students"
          />
          </details>
          <div class="report-actions">
            <Button :to="`/reports/${saved.id}/print`" variant="ghost" size="sm"
              >打印这份报告 <AppIcon name="arrow" :size="16" /></Button
            ><Button
              v-if="saved.status === 'confirmed' && !stale"
              :to="{ path: '/lessons', query: { from_report: saved.id } }"
              variant="secondary"
              size="sm"
              >依据这份报告开始下一课</Button
            >
          </div></template
        >
        <div class="report-actions">
          <Button
            v-if="!readonly"
            variant="primary"
            :loading="busy"
            :disabled="
              !!recovery ||
              !content.overview.trim() ||
              (!!saved && !dirty && !stale)
            "
            @click="save"
            >{{ stale ? "按最新记录另存报告" : "保存报告草稿" }}</Button
          >
          <Button
            v-if="saved?.status === 'draft'"
            variant="secondary"
            :disabled="busy || dirty || stale"
            @click="reportAction('confirm')"
            >确认并归档</Button
          >
          <Button
            v-if="saved?.status === 'confirmed'"
            variant="secondary"
            :disabled="busy"
            @click="reportAction('reopen')"
            >重新打开编辑</Button
          >
        </div>
        <p class="draft-label">
          {{
            dirty
              ? "有尚未保存的报告内容"
              : saved
                ? "已保存，刷新后可重新读取"
                : "填写课堂概览后即可保存"
          }}
        </p>
      </section>
      <hr class="report-divider" aria-hidden="true" />
      <AgentReportPanel
        :lesson="lesson"
        :students="students"
        :disabled="busy || !!recovery || dirty || noteDirty"
        @saved="agentReportSaved"
        @context-changed="refreshAgentContext"
      />
    </div>
  </template>
  <p v-else-if="!error" class="subtle">正在读取课堂回顾…</p>
</template>

<style scoped>
.report-stack { max-width: 1080px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px; }
.report-divider { width: 100%; height: 0; margin: -12px 0; border: 0; border-top: 1px solid #d7dfd5; }
.report-records, .report-blueprint, .report-stack :deep(> .agent-panel) { min-width: 0; border: 1px solid #dce6db; border-radius: 20px; padding: clamp(22px, 3vw, 36px); }
.report-records { background: #faf8f0; border-color: #e8e2d3; }
.report-records :deep(.notes-panel) { padding: 0; border: 0; background: transparent; box-shadow: none; }
.report-blueprint { background: #f2f7f0; }
.report-stack :deep(> .agent-panel) { margin: 0; background: #edf4f2; border-color: #d9e5e1; }
.report-tools { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
.report-tool { min-width: 0; }
.report-tool[open] { width: 100%; }
.report-tool summary { display: inline-flex; align-items: center; gap: 8px; padding: 9px 14px; border: 1px solid #d6dfd4; border-radius: 10px; background: #fff; color: #3f5b4b; cursor: pointer; font-size: 14px; }
.report-tool summary::after { content: '⌄'; font-size: 16px; }
.report-tool[open] summary::after { content: '⌃'; }
.report-tool-body { margin-top: 12px; padding: 20px; border-radius: 12px; background: rgba(255, 255, 255, .7); }
.report-saved-statistics { margin: 18px 0; }
.report-saved-statistics summary { cursor: pointer; color: #3f5b4b; font-weight: 600; }
</style>
