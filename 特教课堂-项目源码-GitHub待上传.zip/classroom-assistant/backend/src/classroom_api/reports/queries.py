"""Read-only report references used by lesson planning; no lesson service import."""

from sqlalchemy import select

from classroom_api.errors import BusinessError
from classroom_api.lessons.models import LessonRow

from .models import ReportRow


def get_previous(db, ids):
    rows = {r.id: r for r in db.scalars(select(ReportRow).where(ReportRow.id.in_(ids)))}
    if len(set(ids)) != len(ids) or set(rows) != set(ids):
        raise BusinessError(422, "INVALID_ARGUMENT", "前次报告不存在或重复", ["previous_report_ids"])
    return [rows[id] for id in ids]


def validate_previous(db, ids, student_ids):
    for report in get_previous(db, ids):
        lesson = db.get(LessonRow, report.lesson_id)
        if report.status != "confirmed" or (report.source_plan_version, report.source_record_version) != (
            lesson.plan_version,
            lesson.record_version,
        ):
            raise BusinessError(409, "INVALID_STATE", "前次报告需已确认且未过期", ["previous_report_ids"])
        if not set(lesson.student_ids) <= set(student_ids):
            raise BusinessError(422, "INVALID_ARGUMENT", "新课程须包含所引用报告的参与学生", ["student_ids"])
